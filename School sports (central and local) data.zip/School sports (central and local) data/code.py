# -*- coding: utf-8 -*-
"""
学校体育政策府际协同关系分析系统 - v28最终版（修复部门名称标准化）
================================================================================
【v28核心修复】
1. 修复部门名称标准化函数，区分中央和地方部门
2. 地方政策中的"财政部门"正确显示为"省级财政部门"
3. 确保网络图节点名称准确反映政策层级
4. 所有分析均基于真实数据
5. 主题关键词改为8个
【v28.3新增】
6. "央地政策不同时期工具使用分布表"中，每个时间段内所有14个二级指标归一化后总和=100%
【v28.4修改】
7. 所有输出结果图的分辨率改为1000 DPI
8. 移除信度检验相关代码（不再依赖学校体育政策信度检验抽样汇总表.xlsx）
9. 更新政策工具二级指标来源参考文献：王培刚与吴婧等(2026)，曹盛民与史万兵(2018)，张歆竹与刘俊荣，部义峰与来鲁振(2020)
10. 修改中央网络_四时段对比图.png、地方网络_四时段对比图.png、央地核心协作派系网络对比图.png的节点标签字体为12
================================================================================
"""

import os
import re
import pandas as pd
import numpy as np
import jieba
import random
from collections import Counter, defaultdict
from typing import List, Dict, Tuple, Optional, Any
from glob import glob
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')


# ==================== 机器学习相关导入 ====================
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import normalize
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

# ==================== 匈牙利算法导入 ====================
try:
    from scipy.optimize import linear_sum_assignment
    HAS_SCIPY = True
    print("✓ 已加载 scipy.optimize.linear_sum_assignment (匈牙利算法)")
except ImportError:
    HAS_SCIPY = False
    print("⚠️ scipy 未安装，将使用贪心匹配算法")

# ==================== 网络分析导入 ====================
import networkx as nx

# ==================== 可视化导入 ====================
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import Patch

# ==================== adjustText 导入（用于自动调整标签位置） ====================
try:
    from adjustText import adjust_text
    HAS_ADJUSTTEXT = True
    print("✓ 已加载 adjustText")
except ImportError:
    HAS_ADJUSTTEXT = False
    print("⚠️ adjustText 未安装，请运行: pip install adjustText")

# ==================== 配置 ====================
CENTRAL_PATH = "/Users/swnn/Desktop/学校体育（新）/中央数据（整理）（48份）"
LOCAL_PATH = "/Users/swnn/Desktop/学校体育（新）/地方数据（整理）（150份）"
EXCEL_PATH = "/Users/swnn/Desktop/学校体育（新）/学校体育政策文件.xlsx"
OUTPUT_DIR = "/Users/swnn/Desktop/学校体育（新）/1 输出结果"

SHEET_CENTRAL = "中央政策"
SHEET_LOCAL = "地方政策"

# ========== 【修改】列名配置 ==========
# 政策名称列（中央和地方通用）
POLICY_NAME_COL = "文件名称"

# 中央政策列
CENTRAL_DEPT_COL = "发文主体（部门）"                    # 中文列（备用）
CENTRAL_DEPT_EN_COL = "Issuing Authority（Department）"  # 英文列（主要使用）
CENTRAL_YEAR_COL = "颁布时间"                            # 时间列

# 地方政策列
LOCAL_DEPT_COL = "发文主体（部门归类）"                          # 中文列（备用）
LOCAL_DEPT_EN_COL = "Issuing Authority（Department Category）"  # 英文列（主要使用）
LOCAL_YEAR_COL = "颁布时间"                                     # 时间列

# 扩展：所有可能的文件名列（用于备用提取）
POSSIBLE_FILENAME_COLS = ['文件名称', '文件名', 'filename', 'FileName', '政策文件', '政策名称']

if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

# ==================== 全局设置 ====================
def set_all_seeds(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    print(f"Random seed set: {seed}")

set_all_seeds(42)

# ========== 【修改】使用英文字体（仅英文，无中文） ==========
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

# 只使用英文字体，避免中文乱码
plt.rcParams['font.sans-serif'] = ['Arial', 'Helvetica', 'DejaVu Sans', 'Tahoma', 'Verdana']
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 10
print("✅ Font set to English only")

# ==================== 常量定义 ====================
SYNERGY_COLORS = {
    '高度协同': '#2ecc71',
    '地方强化': '#e67e22',
    '地方衰减': '#e74c3c',
    '地方关注': '#3498db',
    '中央主导': '#95a5a6',
    '地方创新': '#9b59b6',
    '中央特有': '#f1c40f'
}

SYNERGY_MEANINGS = {
    '高度协同': '央地强度差绝对值<0.10',
    '地方强化': '地方比中央强≥0.15',
    '地方衰减': '地方比中央弱≤-0.15',
    '地方关注': '地方略强于中央(0.10~0.15)',
    '中央主导': '中央略强于地方(0.10~0.15)',
    '地方创新': '地方独有主题',
    '中央特有': '中央独有主题'
}

ALL_SYNERGY_TYPES = ['高度协同', '地方强化', '地方衰减', '地方关注', '中央主导', '地方创新', '中央特有']
MATCHED_SYNERGY_TYPES = ['高度协同', '地方强化', '地方衰减', '地方关注', '中央主导']

MATCH_QUALITY = {'high': 0.70, 'medium': 0.40, 'low': 0.10}
QUALITY_SCORES = {'high': 1.0, 'medium': 0.7, 'low': 0.4, 'none': 0.2, 'unknown': 0.5}
QUALITY_MULTIPLIERS = {'high': 1.0, 'medium': 0.85, 'low': 0.70, 'none': 0.5, 'unknown': 0.6}
COMPREHENSIVE_SCORE_WEIGHTS = {'synergy_type_weight': 0.6, 'match_quality_weight': 0.4}

# 同义词映射
SYNONYM_MAPPING = {
    '体育教师': '体育师资', '体育师资': '体育教师',
    '教练员': '教练', '教练': '教练员',
    '体育场馆': '体育设施', '体育设施': '体育场馆',
    '运动场': '体育场地', '体育场地': '运动场',
    '经费': '资金', '资金': '经费',
    '课时': '学时', '学时': '课时',
    '课程标准': '教学标准',
    '考核': '评估', '评估': '考核',
    '督导': '督查',
    '阳光体育': '阳光体育运动',
    '大课间': '课间活动',
    '校园足球': '足球特色学校', '足球特色学校': '校园足球'
}

# 部门类别映射
DEPT_CATEGORY_MAPPING = {
    # 中央部门
    '教育部': '教育部门',
    '国家体育总局': '体育部门',
    '国家发展改革委': '发改部门',
    '财政部': '财政部门',
    '人力资源社会保障部': '人社部门',
    '人力资源和社会保障部': '人社部门',
    '卫生健康委员会': '卫生部门',
    '国家卫生健康委': '卫生部门',
    '文化和旅游部': '文化部门',
    '科技部': '科技部门',
    '工业和信息化部': '工信部门',
    '民政部': '民政部门',
    '司法部': '司法部门',
    '住房和城乡建设部': '住建部门',
    '自然资源部': '自然资源部门',
    '生态环境部': '生态环境部门',
    '农业农村部': '农业农村部门',
    '商务部': '商务部门',
    '应急管理部': '应急管理部门',
    '国家市场监督管理总局': '市场监管部门',
    '国家广播电视总局': '广电部门',
    '国家新闻出版署': '新闻出版部门',
    '国家知识产权局': '知识产权部门',
    '国务院': '国务院',
    '国务院办公厅': '国务院部门',
    '国务院教育督导委员会办公室': '国务院部门',
    '中共中央办公厅': '党中央部门',
    '全国青少年校园足球工作领导小组': '国务院部门',
    '共青团中央': '共青团组织',
    '中国足协': '社会组织',
    '中央编办': '党中央部门',
    # 地方部门
    '省级教育行政部门': '教育部门',
    '省级体育行政部门': '体育部门',
    '省级财政部门': '财政部门',
    '省级发展改革部门': '发改部门',
    '省级人力资源和社会保障部门': '人社部门',
    '省级卫生健康部门': '卫生部门',
    '省级文化和旅游部门': '文化部门',
    '省级科技部门': '科技部门',
    '省级人民政府': '省级政府',
    '省级党委机关': '省级党委',
    '省级新闻出版广电部门': '新闻出版部门',
    '省级共青团组织': '共青团组织',
    '省级政府工作部门': '省级政府',
    '省级卫生行政部门': '卫生部门',
    '社会组织': '社会组织',
    '省级人民政府办公厅': '省级政府',
    '省级党委办公厅': '省级党委',
}



# ==================== 英文标签映射 ====================
ENGLISH_LABELS = {
    # 主题相关
    '中央政策': 'Central Policy',
    '地方政策': 'Local Policy',
    '中央': 'Central',
    '地方': 'Local',
    '主题': 'Topic',
    '主题数': 'Number of Topics',
    '主题强度': 'Topic Strength',
    '主题一致性': 'Topic Coherence',
    '主题区分度': 'Topic Distance',
    '困惑度': 'Perplexity',
    '年份': 'Year',
    '强度': 'Strength',
    '评估指标': 'Evaluation Metrics',
    '曲线': 'Curve',
    '对比': 'Comparison',
    
    # 协同类型
    '高度协同': 'High Synergy',
    '地方强化': 'Local Strengthening',
    '地方衰减': 'Local Attenuation',
    '地方关注': 'Local Focus',
    '中央主导': 'Central Dominance',
    '地方创新': 'Local Innovation',
    '中央特有': 'Central Unique',
    '府际协同类型分布': 'Intergovernmental Synergy Distribution',
    '央地主题强度差异分析': 'Central-Local Topic Strength Difference',
    '央地政策主题强度综合对比': 'Central-Local Topic Strength Comparison',
    
    # 工具相关
    '供给型': 'Supply-oriented',
    '需求型': 'Demand-oriented',
    '环境型': 'Environment-oriented',
    '一级工具': 'Primary Tool',
    '二级指标': 'Secondary Indicator',
    '使用占比': 'Usage Percentage',
    '政策工具指标': 'Policy Tool Indicator',
    '中央政策工具使用分布': 'Central Policy Tool Distribution',
    '地方政策工具使用分布': 'Local Policy Tool Distribution',
    '央地政策工具使用分布对比图': 'Central-Local Policy Tool Distribution',
    '组内归一化占比': 'Normalized Percentage',
    '原始数据': 'Raw Data',
    '政策工具类型分布': 'Policy Tool Type Distribution',
    '按政策工具类型划分的央地对比分析': 'Central-Local Comparison by Tool Type',
    '中央与地方政策工具使用差异热力图': 'Central-Local Policy Tool Difference Heatmap',
    '央地政策工具使用总量对比': 'Central-Local Policy Tool Total Comparison',
    '央地政策工具使用对比数据明细表': 'Central-Local Policy Tool Comparison Details',
    
    # 网络/主体相关
    '发文单位': 'Issuing Department',
    '节点数': 'Nodes',
    '边数': 'Edges',
    '加权网络密度': 'Weighted Density',
    '平均聚类系数': 'Avg Clustering',
    '平均路径长度': 'Avg Path Length',
    '相对度数中心度': 'Degree Centrality',
    '加权度数中心度': 'Weighted Degree',
    '接近中心度': 'Closeness',
    '中间中心度': 'Betweenness',
    '政策主体网络': 'Actor Network',
    '合作强度': 'Cooperation Intensity',
    '派系': 'Faction',
    '未分组节点': 'Ungrouped Nodes',
    '跨派系连接': 'Cross-faction Edges',
    '核心协作派系': 'Core Collaborative Factions',
    
    # 时间段
    '全时段': 'Full Period',
    '时间段': 'Time Period',
    '央地政策时间段主题强度对比': 'Topic Strength by Time Period',
    '2011-2025': '2011-2025',
    '2011-2015': '2011-2015',
    '2016-2020': '2016-2020',
    '2021-2025': '2021-2025',
    '十二五': '12th Five-Year',
    '十三五': '13th Five-Year',
    '十四五': '14th Five-Year',
    
    # 三维协同
    '工具多样性得分': 'Tool Diversity',
    '主体协作得分': 'Actor Collaboration',
    '综合协同得分': 'Comprehensive Synergy',
    '协同等级': 'Synergy Level',
    '高协同': 'High Synergy',
    '中等协同': 'Medium Synergy',
    '低协同': 'Low Synergy',
    '跨维度协同得分': 'Cross-dimensional Synergy',
    '主题匹配得分': 'Topic Matching',
    '工具相似度': 'Tool Similarity',
    '主体相似度': 'Actor Similarity',
    
    # 通用
    '分析': 'Analysis',
    '分布': 'Distribution',
    '趋势': 'Trend',
    '矩阵': 'Matrix',
    '热力图': 'Heatmap',
    '雷达图': 'Radar Chart',
    '散点图': 'Scatter Plot',
    '标题': 'Title',
    '说明': 'Note',
    '总计': 'Total',
    '排名': 'Rank',
    '序号': 'Index',
    
    # 网络图标题
    '中央政策主体协作网络': 'Central Policy Actor Network',
    '地方政策主体协作网络': 'Local Policy Actor Network',
    '央地网络对比图': 'Central-Local Network Comparison',
    '中央政策核心协作派系网络': 'Central Policy Core Faction Network',
    '地方政策核心协作派系网络': 'Local Policy Core Faction Network',
    '央地核心协作派系网络对比': 'Central-Local Core Faction Comparison',
    '同派系节点与连线颜色一致': 'Same Color = Same Faction',
    '边粗细表示合作强度': 'Edge Width = Cooperation Intensity',
    
    # 协同图
    '央地政策协同类型分布': 'Central-Local Synergy Distribution',
    '央地协同关系网络图': 'Central-Local Synergy Network',
    '央地政策主题协同关系网络图': 'Central-Local Topic Synergy Network',
    '央地主题强度差异分析': 'Topic Strength Difference',
    '央地政策主题强度综合对比': 'Topic Strength Comparison',
    
    # 三维协同图标题
    '中央政策-主题-工具关联热力图': 'Central: Theme-Tool Association',
    '地方政策-主题-工具关联热力图': 'Local: Theme-Tool Association',
    '中央政策-主题-主体关联热力图': 'Central: Theme-Actor Association',
    '地方政策-主题-主体关联热力图': 'Local: Theme-Actor Association',
    '中央政策主题三维协同能力雷达图': 'Central: 3D Synergy Radar',
    '地方政策主题三维协同能力雷达图': 'Local: 3D Synergy Radar',
    '中央政策主题聚类分析': 'Central: Topic Clustering',
    '地方政策主题聚类分析': 'Local: Topic Clustering',
    '央地跨维度协同矩阵': 'Cross-dimensional Synergy Matrix',
    
    # 工具表标题
    '央地政策不同时期工具使用分布表': 'Central-Local Tool Distribution by Period',
    '央地政策工具使用分布对比表': 'Central-Local Tool Distribution Comparison',
}

def get_en_label(chinese_text):
    """获取英文标签，如果没有映射则返回原文本"""
    if not chinese_text:
        return chinese_text
    # 精确匹配
    if chinese_text in ENGLISH_LABELS:
        return ENGLISH_LABELS[chinese_text]
    # 部分匹配
    for cn, en in ENGLISH_LABELS.items():
        if cn in chinese_text:
            return chinese_text.replace(cn, en)
    return chinese_text

# ==================== 【修复】部门标准化函数（区分中央和地方） ====================

def standardize_department_name(name, policy_type='central'):
    """
    标准化部门名称，区分中央和地方
    """
    if pd.isna(name):
        return name
    name = str(name).strip()
    
    # 中央部门标准化
    if policy_type == 'central':
        if '教育部' in name:
            return '教育部'
        if any(kw in name for kw in ['发改委', '发展改革委']):
            return '国家发展改革委'
        if '财政部' in name:
            return '财政部'
        if '体育总局' in name:
            return '国家体育总局'
        if '人力资源社会保障部' in name or '人社部' in name:
            return '人力资源社会保障部'
        if '卫生健康委员会' in name or '卫健委' in name:
            return '国家卫生健康委'
        if '文化和旅游部' in name:
            return '文化和旅游部'
        if '科技部' in name:
            return '科技部'
        if '工业和信息化部' in name:
            return '工业和信息化部'
        if '民政部' in name:
            return '民政部'
        if '司法部' in name:
            return '司法部'
        if '住房和城乡建设部' in name:
            return '住房和城乡建设部'
        if '自然资源部' in name:
            return '自然资源部'
        if '生态环境部' in name:
            return '生态环境部'
        if '农业农村部' in name:
            return '农业农村部'
        if '商务部' in name:
            return '商务部'
        if '应急管理部' in name:
            return '应急管理部'
        if '国家市场监督管理总局' in name:
            return '国家市场监督管理总局'
        if '国家广播电视总局' in name:
            return '国家广播电视总局'
        if '国家新闻出版署' in name:
            return '国家新闻出版署'
        if '国务院' in name:
            return '国务院'
        if '中共中央' in name or '中央办公厅' in name:
            return '中共中央办公厅'
        if '共青团中央' in name:
            return '共青团中央'
        return name
    
    # 地方部门标准化
    else:
        if any(kw in name for kw in ['教育行政部门', '教育厅', '教育局']):
            return '省级教育行政部门'
        if any(kw in name for kw in ['体育行政部门', '体育局']):
            return '省级体育行政部门'
        if any(kw in name for kw in ['财政部门', '财政厅']):
            return '省级财政部门'
        if any(kw in name for kw in ['发展改革部门', '发改委', '发展改革委']):
            return '省级发展改革部门'
        if any(kw in name for kw in ['人力资源和社会保障部门', '人社部门', '人社厅']):
            return '省级人力资源和社会保障部门'
        if any(kw in name for kw in ['卫生健康部门', '卫生行政部门', '卫健委', '卫生厅']):
            return '省级卫生健康部门'
        if any(kw in name for kw in ['文化和旅游部门', '文化部门']):
            return '省级文化和旅游部门'
        if any(kw in name for kw in ['科技部门', '科技厅']):
            return '省级科技部门'
        if '人民政府' in name or '省政府' in name or '政府办公厅' in name:
            return '省级人民政府'
        if '党委' in name or '省委' in name:
            return '省级党委机关'
        if '共青团' in name:
            return '省级共青团组织'
        if '新闻出版广电' in name or '广电' in name:
            return '省级新闻出版广电部门'
        if '政府工作部门' in name:
            return '省级政府工作部门'
        if '社会组织' in name:
            return '社会组织'
        return name


# ==================== 主题数搜索范围 ====================
CENTRAL_TOPIC_RANGE = (3, 6)
LOCAL_TOPIC_RANGE = (3, 6)

# ==================== 文档过滤配置 ====================
DOC_LENGTH_PERCENTILE_THRESHOLD = 0
MIN_DOC_LENGTH_ABSOLUTE = 0

# 三维协同分析配置
THREE_DIMENSION_CONFIG = {
    'theme_tool_weight': 0.35,
    'theme_actor_weight': 0.35,
    'tool_actor_weight': 0.30,
    'high_synergy_threshold': 0.70,
    'medium_synergy_threshold': 0.45
}

COLORS = {
    'central': '#2c7bb6', 'local': '#d7191c', 'high_synergy': '#2ecc71',
    'medium_synergy': '#f39c12', 'low_synergy': '#e74c3c', 'education': '#3498db',
    'sports': '#e67e22', 'finance': '#27ae60', 'health': '#1abc9c', 'hrss': '#f1c40f',
    'central_min': '#1a5276', 'central_max': '#2471a3', 'local_min': '#922b21',
    'local_max': '#c0392b', 'extreme_min': '#00a86b', 'extreme_max': '#8e44ad',
    'supply': '#3498db', 'demand': '#2ecc71', 'environment': '#e74c3c'
}

YEAR_EXTRACTION_PREFERENCE = "range_first"

# ==================== 政策工具框架理论依据（更新参考文献） ====================
FRAMEWORK_THEORETICAL_BASIS = """
【政策工具分析框架构建说明】

一、理论依据
   基于 Rothwell & Zegveld 模型：
   1. 供给型：政府通过直接提供资源、基础设施、人才培养等方式推动学校体育发展
   2. 需求型：政府通过购买服务、试点示范、激励引导等方式拉动学校体育需求
   3. 环境型：政府通过法规管制、目标规划、质量监管等方式营造学校体育发展环境

二、二级指标来源
   参考四篇核心文献：
   1. 王培刚、吴婧等（2026）
   2. 曹盛民、史万兵（2018）
   3. 张歆竹、刘俊荣（2024）
   4. 部义峰、来鲁振（2020）

三、14个二级指标框架
   供给型（5个）：基础建设、人才培养、资金投入、科技支持、公共服务
   需求型（4个）：购买服务、试点示范、家校社协同、引导激励
   环境型（5个）：法规管制、目标规划、质量监管、策略措施、宣传推广
"""

# ==================== 14个二级指标完整定义（更新文献来源） ====================
INDICATOR_DEFINITIONS = {
    "基础建设": "学校体育场地、场馆、器材等硬件设施的建设与配备",
    "人才培养": "体育教师的招聘、培训、职业发展、职称评定，专业教练员进校园",
    "资金投入": "财政专项资金、经费保障、生均经费、场地运营补贴",
    "科技支持": "体育教学数字化平台、智能监测设备、AI辅助教学、教育大数据",
    "公共服务": "跨区域、跨部门的体育资源共建共享，校际联盟，场馆双向开放",
    "购买服务": "政府或学校通过购买、外包等方式，引入社会力量参与学校体育服务供给",
    "试点示范": "校园足球/篮球/排球特色学校、健康学校试点、体教融合示范区",
    "家校社协同": "家长参与、社区体育资源进校园、体育家庭作业、协同育人",
    "引导激励": "评优评先、体质健康达标奖励、体育特长生存量政策",
    "法规管制": "体育课时标准、每日2小时活动、体质健康测试标准、督导评估制度",
    "目标规划": "学生体质强健计划、学校体育发展规划、2030健康学校全覆盖",
    "质量监管": "学校体育督导评估、体质健康抽测、健康学校建设成效纳入督导",
    "策略措施": "阳光体育运动、课间15分钟、一校一品、大单元教学",
    "宣传推广": "体育文化营造、典型经验推广、体育明星进校园、急救培训普及"
}

INDICATOR_KEYWORDS = {
    "基础建设": "场地、设施、器材、运动场、智慧体育",
    "人才培养": "教师、教练、培训、编制、职称、进校园",
    "资金投入": "经费、拨款、专项资金、生均、补贴",
    "科技支持": "数字化、平台、智能、大数据、智慧教育",
    "公共服务": "共享、联盟、开放、均衡、普惠",
    "购买服务": "购买服务、第三方、社会组织、外包、采购、委托、运营",
    "试点示范": "特色学校、试点、试验区、示范",
    "家校社协同": "家长、社区、家庭作业、协同育人",
    "引导激励": "奖励、表彰、评优、激励",
    "法规管制": "标准、课时、必须、严禁、体质测试、2小时",
    "目标规划": "规划、目标、纲要、强健计划",
    "质量监管": "督导、评估、检查、监测、抽测",
    "策略措施": "阳光体育、一校一品、大单元、课间15分钟",
    "宣传推广": "宣传、推广、文化、氛围、急救"
}

INDICATOR_TO_TYPE = {
    "基础建设": "供给型", "人才培养": "供给型", "资金投入": "供给型",
    "科技支持": "供给型", "公共服务": "供给型",
    "购买服务": "需求型", "试点示范": "需求型", "家校社协同": "需求型",
    "引导激励": "需求型",
    "法规管制": "环境型", "目标规划": "环境型", "质量监管": "环境型",
    "策略措施": "环境型", "宣传推广": "环境型"
}

# ==================== 更新文献来源映射 ====================
INDICATOR_LITERATURE = {
    "基础建设": "曹盛民、史万兵（2018）",
    "人才培养": "曹盛民、史万兵（2018）",
    "资金投入": "曹盛民、史万兵（2018）",
    "科技支持": "曹盛民、史万兵（2018）",
    "公共服务": "曹盛民、史万兵（2018）",
    "购买服务": "张歆竹、刘俊荣（2024）",
    "试点示范": "张歆竹、刘俊荣（2024）",
    "家校社协同": "张歆竹、刘俊荣（2024）",
    "引导激励": "张歆竹、刘俊荣（2024）",
    "法规管制": "部义峰、来鲁振（2020）",
    "目标规划": "部义峰、来鲁振（2020）",
    "质量监管": "部义峰、来鲁振（2020）",
    "策略措施": "部义峰、来鲁振（2020）",
    "宣传推广": "部义峰、来鲁振（2020）"
}


# ==================== Excel日期解析函数 ====================
def parse_excel_date(date_val) -> Optional[int]:
    """解析Excel中的日期，支持多种格式"""
    if pd.isna(date_val):
        return None
    
    if isinstance(date_val, datetime):
        return date_val.year
    
    if isinstance(date_val, (int, float)):
        try:
            if date_val > 59:
                base = datetime(1899, 12, 30)
            else:
                base = datetime(1899, 12, 31)
            date_obj = base + timedelta(days=date_val)
            return date_obj.year
        except:
            pass
    
    if isinstance(date_val, str):
        year_match = re.search(r'(19|20)\d{2}', date_val)
        if year_match:
            return int(year_match.group())
    
    return None


# ==================== 部门映射函数 ====================
def map_department_to_category(dept_name: str) -> str:
    """将部门名称映射到类别"""
    if pd.isna(dept_name) or not dept_name:
        return dept_name
    
    dept_name = str(dept_name).strip()
    
    for key, category in DEPT_CATEGORY_MAPPING.items():
        if key in dept_name:
            return category
    
    return dept_name

# ==================== 【修复】extract_departments_from_field 函数 ====================

def extract_departments_from_field(department_field):
    """
    从部门字段提取部门列表，直接返回原始部门名称
    不进行任何标准化处理，保留Excel原始数据
    """
    if pd.isna(department_field):
        return []
    text = str(department_field).strip()
    if not text or text == "nan":
        return []
    
    departments = []
    
    # 处理"XX等N个部门"格式
    if '等' in text and '部门' in text:
        match = re.search(r'(.+?)等\d+个部门', text)
        if match:
            parts = re.split(r'[、，]', match.group(1))
            for part in parts:
                part = part.strip()
                if part and len(part) >= 2 and part != '等':
                    departments.append(part)
    
    # 处理多个部门用顿号/逗号分隔
    if not departments:
        parts = re.split(r'[、，]', text)
        for part in parts:
            part = part.strip()
            if part and len(part) >= 2 and part != '等':
                departments.append(part)
    
    # 单个部门
    if not departments and len(text) >= 2:
        departments = [text]
    
    # 去重（保持顺序）
    seen = set()
    unique_departments = []
    for d in departments:
        d_clean = d.strip()
        if d_clean and d_clean not in seen:
            seen.add(d_clean)
            unique_departments.append(d_clean)
    
    return unique_departments


# ==================== 【新增】从英文列提取部门名称 ====================

def extract_departments_from_field_en(department_field):
    """
    从英文部门字段提取部门列表
    直接返回Excel中的英文名称，不进行任何翻译
    """
    if pd.isna(department_field):
        return []
    text = str(department_field).strip()
    if not text or text == "nan":
        return []
    
    departments = []
    
    # 处理 "et al." 或 "等" 格式
    if 'et al.' in text.lower() or '等' in text:
        # 按逗号、顿号、分号分割
        parts = re.split(r'[、，,;]', text)
        for part in parts:
            part = part.strip()
            if part and len(part) >= 2:
                # 清理 "et al." 等后缀
                clean_part = re.sub(r'\s*et\s+al\.?\s*', '', part, flags=re.IGNORECASE).strip()
                if clean_part:
                    departments.append(clean_part)
    
    # 处理多个部门用逗号/顿号/分号分隔
    if not departments:
        parts = re.split(r'[、，,;]', text)
        for part in parts:
            part = part.strip()
            if part and len(part) >= 2:
                departments.append(part)
    
    # 单个部门
    if not departments and len(text) >= 2:
        departments = [text]
    
    # 去重（保持顺序）
    seen = set()
    unique_departments = []
    for d in departments:
        d_clean = d.strip()
        if d_clean and d_clean not in seen:
            seen.add(d_clean)
            unique_departments.append(d_clean)
    
    return unique_departments



def expand_with_synonyms(text: str) -> str:
    if not text or not isinstance(text, str):
        return text
    result = text
    for orig, syn in SYNONYM_MAPPING.items():
        if orig in result:
            result = result + " " + syn
    return result


# ==================== 年份提取 ====================
def extract_year_from_filename(filename: str) -> Optional[int]:
    year_match = re.search(r'(201[1-9]|202[0-5])', filename)
    if year_match:
        return int(year_match.group())
    return None


def extract_years_covered_from_filename(filename: str) -> List[int]:
    years = []
    range_match = re.search(r'(201[1-9]|202[0-5])\s*[-~到]\s*(201[1-9]|202[0-5])', filename)
    if range_match:
        start = int(range_match.group(1))
        end = int(range_match.group(2))
        years = list(range(start, end + 1))
    else:
        year = extract_year_from_filename(filename)
        if year:
            years = [year]
    return years


# ==================== 模块一：主题部分 ====================

class DataLoader:
    def __init__(self, central_path, local_path, output_path):
        self.central_path = central_path
        self.local_path = local_path
        self.output_path = output_path
        if not os.path.exists(output_path):
            os.makedirs(output_path)
    
    def _read_file_with_encoding(self, file_path):
        encodings = ['utf-8', 'gbk', 'gb2312', 'gb18030', 'utf-8-sig', 'latin-1', 'cp936', 'big5']
        for enc in encodings:
            try:
                with open(file_path, 'r', encoding=enc) as f:
                    return f.read()
            except:
                continue
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except:
            return None
    
    def load_text_files(self, folder_path, policy_type):
        policies = []
        txt_files = glob(os.path.join(folder_path, "*.txt"))
        print(f"正在加载 {policy_type} 政策文件，共找到 {len(txt_files)} 个")
        
        for file_path in txt_files:
            filename = os.path.basename(file_path)
            content = self._read_file_with_encoding(file_path)
            
            if content is None:
                print(f"  ❌ 读取失败 {filename}")
                continue
            
            year = extract_year_from_filename(filename)
            years_covered = extract_years_covered_from_filename(filename)
            
            policies.append({
                'id': len(policies) + 1,
                'title': filename.replace('.txt', ''),
                'content': content,
                'type': policy_type,
                'year': year,
                'years_covered': years_covered,
                'file_size': len(content)
            })
        
        print(f"成功加载 {len(policies)} 份 {policy_type} 政策文件")
        return pd.DataFrame(policies)
    
    def load_all_policies(self):
        central_df = self.load_text_files(self.central_path, 'central')
        local_df = self.load_text_files(self.local_path, 'local')
        return central_df, local_df


class PolicyPreprocessor:
    def __init__(self):
        self.custom_words = ['体育中考', '教会勤练常赛', '每天2小时', '体质强健计划', '健康学校建设',
            '体教融合', '以体育人', '五育融合', '体育教师', '体育课时', '冰雪运动', '校园足球',
            '运动技能', '体质健康测试', '健康第一', '教育部', '体育总局', '卫健委', '财政部', '人社部',
            '体育传统项目', '体育特色学校', '体育后备人才', '体育竞赛', '体育场馆', '体育设施',
            '体育经费', '体育督导', '体育课程']
        for word in self.custom_words:
            jieba.add_word(word)

        self.stopwords = set(['的', '了', '和', '与', '或', '等', '对', '为', '将', '并', '也', '都',
            '印发', '通知', '意见', '各省', '自治区', '直辖市', '进一步', '加强', '完善', '建立',
            '健全', '推动', '促进', '实施', '落实', '开展', '根据', '按照', '参照', '有关', '相关',
            '各', '此', '该', '进行', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十',
            '法宝', '各地', '应当', '部门', '规定', '单位', '各级', '可以', '各区', '各市', '各类',
            '美育', '行政部门', '变迁', '普通', '相应', '管理工作', '制度', '基本', '全国', '探索',
            '项目', '建设', '体系', '开放', '督导', '情况', '学习', '北京市', '形成', '推进','提升',
            '上报', '办法', '文化', '体育局', '教育厅', '鼓励', '支持', '强化', '服务', '课程','积极',
            '结果', '责任', '培养', '培训', '社会', '训练', '重点', '教育部', '参与', '专业','科学',
            '每年', '国家', '保证', '安全', '阶段', '时代', '做好', '设置', '区域', '体育运动','教师',
            '规划', '数据', '普及', '足球', '评估', '政策', '全省', '国家体育总局', '校园', '实现','基础',
            '测试', '时间', '专项', '成绩', '加大', '公布', '监督', '具有', '坚持', '负责','地区','艺术',
            '单项', '指标', '能力', '目标', '内容', '传统', '人才', '国际', '师资', '竞赛','优秀','中等',
            ])
    def preprocess_text(self, text):
        if pd.isna(text) or not isinstance(text, str):
            return ""
        text = re.sub(r'[^\u4e00-\u9fff\s]', '', text)
        words = jieba.cut(text)
        filtered = [w for w in words if w not in self.stopwords and len(w) >= 2]
        return ' '.join(filtered)
    
    def prepare_corpus(self, df):
        print(f"\n预处理 {len(df)} 份文本...")
        df = df.copy()
        df['processed'] = df['content'].apply(self.preprocess_text)
        df['doc_length'] = df['processed'].apply(lambda x: len(x.split()))
        
        empty_docs = df[df['doc_length'] == 0]
        if len(empty_docs) > 0:
            print(f"  ⚠️ 发现 {len(empty_docs)} 份空文档，将填充占位文本")
            for idx in empty_docs.index:
                original = df.loc[idx, 'content']
                chinese_chars = re.findall(r'[\u4e00-\u9fff]', original)
                if chinese_chars:
                    placeholder = ''.join(chinese_chars[:50])
                else:
                    placeholder = "学校体育政策文件"
                df.loc[idx, 'processed'] = placeholder
                df.loc[idx, 'doc_length'] = len(placeholder.split())
        
        print(f"  文档长度分布: 最小值={df['doc_length'].min():.0f}词, "
              f"最大值={df['doc_length'].max():.0f}词, "
              f"平均值={df['doc_length'].mean():.1f}词")
        print(f"  ✅ 保留所有 {len(df)} 份文档")
        
        return df


# ==================== LDA主题建模 ====================

class LDATopicModeler:
    WEIGHTS = {'perplexity': 0.20, 'coherence': 0.50, 'distance': 0.30}
    
    def __init__(self, max_features=800, max_iter=200, random_state=42, invalid_threshold=0.02):
        self.max_features = max_features
        self.max_iter = max_iter
        self.random_state = random_state
        self.invalid_threshold = invalid_threshold
        self.vectorizer = None
        self.lda_model = None
        self.feature_names = None
        self.doc_topic_dist = None
        self.perplexities = []
        self.coherences = []
        self.distances = []
        self.k_range = []
        self.df_original = None
        self.n_topics = None
        self.document_indices = None
        self._was_filtered = False
    
    def vectorize(self, texts):
        self.vectorizer = CountVectorizer(max_features=self.max_features, min_df=2, max_df=0.85,
            token_pattern=r'(?u)\b\w+\b')
        dtm = self.vectorizer.fit_transform(texts)
        self.feature_names = self.vectorizer.get_feature_names_out()
        print(f"向量化：{dtm.shape[0]}文档，{dtm.shape[1]}特征词")
        return dtm
    
    def _calculate_coherence(self, lda, dtm):
        n_top_words = 8
        topic_top_words = []
        for topic_idx, topic in enumerate(lda.components_):
            top_words_idx = topic.argsort()[-n_top_words:][::-1]
            top_words = [self.feature_names[i] for i in top_words_idx]
            topic_top_words.append(top_words)
        
        all_texts = self.vectorizer.inverse_transform(dtm)
        
        coherences = []
        for words in topic_top_words:
            if len(words) < 2:
                coherences.append(0)
                continue
            score = 0
            pair_count = 0
            for i in range(len(words)):
                for j in range(i+1, len(words)):
                    pair_count += 1
                    count = 0
                    for doc in all_texts:
                        if words[i] in doc and words[j] in doc:
                            count += 1
                    score += count
            coherences.append(score / (pair_count * len(all_texts)) if pair_count > 0 else 0)
        return np.mean(coherences) if coherences else 0.5
    
    def _calculate_topic_distance(self, lda):
        topic_vectors = lda.components_
        sim_matrix = cosine_similarity(topic_vectors)
        n = sim_matrix.shape[0]
        if n <= 1:
            return 1.0
        np.fill_diagonal(sim_matrix, 0)
        avg_similarity = sim_matrix.sum() / (n * (n - 1))
        return 1 - avg_similarity
    
    def _calculate_perplexity(self, lda, dtm):
        return lda.perplexity(dtm)
    
    def _normalize_scores(self, values, reverse=False):
        values = np.array(values)
        if values.max() == values.min():
            return np.zeros_like(values)
        norm = (values - values.min()) / (values.max() - values.min())
        return 1 - norm if reverse else norm
    
    def check_invalid_topics(self, topic_strengths):
        invalid_indices = [i for i, s in enumerate(topic_strengths) if s < self.invalid_threshold]
        return len(invalid_indices) > 0, invalid_indices
    
    def test_multiple_seeds(self, texts, n_topics, seeds=[42, 123, 456, 789, 1024]):
        print(f"\n测试多个随机种子（主题数={n_topics}）")
        seed_results = []
        dtm = self.vectorize(texts)
        for seed in seeds:
            lda = LatentDirichletAllocation(n_components=n_topics, random_state=seed,
                max_iter=self.max_iter, learning_method='batch',
                doc_topic_prior=0.1, topic_word_prior=0.01)
            doc_topic_dist = lda.fit_transform(dtm)
            topic_strengths = doc_topic_dist.mean(axis=0)
            has_invalid, invalid_indices = self.check_invalid_topics(topic_strengths)
            coherence = self._calculate_coherence(lda, dtm)
            distance = self._calculate_topic_distance(lda)
            perplexity = lda.perplexity(dtm)
            topic_probs = topic_strengths / (topic_strengths.sum() + 1e-10)
            entropy = -np.sum(topic_probs * np.log(topic_probs + 1e-10))
            max_entropy = np.log(len(topic_probs))
            diversity = entropy / max_entropy if max_entropy > 0 else 0
            seed_results.append({'seed': seed, 'lda': lda, 'doc_topic_dist': doc_topic_dist,
                'topic_strengths': topic_strengths, 'has_invalid': has_invalid,
                'invalid_indices': invalid_indices, 'coherence': coherence, 'distance': distance,
                'perplexity': perplexity, 'diversity': diversity})
        valid_results = [r for r in seed_results if not r['has_invalid']]
        if valid_results:
            best_result = max(valid_results, key=lambda x: (x['diversity'], x['coherence'], x['distance']))
        else:
            best_result = min(seed_results, key=lambda x: len(x['invalid_indices']))
        print(f"✓ 选择最优种子: {best_result['seed']}")
        self.lda_model = best_result['lda']
        self.doc_topic_dist = best_result['doc_topic_dist']
        self.random_state = best_result['seed']
        return best_result['seed'], best_result, seed_results
    
    def find_optimal_topics(self, texts, min_topics, max_topics, corpus_name="",
                           seeds=[42, 123, 456, 789, 1024]):
        dtm = self.vectorize(texts)
        topic_range = range(min_topics, max_topics + 1)
        all_results = []
        print(f"\n{corpus_name}主题数寻优（{min_topics}-{max_topics}）")
        for k in topic_range:
            print(f"\n--- 测试 K={k} ---")
            best_k_result, best_k_score = None, -1
            for seed in seeds:
                lda = LatentDirichletAllocation(n_components=k, random_state=seed,
                    max_iter=self.max_iter, learning_method='batch')
                lda.fit(dtm)
                perplexity = self._calculate_perplexity(lda, dtm)
                coherence = self._calculate_coherence(lda, dtm)
                distance = self._calculate_topic_distance(lda)
                p_norm = self._normalize_scores([perplexity], reverse=True)[0]
                score = (self.WEIGHTS['perplexity'] * p_norm + self.WEIGHTS['coherence'] * coherence +
                        self.WEIGHTS['distance'] * distance)
                if score > best_k_score:
                    best_k_score = score
                    best_k_result = {'k': k, 'seed': seed, 'perplexity': perplexity,
                        'coherence': coherence, 'distance': distance, 'score': score,
                        'lda': lda, 'doc_topic_dist': lda.transform(dtm)}
            all_results.append(best_k_result)
            print(f"  K={k} 最优: 种子={best_k_result['seed']}, 困惑度={best_k_result['perplexity']:.2f}, "
                  f"一致性={best_k_result['coherence']:.3f}, 区分度={best_k_result['distance']:.3f}")
        best_overall = max(all_results, key=lambda x: x['score'])
        optimal_k = best_overall['k']
        
        self.lda_model = best_overall['lda']
        self.doc_topic_dist = best_overall['doc_topic_dist']
        self.n_topics = optimal_k
        self.random_state = best_overall['seed']
        
        print(f"\n推荐主题数: K={optimal_k}")
        self.perplexities = [r['perplexity'] for r in all_results]
        self.coherences = [r['coherence'] for r in all_results]
        self.distances = [r['distance'] for r in all_results]
        self.k_range = list(topic_range)
        self.optimal_k = optimal_k
        return optimal_k
    
    def plot_metrics_curves(self, output_path, corpus_name):
        if len(self.perplexities) == 0:
            return
        main_color = COLORS['central'] if '中央' in corpus_name else COLORS['local']
        fig, axes = plt.subplots(1, 3, figsize=(15, 4))
        
        axes[0].plot(self.k_range, self.perplexities, 'o-', color=main_color, linewidth=2, markersize=8)
        axes[0].set_xlabel('主题数 K')
        axes[0].set_ylabel('困惑度')
        axes[0].set_title('困惑度曲线')
        axes[0].grid(True, alpha=0.3)
        
        axes[1].plot(self.k_range, self.coherences, 'o-', color=main_color, linewidth=2, markersize=8)
        axes[1].set_xlabel('主题数 K')
        axes[1].set_ylabel('主题一致性')
        axes[1].set_title('主题一致性曲线')
        axes[1].grid(True, alpha=0.3)
        
        axes[2].plot(self.k_range, self.distances, 'o-', color=main_color, linewidth=2, markersize=8)
        axes[2].set_xlabel('主题数 K')
        axes[2].set_ylabel('主题区分度')
        axes[2].set_title('主题区分度曲线')
        axes[2].grid(True, alpha=0.3)
        
        plt.suptitle(f'{corpus_name} - 三项评估指标曲线')
        plt.tight_layout()
        safe_name = corpus_name.replace(' ', '_')
        fig.savefig(os.path.join(output_path, f'00_评估曲线_{safe_name}.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print(f"评估曲线已保存: 00_评估曲线_{safe_name}.png")
    
    def train(self, texts, n_topics, seeds=[42, 123, 456, 789, 1024], auto_select_best=True, df_original=None):
        self.n_topics = n_topics
        self.df_original = df_original
        
        if df_original is not None:
            self.document_indices = df_original.index.tolist()
        else:
            self.document_indices = list(range(len(texts)))
        
        if auto_select_best:
            best_seed, best_result, _ = self.test_multiple_seeds(texts, n_topics, seeds)
            self.random_state = best_seed
        else:
            dtm = self.vectorize(texts)
            self.lda_model = LatentDirichletAllocation(n_components=n_topics, random_state=self.random_state,
                max_iter=self.max_iter, learning_method='batch',
                doc_topic_prior=0.1, topic_word_prior=0.01)
            self.doc_topic_dist = self.lda_model.fit_transform(dtm)
        print(f"LDA训练完成：{n_topics}个主题")
        return self.doc_topic_dist
    
    def get_top_words(self, n_words=8):
        if self.lda_model is None:
            return {}
        topic_words = {}
        for idx, topic in enumerate(self.lda_model.components_):
            top_idx = topic.argsort()[-n_words:][::-1]
            words = [self.feature_names[i] for i in top_idx]
            scores = [topic[i] for i in top_idx]
            topic_words[f"Topic_{idx+1}"] = list(zip(words, scores))
        return topic_words
    
    def get_topic_strength(self):
        if self.doc_topic_dist is None:
            return np.array([])
        return self.doc_topic_dist.mean(axis=0)
    
    def get_topic_strength_weighted(self):
        if self.df_original is None or self.doc_topic_dist is None:
            return self.get_topic_strength()
        
        doc_lengths = self.df_original['doc_length'].values
        if doc_lengths.sum() == 0:
            return self.get_topic_strength()
        
        weights = doc_lengths / doc_lengths.sum()
        weighted_strength = np.average(self.doc_topic_dist, axis=0, weights=weights)
        
        if np.isnan(weighted_strength).any():
            return self.get_topic_strength()
        
        return weighted_strength
    
    def get_yearly_topic_strengths(self):
        if self.df_original is None:
            return None, None
        
        doc_topic_matrix = self.doc_topic_dist
        n_topics = self.n_topics
        
        all_years = set()
        doc_year_weights = []
        
        for idx, (_, row) in enumerate(self.df_original.iterrows()):
            filename = row.get('title', '')
            years_covered = row.get('years_covered', [])
            if not years_covered:
                years_covered = [row.get('year')] if row.get('year') else []
            
            if years_covered:
                weight_per_year = 1.0 / len(years_covered)
                year_weights = {year: weight_per_year for year in years_covered}
                doc_year_weights.append(year_weights)
                all_years.update(years_covered)
            else:
                doc_year_weights.append({})
        
        unique_years = sorted([y for y in all_years if y is not None])
        
        if not unique_years:
            return None, None
        
        doc_lengths = self.df_original['doc_length'].values
        if doc_lengths.sum() > 0:
            doc_weights = doc_lengths / doc_lengths.sum()
        else:
            doc_weights = np.ones(len(doc_topic_matrix)) / len(doc_topic_matrix)
        
        yearly_strengths = []
        for year in unique_years:
            year_strength = np.zeros(n_topics)
            total_weight = 0
            for doc_idx, year_weights in enumerate(doc_year_weights):
                weight = year_weights.get(year, 0) * doc_weights[doc_idx]
                if weight > 0:
                    year_strength += doc_topic_matrix[doc_idx] * weight
                    total_weight += weight
            if total_weight > 0:
                year_strength /= total_weight
            yearly_strengths.append(year_strength)
        
        return unique_years, np.array(yearly_strengths)


# ==================== BTM匹配 ====================

class BTMMatcher:
    def __init__(self, threshold=0.10, secondary_check_threshold=0.08, use_synonyms=True):
        self.threshold = threshold
        self.secondary_check_threshold = secondary_check_threshold
        self.use_synonyms = use_synonyms
        self.quality_thresholds = MATCH_QUALITY
    
    def get_match_quality(self, score: float) -> str:
        if score >= self.quality_thresholds['high']:
            return 'high'
        elif score >= self.quality_thresholds['medium']:
            return 'medium'
        elif score >= self.threshold:
            return 'low'
        else:
            return 'none'
    
    def find_matching_pairs(self, central_model, local_model):
        print("\n执行BTM双向匹配...")
        
        central_features = set(central_model.feature_names)
        local_features = set(local_model.feature_names)
        
        common_features = list(central_features.intersection(local_features))
        print(f"共同特征词数量: {len(common_features)}")
        
        if len(common_features) == 0:
            print("⚠️ 警告：无共同特征词，无法计算主题相似度")
            matching_pairs = []
            for c in range(central_model.n_topics):
                matching_pairs.append({
                    'central_topic': c,
                    'local_topic': None,
                    'match_score': 0,
                    'match_type': 'central_only',
                    'match_quality': 'none'
                })
            for l in range(local_model.n_topics):
                matching_pairs.append({
                    'central_topic': None,
                    'local_topic': l,
                    'match_score': 0,
                    'match_type': 'local_only',
                    'match_quality': 'none'
                })
            similarity_matrix = np.zeros((central_model.n_topics, local_model.n_topics))
            return matching_pairs, similarity_matrix
        
        central_idx = {f: i for i, f in enumerate(central_model.feature_names)}
        local_idx = {f: i for i, f in enumerate(local_model.feature_names)}
        
        central_vectors = np.zeros((central_model.n_topics, len(common_features)))
        local_vectors = np.zeros((local_model.n_topics, len(common_features)))
        
        for j, feat in enumerate(common_features):
            if feat in central_idx:
                central_vectors[:, j] = central_model.lda_model.components_[:, central_idx[feat]]
            else:
                central_vectors[:, j] = 0
            
            if feat in local_idx:
                local_vectors[:, j] = local_model.lda_model.components_[:, local_idx[feat]]
            else:
                local_vectors[:, j] = 0
        
        central_vectors = normalize(central_vectors, norm='l2')
        local_vectors = normalize(local_vectors, norm='l2')
        
        similarity_matrix = cosine_similarity(central_vectors, local_vectors)
        
        if HAS_SCIPY:
            n_central, n_local = similarity_matrix.shape
            if n_central <= n_local:
                cost_matrix = -similarity_matrix
                row_ind, col_ind = linear_sum_assignment(cost_matrix)
                matched_pairs = list(zip(row_ind, col_ind))
            else:
                cost_matrix = -similarity_matrix.T
                row_ind, col_ind = linear_sum_assignment(cost_matrix)
                matched_pairs = [(col_ind[i], row_ind[i]) for i in range(len(row_ind))]
            
            matching_pairs = []
            matched_central = set()
            matched_local = set()
            
            for c, l in matched_pairs:
                score = similarity_matrix[c, l]
                quality = self.get_match_quality(score)
                if score >= self.threshold:
                    matching_pairs.append({
                        'central_topic': c,
                        'local_topic': l,
                        'match_score': score,
                        'match_type': 'matched',
                        'match_quality': quality
                    })
                    matched_central.add(c)
                    matched_local.add(l)
                else:
                    matching_pairs.append({
                        'central_topic': c,
                        'local_topic': None,
                        'match_score': score,
                        'match_type': 'central_only',
                        'match_quality': quality
                    })
                    matched_central.add(c)
            
            for c in range(central_model.n_topics):
                if c not in matched_central:
                    scores = similarity_matrix[c, :]
                    sorted_indices = np.argsort(scores)[::-1]
                    
                    best_score = scores[sorted_indices[0]]
                    best_l = sorted_indices[0]
                    
                    quality = self.get_match_quality(best_score)
                    
                    if best_score >= self.threshold:
                        if best_l not in matched_local:
                            matching_pairs.append({
                                'central_topic': c,
                                'local_topic': best_l,
                                'match_score': best_score,
                                'match_type': 'matched',
                                'match_quality': quality
                            })
                            matched_central.add(c)
                            matched_local.add(best_l)
                        else:
                            matching_pairs.append({
                                'central_topic': c,
                                'local_topic': None,
                                'match_score': best_score,
                                'match_type': 'central_only',
                                'match_quality': quality
                            })
                            matched_central.add(c)
                    else:
                        matching_pairs.append({
                            'central_topic': c,
                            'local_topic': None,
                            'match_score': best_score,
                            'match_type': 'central_only',
                            'match_quality': quality
                        })
                        matched_central.add(c)
            
            for l in range(local_model.n_topics):
                if l not in matched_local:
                    scores = similarity_matrix[:, l]
                    best_score = scores.max()
                    quality = self.get_match_quality(best_score)
                    matching_pairs.append({
                        'central_topic': None,
                        'local_topic': l,
                        'match_score': best_score,
                        'match_type': 'local_only',
                        'match_quality': quality
                    })
                    matched_local.add(l)
        else:
            print("⚠️ 使用贪心匹配算法")
            matching_pairs = []
            for c in range(central_model.n_topics):
                best = np.argmax(similarity_matrix[c, :])
                score = similarity_matrix[c, best]
                quality = self.get_match_quality(score)
                if score >= self.threshold:
                    matching_pairs.append({
                        'central_topic': c,
                        'local_topic': best,
                        'match_score': score,
                        'match_type': 'matched',
                        'match_quality': quality
                    })
                else:
                    matching_pairs.append({
                        'central_topic': c,
                        'local_topic': None,
                        'match_score': score,
                        'match_type': 'central_only',
                        'match_quality': quality
                    })
            
            matched_local = set([p['local_topic'] for p in matching_pairs if p['local_topic'] is not None])
            for l in range(local_model.n_topics):
                if l not in matched_local:
                    score = similarity_matrix[:, l].max()
                    quality = self.get_match_quality(score)
                    matching_pairs.append({
                        'central_topic': None,
                        'local_topic': l,
                        'match_score': score,
                        'match_type': 'local_only',
                        'match_quality': quality
                    })
        
        matched_count = len([p for p in matching_pairs if p['match_type'] == 'matched'])
        high_quality_count = len([p for p in matching_pairs if p.get('match_quality') == 'high'])
        print(f"匹配结果: {matched_count} 对匹配成功（高质量: {high_quality_count}）")
        return matching_pairs, similarity_matrix


# ==================== 协同分析 ====================

class SynergyAnalyzer:
    def __init__(self, output_path):
        self.output_path = output_path
    
    def classify_synergy_type(self, diff: float) -> str:
        abs_diff = abs(diff)
        if abs_diff < 0.10:
            return '高度协同'
        elif diff >= 0.15:
            return '地方强化'
        elif diff <= -0.15:
            return '地方衰减'
        elif diff > 0:
            return '地方关注'
        else:
            return '中央主导'
    
    def compute_synergy_metrics(self, matching_pairs, central_strength, local_strength):
        results = []
        for pair in matching_pairs:
            if pair['match_type'] == 'matched':
                c_strength = central_strength[pair['central_topic']]
                l_strength = local_strength[pair['local_topic']]
                diff = l_strength - c_strength
                synergy_type = self.classify_synergy_type(diff)
                results.append({
                    'central_topic_id': pair['central_topic'],
                    'local_topic_id': pair['local_topic'],
                    'match_score': pair['match_score'],
                    'match_quality': pair.get('match_quality', 'unknown'),
                    'central_strength': c_strength,
                    'local_strength': l_strength,
                    'strength_diff': diff,
                    'synergy_type': synergy_type
                })
            elif pair['match_type'] == 'central_only':
                results.append({
                    'central_topic_id': pair['central_topic'],
                    'local_topic_id': None,
                    'match_score': pair['match_score'],
                    'match_quality': pair.get('match_quality', 'unknown'),
                    'central_strength': central_strength[pair['central_topic']],
                    'local_strength': 0,
                    'strength_diff': -central_strength[pair['central_topic']],
                    'synergy_type': '中央特有'
                })
            else:
                results.append({
                    'central_topic_id': None,
                    'local_topic_id': pair['local_topic'],
                    'match_score': pair['match_score'],
                    'match_quality': pair.get('match_quality', 'unknown'),
                    'central_strength': 0,
                    'local_strength': local_strength[pair['local_topic']],
                    'strength_diff': local_strength[pair['local_topic']],
                    'synergy_type': '地方创新'
                })
        return pd.DataFrame(results)
    
    def calculate_comprehensive_synergy_index(self, synergy_df):
        matched_df = synergy_df[synergy_df['synergy_type'].isin(MATCHED_SYNERGY_TYPES)]
        if len(matched_df) == 0:
            return 0.5
        
        synergy_scores = {'高度协同': 1.0, '地方强化': 0.85, 
                          '地方关注': 0.75, '中央主导': 0.65, '地方衰减': 0.55}
        
        matched_df_copy = matched_df.copy()
        matched_df_copy['synergy_score'] = matched_df_copy['synergy_type'].map(synergy_scores)
        matched_df_copy['quality_score'] = matched_df_copy['match_quality'].map(QUALITY_SCORES)
        
        matched_df_copy['score'] = (
            COMPREHENSIVE_SCORE_WEIGHTS['synergy_type_weight'] * matched_df_copy['synergy_score'] +
            COMPREHENSIVE_SCORE_WEIGHTS['match_quality_weight'] * matched_df_copy['quality_score']
        )
        
        match_scores = matched_df_copy['match_score'].values
        if len(match_scores) > 0 and match_scores.std() > 0:
            weights = match_scores / match_scores.sum()
            comprehensive_score = np.sum(matched_df_copy['score'].values * weights)
        else:
            comprehensive_score = matched_df_copy['score'].mean()
        
        return comprehensive_score


# ==================== 时间段分析 ====================

class TimePeriodAnalyzer:
    def __init__(self, output_path):
        self.output_path = output_path
    
    def calculate_period_topic_strengths(self, doc_topic_matrix, doc_years_covered, periods, doc_weights=None):
        results = {}
        n_topics = doc_topic_matrix.shape[1]
        topic_names = [f"T{i+1}" for i in range(n_topics)]
        
        if doc_weights is None:
            doc_weights = np.ones(len(doc_topic_matrix)) / len(doc_topic_matrix)
        
        for period in periods:
            period_name = period['name']
            years_set = set(period['years'])
            
            period_strength = np.zeros(n_topics)
            total_weight = 0
            
            for doc_idx in range(len(doc_topic_matrix)):
                years_covered = doc_years_covered[doc_idx] if doc_idx < len(doc_years_covered) else []
                
                overlapping_years = [y for y in years_covered if y in years_set]
                if overlapping_years:
                    year_fraction = len(overlapping_years) / len(years_covered) if years_covered else 1.0
                    doc_contrib_weight = year_fraction * doc_weights[doc_idx]
                    period_strength += doc_topic_matrix[doc_idx] * doc_contrib_weight
                    total_weight += doc_contrib_weight
            
            if total_weight > 0:
                period_strength /= total_weight
            
            results[period_name] = {topic_names[i]: period_strength[i] for i in range(n_topics)}
        
        return pd.DataFrame(results).T
    
    def extract_document_data(self, model, df):
        if model is None or df is None or model.doc_topic_dist is None:
            return None, None, None
        
        doc_topic_matrix = model.doc_topic_dist
        doc_years_covered = []
        
        doc_weights = df['doc_length'].values if 'doc_length' in df.columns else None
        if doc_weights is not None and doc_weights.sum() > 0:
            doc_weights = doc_weights / doc_weights.sum()
        else:
            doc_weights = np.ones(len(doc_topic_matrix)) / len(doc_topic_matrix)
        
        for i, (_, row) in enumerate(df.iterrows()):
            filename = row.get('title', '')
            years_covered = row.get('years_covered', [])
            if not years_covered:
                year_val = row.get('year')
                if year_val:
                    years_covered = [year_val]
            doc_years_covered.append(years_covered)
        
        return doc_topic_matrix, doc_years_covered, doc_weights
    
    def run_analysis(self, central_model, local_model, central_df, local_df):
        print("\n开始时间段主题强度分析")
        print("时间段：2011-2025、2011-2015、2016-2020、2021-2025")
        
        periods = [
            {'name': '2011-2025', 'years': list(range(2011, 2026))},
            {'name': '2011-2015', 'years': list(range(2011, 2016))},
            {'name': '2016-2020', 'years': list(range(2016, 2021))},
            {'name': '2021-2025', 'years': list(range(2021, 2026))}
        ]
        
        central_data = self.extract_document_data(central_model, central_df)
        local_data = self.extract_document_data(local_model, local_df)
        
        if central_data[0] is None or local_data[0] is None:
            print("警告：无法提取文档数据，跳过时间段分析")
            return
        
        central_doc_topic, central_years_covered, central_weights = central_data
        local_doc_topic, local_years_covered, local_weights = local_data
        
        central_period_df = self.calculate_period_topic_strengths(
            central_doc_topic, central_years_covered, periods, central_weights
        )
        local_period_df = self.calculate_period_topic_strengths(
            local_doc_topic, local_years_covered, periods, local_weights
        )
        
        central_columns = {f"T{i+1}": f"C{i+1}" for i in range(central_model.n_topics)}
        local_columns = {f"T{i+1}": f"L{i+1}" for i in range(local_model.n_topics)}
        central_period_df = central_period_df.rename(columns=central_columns)
        local_period_df = local_period_df.rename(columns=local_columns)
        
        self.plot_period_heatmap(central_period_df, local_period_df)
        self.export_period_tables(central_period_df, local_period_df)
        
        print("\n" + "=" * 60)
        print("时间段主题强度分析完成！")
        print("=" * 60)
    
    def plot_period_heatmap(self, central_period_df, local_period_df):
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        sns.heatmap(central_period_df, annot=True, cmap='Blues', fmt='.4f', ax=axes[0], square=True)
        axes[0].set_title('中央政策 - 各时间段主题强度')
        sns.heatmap(local_period_df, annot=True, cmap='Greens', fmt='.4f', ax=axes[1], square=True)
        axes[1].set_title('地方政策 - 各时间段主题强度')
        plt.suptitle('央地政策时间段主题强度对比')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, 'period_strength_heatmap.png'), dpi=1000, bbox_inches='tight')
        plt.close()
    
    def export_period_tables(self, central_period_df, local_period_df):
        output_excel = os.path.join(self.output_path, 'period_strength_tables.xlsx')
        with pd.ExcelWriter(output_excel, engine='openpyxl') as writer:
            central_period_df.T.to_excel(writer, sheet_name='中央主题_时间段强度')
            local_period_df.T.to_excel(writer, sheet_name='地方主题_时间段强度')
            note_df = pd.DataFrame({
                '说明': ['数据时间范围说明', '时间段说明', '计算方法说明'],
                '备注': ['2011-2025年为完整年度数据', 
                        '四个时间段：2011-2025、2011-2015、2016-2020、2021-2025',
                        '跨年政策权重均摊到所有覆盖年份']
            })
            note_df.to_excel(writer, sheet_name='数据说明', index=False)
        print(f"时间段强度表已导出: {output_excel}")


# ==================== 主题可视化 ====================

class ThemeVisualizer:
    def __init__(self, output_path):
        self.output_path = output_path
    
    def plot_cross_comparison_curves(self, central_modeler, local_modeler):
        fig, axes = plt.subplots(1, 3, figsize=(20, 6))
    
        ax1 = axes[0]
        ax1.plot(central_modeler.k_range, central_modeler.perplexities, 'o-', 
            color=COLORS['central'], linewidth=2, markersize=8, label='Central Policy')
        ax1.plot(local_modeler.k_range, local_modeler.perplexities, 's-', 
            color=COLORS['local'], linewidth=2, markersize=8, label='Local Policy')
        ax1.set_xlabel('Number of Topics (K)')
        ax1.set_ylabel('Perplexity')
        ax1.set_title('Perplexity Comparison')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
    
        ax2 = axes[1]
        ax2.plot(central_modeler.k_range, central_modeler.coherences, 'o-', 
            color=COLORS['central'], linewidth=2, markersize=8, label='Central Policy')
        ax2.plot(local_modeler.k_range, local_modeler.coherences, 's-', 
            color=COLORS['local'], linewidth=2, markersize=8, label='Local Policy')
        ax2.set_xlabel('Number of Topics (K)')
        ax2.set_ylabel('Topic Coherence')
        ax2.set_title('Topic Coherence Comparison')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
    
        ax3 = axes[2]
        ax3.plot(central_modeler.k_range, central_modeler.distances, 'o-', 
            color=COLORS['central'], linewidth=2, markersize=8, label='Central Policy')
        ax3.plot(local_modeler.k_range, local_modeler.distances, 's-', 
            color=COLORS['local'], linewidth=2, markersize=8, label='Local Policy')
        ax3.set_xlabel('Number of Topics (K)')
        ax3.set_ylabel('Topic Distance')
        ax3.set_title('Topic Distance Comparison')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
    
        plt.suptitle('Central-Local Policy Evaluation Metrics Comparison')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, '00_央地评估指标对比曲线.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("Central-Local evaluation metrics comparison saved")
    
    def plot_similarity_heatmap(self, similarity_matrix):
        if similarity_matrix is None or similarity_matrix.size == 0:
            return
    
        fig, ax = plt.subplots(figsize=(18, 14))
        im = ax.imshow(similarity_matrix, cmap='RdYlBu_r', aspect='auto', vmin=0, vmax=1)
    
        n_central = similarity_matrix.shape[0]
        n_local = similarity_matrix.shape[1]
        FONT_SIZE = 20
    
        ax.set_xticks(range(n_local))
        ax.set_yticks(range(n_central))
        ax.set_xticklabels([f"L{i+1}" for i in range(n_local)], fontsize=FONT_SIZE)
        ax.set_yticklabels([f"C{i+1}" for i in range(n_central)], fontsize=FONT_SIZE)
    
        ax.set_xlabel('Local Policy Topics', fontsize=FONT_SIZE, fontweight='bold')
        ax.set_ylabel('Central Policy Topics', fontsize=FONT_SIZE, fontweight='bold')
        ax.set_title('Central-Local Topic Matching Heatmap', fontsize=FONT_SIZE, fontweight='bold')
    
        cbar = plt.colorbar(im, ax=ax, label='Matching Strength')
        cbar.ax.set_ylabel('Matching Strength', fontsize=FONT_SIZE)
        cbar.ax.tick_params(labelsize=FONT_SIZE)
    
        for i in range(n_central):
            for j in range(n_local):
                value = similarity_matrix[i, j]
                text_color = 'white' if value > 0.6 else 'black'
                ax.text(j, i, f'{value:.3f}', ha='center', va='center',
                   fontsize=FONT_SIZE, fontweight='bold', color=text_color)
    
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, '04_主题匹配热力图.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("Topic Matching Heatmap saved (all fonts size 20)")
    
    def plot_yearly_topic_matrices(self, central_model, local_model):
        """绘制央地主题年度强度矩阵热力图"""
        central_years, central_yearly = central_model.get_yearly_topic_strengths()
        local_years, local_yearly = local_model.get_yearly_topic_strengths()
        if central_years is None or local_years is None:
            return
        
        central_topic_names = [f"C{i+1}" for i in range(central_model.n_topics)]
        local_topic_names = [f"L{i+1}" for i in range(local_model.n_topics)]
        all_years = list(range(2011, 2026))
        
        # ========== 构建数据矩阵 ==========
        central_full_matrix = []
        for i in range(len(central_topic_names)):
            row = []
            for year in all_years:
                if year in central_years:
                    idx = list(central_years).index(year)
                    row.append(central_yearly[idx, i])
                else:
                    row.append(np.nan)
            central_full_matrix.append(row)
        
        local_full_matrix = []
        for i in range(len(local_topic_names)):
            row = []
            for year in all_years:
                if year in local_years:
                    idx = list(local_years).index(year)
                    row.append(local_yearly[idx, i])
                else:
                    row.append(np.nan)
            local_full_matrix.append(row)
        
        df_central = pd.DataFrame(central_full_matrix, index=central_topic_names, columns=all_years)
        df_local = pd.DataFrame(local_full_matrix, index=local_topic_names, columns=all_years)
        
        fig, axes = plt.subplots(1, 2, figsize=(18, max(8, max(central_model.n_topics, local_model.n_topics) * 0.5)))
        
        # ========== 中央热力图 ==========
        sns.heatmap(df_central, annot=True, cmap='Blues', fmt='.3f',
                    cbar_kws={'label': 'Topic Strength'}, ax=axes[0],
                    linewidths=0.5, square=False, vmin=0, vmax=1)
        axes[0].set_title(f'Central Topic Matrix ({central_model.n_topics} Topics)', fontsize=20, fontweight='bold')
        axes[0].set_xlabel('Year', fontsize=20, fontweight='bold')
        axes[0].set_ylabel('Topic', fontsize=20, fontweight='bold')
        axes[0].set_yticklabels(axes[0].get_yticklabels(), fontsize=20, fontweight='bold')
        axes[0].set_xticklabels(axes[0].get_xticklabels(), fontweight='bold')
        for text in axes[0].texts:
            text.set_fontweight('bold')
        cbar = axes[0].collections[0].colorbar
        cbar.set_label('Topic Strength', fontsize=20, fontweight='bold')
        cbar.ax.tick_params(labelsize=20, width=2)
        for label in cbar.ax.get_yticklabels():
            label.set_fontweight('bold')
        
        # ========== 地方热力图 ==========
        sns.heatmap(df_local, annot=True, cmap='Greens', fmt='.3f',
                    cbar_kws={'label': 'Topic Strength'}, ax=axes[1],
                    linewidths=0.5, square=False, vmin=0, vmax=1)
        axes[1].set_title(f'Local Topic Matrix ({local_model.n_topics} Topics)', fontsize=20, fontweight='bold')
        axes[1].set_xlabel('Year', fontsize=20, fontweight='bold')
        axes[1].set_ylabel('Topic', fontsize=20, fontweight='bold')
        axes[1].set_yticklabels(axes[1].get_yticklabels(), fontsize=20, fontweight='bold')
        axes[1].set_xticklabels(axes[1].get_xticklabels(), fontweight='bold')
        for text in axes[1].texts:
            text.set_fontweight('bold')
        cbar = axes[1].collections[0].colorbar
        cbar.set_label('Topic Strength', fontsize=20, fontweight='bold')
        cbar.ax.tick_params(labelsize=20, width=2)
        for label in cbar.ax.get_yticklabels():
            label.set_fontweight('bold')
        
        plt.suptitle('Central vs Local Topic Strength Matrix (2011-2025)', fontsize=20, fontweight='bold')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, 'central_vs_local_matrix.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("central_vs_local_matrix.png saved (English labels, fonts 20 bold)")
    
    def plot_synergy_network(self, synergy_df, central_strengths, local_strengths):
        fig, ax = plt.subplots(figsize=(14, 10))
        n_central, n_local = len(central_strengths), len(local_strengths)
        central_themes = [f"C{i+1}" for i in range(n_central)]
        local_themes = [f"L{i+1}" for i in range(n_local)]
        central_pos = {f"C{i+1}": (0, (n_central-1)*2/2 - i*2) for i in range(n_central)}
        local_pos = {f"L{i+1}": (4, (n_local-1)*1.8/2 - i*1.8) for i in range(n_local)}
        all_pos = {**central_pos, **local_pos}
        
        for node, (x, y) in central_pos.items():
            circle = plt.Circle((x, y), 0.4, color='#2c7bb6', ec='white', linewidth=2, zorder=2)
            ax.add_patch(circle)
            ax.text(x, y, node, ha='center', va='center', fontsize=14, fontweight='bold', color='white')
        for node, (x, y) in local_pos.items():
            circle = plt.Circle((x, y), 0.4, color='#d7191c', ec='white', linewidth=2, zorder=2)
            ax.add_patch(circle)
            ax.text(x, y, node, ha='center', va='center', fontsize=14, fontweight='bold', color='white')
        
        for _, row in synergy_df.iterrows():
            if pd.notna(row['central_topic_id']) and pd.notna(row['local_topic_id']):
                u, v = f"C{int(row['central_topic_id'])+1}", f"L{int(row['local_topic_id'])+1}"
                if u in all_pos and v in all_pos:
                    x1, y1 = all_pos[u]; x2, y2 = all_pos[v]
                    if row['synergy_type'] == '高度协同':
                        color = '#2ecc71'
                    elif row['synergy_type'] == '中央主导':
                        color = '#95a5a6'
                    elif row['synergy_type'] == '地方衰减':
                        color = '#e74c3c'
                    elif row['synergy_type'] == '地方关注':
                        color = '#3498db'
                    else:
                        color = '#e67e22'
                    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                               arrowprops=dict(arrowstyle='->', color=color, lw=2.5, alpha=0.8))
        
        ax.set_xlim(-1, 5)
        ax.set_ylim(-5, 5)
        ax.axis('off')
        ax.set_title('Central-Local Policy Topic Synergy Network')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, '10_央地协同关系网络图.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("Central-Local synergy network saved")
    
    def plot_synergy_distribution(self, synergy_df):
        fig, axes = plt.subplots(1, 2, figsize=(18, 8))
        
        matched_df = synergy_df[synergy_df['central_topic_id'].notna() & synergy_df['local_topic_id'].notna()]
        type_counts = matched_df['synergy_type'].value_counts().to_dict()
        
        type_labels_en = {
            '高度协同': 'High Synergy',
            '地方强化': 'Local Strengthening', 
            '地方衰减': 'Local Attenuation',
            '地方关注': 'Local Focus',
            '中央主导': 'Central Dominance',
            '地方创新': 'Local Innovation',
            '中央特有': 'Central Unique'
        }
        
        labels = [type_labels_en.get(k, k) for k in type_counts.keys()]
        colors = [SYNERGY_COLORS.get(t, '#cccccc') for t in type_counts.keys()]
        
        axes[0].pie(list(type_counts.values()), 
                    labels=labels,
                    colors=colors,
                    autopct='%1.1f%%', startangle=90)
        axes[0].set_title('Intergovernmental Synergy Distribution')
        
        if len(matched_df) > 0:
            topics, diffs = [], []
            for _, row in matched_df.iterrows():
                topics.append(f"C{int(row['central_topic_id'])+1}")
                diffs.append(row['strength_diff'])
            
            colors_bar = []
            for d in diffs:
                if abs(d) < 0.10:
                    colors_bar.append('#2ecc71')
                elif d >= 0.15:
                    colors_bar.append('#e67e22')
                elif d <= -0.15:
                    colors_bar.append('#e74c3c')
                elif d > 0:
                    colors_bar.append('#3498db')
                else:
                    colors_bar.append('#95a5a6')
            
            axes[1].barh(topics, diffs, color=colors_bar, edgecolor='white', height=0.6)
            axes[1].axvline(x=0, color='black', linewidth=1.5)
            axes[1].set_xlabel('Strength Difference (Local - Central)')
            axes[1].set_ylabel('Central Policy Topics')
            axes[1].set_title('Central-Local Topic Strength Difference')
            axes[1].axvline(x=0.10, color='#2ecc71', linestyle='--', alpha=0.6)
            axes[1].axvline(x=-0.10, color='#2ecc71', linestyle='--', alpha=0.6)
            axes[1].axvline(x=0.15, color='#e67e22', linestyle=':', alpha=0.6)
            axes[1].axvline(x=-0.15, color='#e74c3c', linestyle=':', alpha=0.6)
            axes[1].legend(loc='lower right', fontsize=8)
        
        plt.suptitle('Central-Local Policy Synergy Distribution & Difference Analysis')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, '02_协同类型分布图.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("02_协同类型分布图.png saved (English labels)")
    
    def plot_synergy_difference_barchart(self, synergy_df):
        matched = synergy_df[synergy_df['central_topic_id'].notna()].copy()
        if len(matched) == 0:
            return
        fig, ax = plt.subplots(figsize=(10, 6))
        topics, diffs = [], []
        for _, row in matched.iterrows():
            topics.append(f"C{int(row['central_topic_id'])+1}")
            diffs.append(row['strength_diff'])
        colors_bar = []
        for d in diffs:
            if abs(d) < 0.10:
                colors_bar.append('#2ecc71')
            elif d >= 0.15:
                colors_bar.append('#e67e22')
            elif d <= -0.15:
                colors_bar.append('#e74c3c')
            elif d > 0:
                colors_bar.append('#3498db')
            else:
                colors_bar.append('#95a5a6')
        ax.barh(topics, diffs, color=colors_bar, edgecolor='white', height=0.6)
        ax.axvline(x=0, color='black', linewidth=1.5)
        ax.set_xlabel('Strength Difference (Local - Central)')
        ax.set_ylabel('Central Policy Topics')
        ax.set_title('Central-Local Topic Strength Difference Analysis')
        ax.axvline(x=0.10, color='#2ecc71', linestyle='--', alpha=0.6)
        ax.axvline(x=-0.10, color='#2ecc71', linestyle='--', alpha=0.6)
        ax.axvline(x=0.15, color='#e67e22', linestyle=':', alpha=0.6)
        ax.axvline(x=-0.15, color='#e74c3c', linestyle=':', alpha=0.6)
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, '03_央地主题强度差异分析图.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("03_央地主题强度差异分析图.png saved (English labels)")
    
    def plot_central_local_comprehensive(self, central_strengths, local_strengths):
        fig, ax = plt.subplots(figsize=(12, 6))
        central_themes = [f"C{i+1}" for i in range(len(central_strengths))]
        local_themes = [f"L{i+1}" for i in range(len(local_strengths))]
        x1 = np.arange(len(central_themes))
        x2 = np.arange(len(local_themes)) + len(central_themes) + 1
        ax.bar(x1, central_strengths, width=0.6, label='Central Policy', color='#2c7bb6', edgecolor='white')
        ax.bar(x2, local_strengths, width=0.6, label='Local Policy', color='#d7191c', edgecolor='white')
        ax.set_xlabel('Policy Topics')
        ax.set_ylabel('Topic Strength')
        ax.set_title('Central-Local Topic Strength Comparison')
        all_labels = central_themes + [''] + local_themes
        all_ticks = list(x1) + [x1[-1] + 0.8] + list(x2)
        ax.set_xticks(all_ticks)
        ax.set_xticklabels(all_labels)
        ax.legend(loc='upper right')
        ax.set_ylim(0, max(max(central_strengths), max(local_strengths)) * 1.15)
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, '09_央地主题强度综合对比.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("09_央地主题强度综合对比.png saved (English labels)")
    
    def plot_synergy_distribution_pie(self, synergy_df):
        type_counts = {}
        for t in ALL_SYNERGY_TYPES:
            type_counts[t] = len(synergy_df[synergy_df['synergy_type'] == t]) if t in synergy_df['synergy_type'].values else 0
        
        non_zero = {k: v for k, v in type_counts.items() if v > 0}
        
        if len(non_zero) == 0:
            fig, ax = plt.subplots(figsize=(10, 8))
            ax.text(0.5, 0.5, "No valid topic pairs", ha='center', va='center', fontsize=14)
            ax.set_title('Central-Local Policy Synergy Distribution')
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_path, '11_央地协同类型分布.png'), dpi=1000, bbox_inches='tight')
            plt.close()
            return
        
        fig, ax = plt.subplots(figsize=(12, 10))
        
        type_labels_en = {
            '高度协同': 'High Synergy',
            '地方强化': 'Local Strengthening', 
            '地方衰减': 'Local Attenuation',
            '地方关注': 'Local Focus',
            '中央主导': 'Central Dominance',
            '地方创新': 'Local Innovation',
            '中央特有': 'Central Unique'
        }
        
        labels = [type_labels_en.get(k, k) for k in non_zero.keys()]
        sizes = list(non_zero.values())
        colors = [SYNERGY_COLORS[k] for k in non_zero.keys()]
        
        wedges, texts, autotexts = ax.pie(
            sizes, 
            labels=labels,
            colors=colors,
            autopct=lambda pct: f'{pct:.1f}%',
            startangle=90,
            pctdistance=0.8,
            labeldistance=1.2
        )
        
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontweight('bold')
            autotext.set_fontsize(11)
        
        for text in texts:
            text.set_fontsize(10)
            text.set_fontweight('bold')
        
        ax.set_title('Central-Local Policy Synergy Distribution\n(7 Synergy Types)')
        
        centre_circle = plt.Circle((0, 0), 0.50, fc='white', linewidth=1.5, edgecolor='#cccccc')
        fig.gca().add_artist(centre_circle)
        
        total = sum(sizes)
        existing_count = len(non_zero)
        ax.text(0, 0, f'Total\n{total}\n({existing_count}/7 types)', ha='center', va='center', 
                fontsize=12, fontweight='bold')
        
        legend_elements = []
        for t in ALL_SYNERGY_TYPES:
            count = type_counts[t]
            color = SYNERGY_COLORS[t]
            label_en = type_labels_en.get(t, t)
            if count > 0:
                label = f'✓ {label_en}: ({count})'
                alpha = 0.85
            else:
                label = f'○ {label_en}: (0)'
                alpha = 0.3
            legend_elements.append(Patch(facecolor=color, label=label, alpha=alpha))
        
        ax.legend(handles=legend_elements, loc='center left', bbox_to_anchor=(1, 0.5), 
                  fontsize=8, title='Synergy Types (✓=present, ○=absent)')
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, '11_央地协同类型分布.png'), 
                    dpi=1000, bbox_inches='tight')
        plt.close()
        print(f"11_央地协同类型分布.png saved ({existing_count}/7 types)")
    
    def plot_difference_matrix(self, synergy_df, central_strengths, local_strengths):
        n_central, n_local = len(central_strengths), len(local_strengths)
        diff_matrix = np.full((n_central, n_local), np.nan)
        for _, row in synergy_df.iterrows():
            if pd.notna(row['central_topic_id']) and pd.notna(row['local_topic_id']):
                c, l = int(row['central_topic_id']), int(row['local_topic_id'])
                diff_matrix[c, l] = row['strength_diff']
        fig, ax = plt.subplots(figsize=(10, 6))
        im = ax.imshow(diff_matrix, cmap='RdYlBu_r', aspect='auto', vmin=-0.25, vmax=0.25)
        ax.set_xticks(range(n_local))
        ax.set_yticks(range(n_central))
        ax.set_xticklabels([f"L{i+1}" for i in range(n_local)])
        ax.set_yticklabels([f"C{i+1}" for i in range(n_central)])
        ax.set_xlabel('Local Policy Topics')
        ax.set_ylabel('Central Policy Topics')
        ax.set_title('Central-Local Topic Strength Difference Matrix')
        for i in range(n_central):
            for j in range(n_local):
                if not np.isnan(diff_matrix[i, j]):
                    ax.text(j, i, f'{diff_matrix[i, j]:+.3f}', ha='center', va='center',
                           fontsize=10, fontweight='bold', color='white' if abs(diff_matrix[i, j]) > 0.12 else 'black')
        plt.colorbar(im, ax=ax, label='Strength Difference')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, '12_央地主题强度差异矩阵.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("12_央地主题强度差异矩阵.png saved (English labels)")
    
    def plot_central_topics_matrix(self, central_model):
        central_years, central_yearly = central_model.get_yearly_topic_strengths()
        if central_years is None:
            return
        central_topic_names = [f"C{i+1}" for i in range(central_model.n_topics)]
        all_years = list(range(2011, 2026))
        
        central_full_matrix = []
        for i, topic_name in enumerate(central_topic_names):
            row = []
            for year in all_years:
                if year in central_years:
                    idx = list(central_years).index(year)
                    row.append(central_yearly[idx, i])
                else:
                    row.append(np.nan)
            central_full_matrix.append(row)
        
        df_central = pd.DataFrame(central_full_matrix, index=central_topic_names, columns=all_years)
        fig, ax = plt.subplots(figsize=(16, max(6, central_model.n_topics * 0.6)))
        sns.heatmap(df_central, annot=True, cmap='Blues', fmt='.3f',
                    cbar_kws={'label': 'Topic Strength'}, ax=ax,
                    linewidths=0.5, square=False, vmin=0, vmax=1)
        ax.set_title('Central Topic Strength Matrix (2011-2025)')
        ax.set_xlabel('Year')
        ax.set_ylabel('Central Topic')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, 'central_topics_matrix.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("central_topics_matrix.png saved (English labels)")
    
    def plot_local_topics_matrix(self, local_model):
        local_years, local_yearly = local_model.get_yearly_topic_strengths()
        if local_years is None:
            return
        local_topic_names = [f"L{i+1}" for i in range(local_model.n_topics)]
        all_years = list(range(2011, 2026))
        
        local_full_matrix = []
        for i, topic_name in enumerate(local_topic_names):
            row = []
            for year in all_years:
                if year in local_years:
                    idx = list(local_years).index(year)
                    row.append(local_yearly[idx, i])
                else:
                    row.append(np.nan)
            local_full_matrix.append(row)
        
        df_local = pd.DataFrame(local_full_matrix, index=local_topic_names, columns=all_years)
        fig, ax = plt.subplots(figsize=(16, max(6, local_model.n_topics * 0.6)))
        sns.heatmap(df_local, annot=True, cmap='Greens', fmt='.3f',
                    cbar_kws={'label': 'Topic Strength'}, ax=ax,
                    linewidths=0.5, square=False, vmin=0, vmax=1)
        ax.set_title('Local Topic Strength Matrix (2011-2025)')
        ax.set_xlabel('Year')
        ax.set_ylabel('Local Topic')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, 'local_topics_matrix.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("local_topics_matrix.png saved (English labels)")
    
    def plot_difference_matrix(self, synergy_df, central_strengths, local_strengths):
        n_central, n_local = len(central_strengths), len(local_strengths)
        diff_matrix = np.full((n_central, n_local), np.nan)
        for _, row in synergy_df.iterrows():
            if pd.notna(row['central_topic_id']) and pd.notna(row['local_topic_id']):
                c, l = int(row['central_topic_id']), int(row['local_topic_id'])
                diff_matrix[c, l] = row['strength_diff']
        fig, ax = plt.subplots(figsize=(10, 6))
        im = ax.imshow(diff_matrix, cmap='RdYlBu_r', aspect='auto', vmin=-0.25, vmax=0.25)
        ax.set_xticks(range(n_local))
        ax.set_yticks(range(n_central))
        ax.set_xticklabels([f"L{i+1}" for i in range(n_local)])
        ax.set_yticklabels([f"C{i+1}" for i in range(n_central)])
        ax.set_xlabel('Local Policy Topics')
        ax.set_ylabel('Central Policy Topics')
        ax.set_title('Central-Local Topic Strength Difference Matrix')
        for i in range(n_central):
            for j in range(n_local):
                if not np.isnan(diff_matrix[i, j]):
                    ax.text(j, i, f'{diff_matrix[i, j]:+.3f}', ha='center', va='center',
                           fontsize=10, fontweight='bold', color='white' if abs(diff_matrix[i, j]) > 0.12 else 'black')
        plt.colorbar(im, ax=ax, label='Strength Difference')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, '12_央地主题强度差异矩阵.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("12_央地主题强度差异矩阵.png saved (English labels)")
    
    def plot_central_topics_matrix(self, central_model):
        central_years, central_yearly = central_model.get_yearly_topic_strengths()
        if central_years is None:
            return
        central_topic_names = [f"C{i+1}" for i in range(central_model.n_topics)]
        all_years = list(range(2011, 2026))
        
        central_full_matrix = []
        for i, topic_name in enumerate(central_topic_names):
            row = []
            for year in all_years:
                if year in central_years:
                    idx = list(central_years).index(year)
                    row.append(central_yearly[idx, i])
                else:
                    row.append(np.nan)
            central_full_matrix.append(row)
        
        df_central = pd.DataFrame(central_full_matrix, index=central_topic_names, columns=all_years)
        fig, ax = plt.subplots(figsize=(16, max(6, central_model.n_topics * 0.6)))
        sns.heatmap(df_central, annot=True, cmap='Blues', fmt='.3f',
                    cbar_kws={'label': '主题强度'}, ax=ax,
                    linewidths=0.5, square=False, vmin=0, vmax=1)
        ax.set_title('中央主题强度矩阵 (2011-2025)')
        ax.set_xlabel('年份')
        ax.set_ylabel('中央主题')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, 'central_topics_matrix.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("central_topics_matrix.png 已保存")
    
    def plot_local_topics_matrix(self, local_model):
        local_years, local_yearly = local_model.get_yearly_topic_strengths()
        if local_years is None:
            return
        local_topic_names = [f"L{i+1}" for i in range(local_model.n_topics)]
        all_years = list(range(2011, 2026))
        
        local_full_matrix = []
        for i, topic_name in enumerate(local_topic_names):
            row = []
            for year in all_years:
                if year in local_years:
                    idx = list(local_years).index(year)
                    row.append(local_yearly[idx, i])
                else:
                    row.append(np.nan)
            local_full_matrix.append(row)
        
        df_local = pd.DataFrame(local_full_matrix, index=local_topic_names, columns=all_years)
        fig, ax = plt.subplots(figsize=(16, max(6, local_model.n_topics * 0.6)))
        sns.heatmap(df_local, annot=True, cmap='Greens', fmt='.3f',
                    cbar_kws={'label': '主题强度'}, ax=ax,
                    linewidths=0.5, square=False, vmin=0, vmax=1)
        ax.set_title('地方主题强度矩阵 (2011-2025)')
        ax.set_xlabel('年份')
        ax.set_ylabel('地方主题')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, 'local_topics_matrix.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("local_topics_matrix.png 已保存")


# ==================== 模块二：工具部分 ====================

def build_builtin_framework():
    framework = {"供给型": [], "需求型": [], "环境型": []}
    for indicator, tool_type in INDICATOR_TO_TYPE.items():
        framework[tool_type].append(indicator)
    return framework


def build_framework_dataframe():
    rows = []
    tool_code_map = {"供给型": "Z1", "需求型": "Z2", "环境型": "Z3"}
    
    for indicator, tool_type in INDICATOR_TO_TYPE.items():
        tool_code = tool_code_map[tool_type]
        idx = list(INDICATOR_TO_TYPE.keys()).index(indicator)
        rows.append({
            "一级工具": tool_type,
            "工具代码": tool_code,
            "二级指标": indicator,
            "二级代码": f"{tool_code}-{idx+1}",
            "操作化定义": INDICATOR_DEFINITIONS.get(indicator, "待补充"),
            "关键词示例": INDICATOR_KEYWORDS.get(indicator, "待补充"),
            "文献来源": INDICATOR_LITERATURE.get(indicator, "待补充")
        })
    return pd.DataFrame(rows)


class PolicyTextLoader:
    @staticmethod
    def load_all_policies(central_folder: str, local_folder: str):
        print(f"\n{'='*60}\n学校体育政策文本加载\n{'='*60}")
        central_texts, central_info = PolicyTextLoader._load_all_from_folder(central_folder, "中央数据")
        local_texts, local_info = PolicyTextLoader._load_all_from_folder(local_folder, "地方数据")
        all_info = central_info + local_info
        metadata_df = pd.DataFrame(all_info) if all_info else pd.DataFrame()
        text_names_df = pd.DataFrame([{"序号": i+1, "政策文本名称": f["文件名"], "来源": f["来源"],
            "年份": f["年份"], "政策类型": f["政策类型"], "文件大小(字)": f["文件大小"]} for i, f in enumerate(all_info)])
        sampling_stats = {"总体": {"总文件数": len(all_info), "中央数据数": len(central_info), "地方数据数": len(local_info)}}
        return central_texts, local_texts, metadata_df, text_names_df, sampling_stats
    
    @staticmethod
    def _load_all_from_folder(folder: str, source: str):
        texts, infos = [], []
        if not os.path.exists(folder):
            return texts, infos
        for file_name in os.listdir(folder):
            file_path = os.path.join(folder, file_name)
            if not os.path.isfile(file_path) or not file_name.lower().endswith(('.txt', '.md', '.csv')):
                continue
            content = PolicyTextLoader._read_file(file_path)
            if content is not None:
                year_match = re.search(r'(201[1-9]|202[0-5])', file_name)
                year = int(year_match.group(1)) if year_match else None
                type_keywords = {"意见": "指导意见", "通知": "通知类", "办法": "管理办法",
                                "规划": "发展规划", "方案": "实施方案", "条例": "法规条例"}
                policy_type = "其他"
                for k, v in type_keywords.items():
                    if k in file_name:
                        policy_type = v
                        break
                texts.append(content)
                infos.append({"文件名": file_name, "来源": source, "年份": year,
                             "政策类型": policy_type, "文件大小": len(content)})
                print(f"  ✓ {file_name}")
        return texts, infos
    
    @staticmethod
    def _read_file(file_path: str):
        for enc in ['utf-8', 'gbk', 'gb2312', 'gb18030', 'utf-8-sig', 'latin-1', 'cp936', 'big5']:
            try:
                with open(file_path, 'r', encoding=enc) as f:
                    return f.read()
            except:
                continue
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except:
            return None
    
    @staticmethod
    def export_metadata(metadata_df, filename="policy_metadata.xlsx"):
        filepath = os.path.join(OUTPUT_DIR, filename)
        if not metadata_df.empty:
            metadata_df.to_excel(filepath, index=False)
            print(f"✅ 文件元数据已导出: {filepath}")
    
    @staticmethod
    def export_text_names(text_names_df, filename="policy_text_names.xlsx"):
        filepath = os.path.join(OUTPUT_DIR, filename)
        if not text_names_df.empty:
            text_names_df.to_excel(filepath, index=False)
            print(f"✅ 文本名称表已导出: {filepath}")
    
    @staticmethod
    def export_sampling_stats(sampling_stats, filename="sampling_stats.xlsx"):
        filepath = os.path.join(OUTPUT_DIR, filename)
        overall_df = pd.DataFrame({"统计项": list(sampling_stats["总体"].keys()), "数值": [str(v) for v in sampling_stats["总体"].values()]})
        overall_df.to_excel(filepath, index=False)
        print(f"✅ 抽样统计已导出: {filepath}")


class PolicyTextCoder:
    def __init__(self, framework_df):
        self.keyword_mapping = {}
        self.indicator_to_type = {}
        for _, row in framework_df.iterrows():
            indicator, tool_type = row["二级指标"], row["一级工具"]
            keywords_str = row.get("关键词示例", "")
            keywords = re.split('[、，, ]+', keywords_str) if pd.notna(keywords_str) and keywords_str else []
            self.keyword_mapping[indicator] = keywords
            self.indicator_to_type[indicator] = tool_type
        self.tool_categories = ['供给型', '需求型', '环境型']
        print(f"✅ 从框架表加载了 {len(self.keyword_mapping)} 个指标的关键词")
    
    def encode_text(self, text):
        matched = {cat: [] for cat in self.tool_categories}
        for indicator, keywords in self.keyword_mapping.items():
            tool = self.indicator_to_type.get(indicator)
            if tool and keywords and any(k in text for k in keywords):
                matched[tool].append(indicator)
        return matched
    
    def get_tool_vector(self, text):
        result = self.encode_text(text)
        return np.array([len(result[cat]) for cat in self.tool_categories])
    
    def get_detailed_frequency(self, texts, metadata_df):
        frequency = {"供给型": defaultdict(int), "需求型": defaultdict(int), "环境型": defaultdict(int)}
        central_freq = {"供给型": defaultdict(int), "需求型": defaultdict(int), "环境型": defaultdict(int)}
        local_freq = {"供给型": defaultdict(int), "需求型": defaultdict(int), "环境型": defaultdict(int)}
        for idx, text in enumerate(texts):
            matched = self.encode_text(text)
            source = metadata_df.iloc[idx].get("来源", "未知") if metadata_df is not None and idx < len(metadata_df) else "未知"
            for tool_type, indicators in matched.items():
                for indicator in indicators:
                    frequency[tool_type][indicator] += 1
                    if source == "中央数据":
                        central_freq[tool_type][indicator] += 1
                    elif source == "地方数据":
                        local_freq[tool_type][indicator] += 1
        return {"total": frequency, "central": central_freq, "local": local_freq}
    
    def batch_encode(self, texts):
        results = []
        for i, text in enumerate(texts):
            matched = self.encode_text(text)
            results.append({"文本编号": i+1, "供给型匹配": ", ".join(matched["供给型"]) or "无",
                "需求型匹配": ", ".join(matched["需求型"]) or "无", "环境型匹配": ", ".join(matched["环境型"]) or "无",
                "匹配总数": len(matched["供给型"]) + len(matched["需求型"]) + len(matched["环境型"])})
        return pd.DataFrame(results)
    
    def export_encoding_results(self, results_df, filename="encoding_results.xlsx"):
        filepath = os.path.join(OUTPUT_DIR, filename)
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            results_df.to_excel(writer, sheet_name="编码结果", index=False)
            summary = pd.DataFrame({"统计项": ["总文本数", "平均匹配数"],
                "数值": [len(results_df), round(results_df["匹配总数"].mean(), 2)]})
            summary.to_excel(writer, sheet_name="统计摘要", index=False)
        print(f"✅ 编码结果已导出: {filepath}")


class CoverageValidator:
    def __init__(self, total_texts: int):
        self.total_texts = total_texts
    
    def evaluate_all_indicators(self, frequency: Dict, central_frequency: Dict = None, local_frequency: Dict = None) -> pd.DataFrame:
        results = []
        all_indicators = {
            "供给型": ["基础建设", "人才培养", "资金投入", "科技支持", "公共服务"],
            "需求型": ["购买服务", "试点示范", "家校社协同", "引导激励"],
            "环境型": ["法规管制", "目标规划", "质量监管", "策略措施", "宣传推广"]
        }
        for tool_type, indicators in all_indicators.items():
            for indicator in indicators:
                freq = frequency.get(tool_type, {}).get(indicator, 0)
                central_freq = central_frequency.get(tool_type, {}).get(indicator, 0) if central_frequency else 0
                local_freq = local_frequency.get(tool_type, {}).get(indicator, 0) if local_frequency else 0
                coverage_rate = freq / self.total_texts if self.total_texts > 0 else 0
                if freq >= 3:
                    action, priority = "保留", "高"
                elif freq >= 2:
                    action, priority = "待验证", "中"
                elif freq >= 1:
                    action, priority = "重点讨论", "中低"
                else:
                    action, priority = "删除", "低"
                results.append({"一级工具": tool_type, "二级指标": indicator, "出现频次": freq,
                    "中央频次": central_freq, "地方频次": local_freq, "覆盖率": f"{coverage_rate*100:.1f}%",
                    "行动": action, "优先级": priority})
        return pd.DataFrame(results)
    
    def export_evaluation_report(self, evaluation_df: pd.DataFrame, filename: str = "coverage_evaluation.xlsx"):
        filepath = os.path.join(OUTPUT_DIR, filename)
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            evaluation_df.to_excel(writer, sheet_name="覆盖度评估", index=False)
            for action in ["保留", "待验证", "重点讨论", "删除"]:
                subset = evaluation_df[evaluation_df["行动"] == action]
                if not subset.empty:
                    subset.to_excel(writer, sheet_name=f"行动-{action}", index=False)
        print(f"✅ 覆盖度评估报告已导出: {filepath}")


class FrameworkDocumenter:
    def __init__(self, final_framework: Dict[str, List[str]]):
        self.framework = final_framework
    
    def generate_framework_table(self) -> pd.DataFrame:
        rows = []
        tool_code_map = {"供给型": "Z1", "需求型": "Z2", "环境型": "Z3"}
        
        for tool_type, indicators in self.framework.items():
            tool_code = tool_code_map[tool_type]
            for i, indicator in enumerate(indicators):
                rows.append({
                    "一级工具": tool_type, 
                    "工具代码": tool_code, 
                    "二级指标": indicator,
                    "二级代码": f"{tool_code}-{i+1}", 
                    "操作化定义": INDICATOR_DEFINITIONS.get(indicator, "待补充"),
                    "关键词示例": INDICATOR_KEYWORDS.get(indicator, "待补充"),
                    "文献来源": INDICATOR_LITERATURE.get(indicator, "待补充")
                })
        return pd.DataFrame(rows)
    
    def export_framework_to_excel(self, filename: str = "policy_framework_table.xlsx"):
        filepath = os.path.join(OUTPUT_DIR, filename)
        framework_table = self.generate_framework_table()
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            framework_table.to_excel(writer, sheet_name="政策工具框架表", index=False)
            summary = pd.DataFrame({
                "统计项": ["总指标数", "供给型指标数", "需求型指标数", "环境型指标数"],
                "数值": [len(framework_table), 
                        len(framework_table[framework_table["一级工具"] == "供给型"]),
                        len(framework_table[framework_table["一级工具"] == "需求型"]),
                        len(framework_table[framework_table["一级工具"] == "环境型"])]
            })
            summary.to_excel(writer, sheet_name="统计摘要", index=False)
        print(f"✅ 框架表已导出: {filepath}")
    
    def export_framework_theoretical_basis(self, filename: str = "policy_framework_theoretical_basis.md"):
        filepath = os.path.join(OUTPUT_DIR, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(FRAMEWORK_THEORETICAL_BASIS)
        print(f"✅ 政策工具框架理论依据已导出: {filepath}")
    
    def export_to_markdown(self, filename: str = "school_sports_policy_framework.md"):
        filepath = os.path.join(OUTPUT_DIR, filename)
        framework_table = self.generate_framework_table()
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write("# 学校体育政策工具分析框架（14个二级指标）\n\n")
            f.write("## 一、理论依据\n\n")
            f.write("本框架基于 **Rothwell & Zegveld 模型**，将政策工具划分为三个一级类型：\n\n")
            f.write("| 一级类型 | 作用方向 | 功能描述 |\n")
            f.write("| --- | --- | --- |\n")
            f.write("| 供给型 | 推力 | 政府通过直接提供资源、基础设施、人才培养等方式推动学校体育发展 |\n")
            f.write("| 需求型 | 拉力 | 政府通过购买服务、试点示范、激励引导等方式拉动学校体育需求 |\n")
            f.write("| 环境型 | 影响力 | 政府通过法规管制、目标规划、质量监管等方式营造学校体育发展环境 |\n\n")
            f.write("## 二、参考文献\n\n")
            f.write("1. 王培刚、吴婧等（2026）\n")
            f.write("2. 曹盛民、史万兵（2018）\n")
            f.write("3. 张歆竹、刘俊荣（2024）\n")
            f.write("4. 部义峰、来鲁振（2020）\n\n")
            f.write("## 三、14个二级指标完整框架\n\n")
            f.write("| 一级工具 | 工具代码 | 二级指标 | 二级代码 | 操作化定义 | 关键词示例 | 文献来源 |\n")
            f.write("| --- | --- | --- | --- | --- | --- | --- |\n")
            for _, row in framework_table.iterrows():
                f.write(f"| {row['一级工具']} | {row['工具代码']} | {row['二级指标']} | {row['二级代码']} | {row['操作化定义']} | {row['关键词示例']} | {row['文献来源']} |\n")
            
            f.write("\n## 四、指标分类汇总\n\n")
            f.write("### 供给型（5个）- 参考曹盛民、史万兵（2018）\n")
            supply = framework_table[framework_table["一级工具"] == "供给型"]
            for _, row in supply.iterrows():
                f.write(f"- **{row['二级指标']}**：{row['操作化定义']}\n")
            f.write("\n### 需求型（4个）- 参考张歆竹、刘俊荣（2024）\n")
            demand = framework_table[framework_table["一级工具"] == "需求型"]
            for _, row in demand.iterrows():
                f.write(f"- **{row['二级指标']}**：{row['操作化定义']}\n")
            f.write("\n### 环境型（5个）- 参考部义峰、来鲁振（2020）\n")
            env = framework_table[framework_table["一级工具"] == "环境型"]
            for _, row in env.iterrows():
                f.write(f"- **{row['二级指标']}**：{row['操作化定义']}\n")
        print(f"✅ 框架Markdown已导出: {filepath}")


# ==================== 工具可视化 ====================

def plot_tool_comparison_independent(framework_df, central_freq, local_freq, central_count, local_count):
    print("\nGenerating Central-Local Policy Tool Distribution Comparison...")
    
    # ========== 英文标签映射 ==========
    tool_type_en = {
        '供给型': 'Supply',
        '需求型': 'Demand',
        '环境型': 'Environment'
    }
    
    indicator_en = {
        '基础建设': 'Infrastructure',
        '人才培养': 'Talent Training',
        '资金投入': 'Financial Investment',
        '科技支持': 'Tech Support',
        '公共服务': 'Public Service',
        '购买服务': 'Service Purchase',
        '试点示范': 'Pilot Demonstration',
        '家校社协同': 'Home-School-Community',
        '引导激励': 'Guidance & Incentive',
        '法规管制': 'Regulation',
        '目标规划': 'Goal Planning',
        '质量监管': 'Quality Supervision',
        '策略措施': 'Strategic Measures',
        '宣传推广': 'Promotion'
    }
    
    # ========== 第一步：构建原始数据 ==========
    raw_data = []
    for _, row in framework_df.iterrows():
        indicator = row["二级指标"]
        tool_type = row["一级工具"]
        central_raw = central_freq.get(tool_type, {}).get(indicator, 0) if central_freq else 0
        local_raw = local_freq.get(tool_type, {}).get(indicator, 0) if local_freq else 0
        central_pct = central_raw / central_count * 100 if central_count > 0 else 0
        local_pct = local_raw / local_count * 100 if local_count > 0 else 0
        
        indicator_en_name = indicator_en.get(indicator, indicator)
        tool_type_en_name = tool_type_en.get(tool_type, tool_type)
        
        raw_data.append({
            "二级指标": indicator_en_name,
            "一级工具": tool_type_en_name,
            "中央原始占比": central_pct,
            "地方原始占比": local_pct,
            "中央次数": central_raw,
            "地方次数": local_raw
        })
    df_raw = pd.DataFrame(raw_data)
    
    # ========== 第二步：整体归一化（所有14个二级指标总和=100%） ==========
    # 计算所有14个指标的总和作为分母
    central_total_sum = df_raw['中央原始占比'].sum()
    local_total_sum = df_raw['地方原始占比'].sum()
    
    normalized_data = []
    for _, row in df_raw.iterrows():
        central_norm = (row['中央原始占比'] / central_total_sum * 100) if central_total_sum > 0 else 0
        local_norm = (row['地方原始占比'] / local_total_sum * 100) if local_total_sum > 0 else 0
        normalized_data.append({
            "二级指标": row['二级指标'],
            "一级工具": row['一级工具'],
            "中央_归一化": central_norm,
            "地方_归一化": local_norm,
            "中央_原始占比": row['中央原始占比'],
            "地方_原始占比": row['地方原始占比'],
            "中央次数": row['中央次数'],
            "地方次数": row['地方次数']
        })
    
    df_norm = pd.DataFrame(normalized_data)
    
    # 按一级工具分组排序
    tool_order = ['Supply', 'Demand', 'Environment']
    df_norm['一级工具'] = pd.Categorical(df_norm['一级工具'], categories=tool_order, ordered=True)
    df_norm = df_norm.sort_values('一级工具').reset_index(drop=True)
    
    if df_norm.empty:
        print("⚠️ No data, skipping visualization")
        return
    
    # ========== 验证归一化结果 ==========
    central_sum_check = df_norm['中央_归一化'].sum()
    local_sum_check = df_norm['地方_归一化'].sum()
    print(f"\n【整体归一化验证】")
    print(f"  中央政策14个指标总和: {central_sum_check:.2f}%")
    print(f"  地方政策14个指标总和: {local_sum_check:.2f}%")
    if abs(central_sum_check - 100) < 0.01 and abs(local_sum_check - 100) < 0.01:
        print("  ✅ 验证通过！所有14个二级指标总和=100%")
    else:
        print("  ⚠️ 验证未通过，请检查数据")
    
    tool_colors = {"Supply": "#3498db", "Demand": "#2ecc71", "Environment": "#e74c3c"}
    indicators = df_norm["二级指标"].tolist()
    bar_colors = [tool_colors[t] for t in df_norm["一级工具"]]
    
    fig, axes = plt.subplots(2, 2, figsize=(20, 14))
    
    # ==================== Top Left: Central Policy Bar Chart (整体归一化) ====================
    ax1 = axes[0, 0]
    bars1 = ax1.bar(indicators, df_norm["中央_归一化"], color=bar_colors, edgecolor='white', linewidth=1.5, alpha=0.85)
    ax1.set_xlabel('Policy Tool Indicators', fontsize=14, fontweight='bold')
    ax1.set_ylabel('Normalized Percentage (%)', fontsize=14, fontweight='bold')
    ax1.set_title('Central Policy Tool Distribution (All 14 Indicators = 100%)', fontsize=14, fontweight='bold')
    ax1.set_xticklabels(indicators, rotation=45, ha='right', fontsize=12, fontweight='bold')
    ax1.set_ylim(0, 55)
    ax1.grid(True, alpha=0.3, axis='y')
    
    # 添加分组边界线和组标签
    _add_group_boundaries_independent(ax1, df_norm, tool_colors, fontsize=12)
    
    for idx, bar in enumerate(bars1):
        height = bar.get_height()
        indicator = indicators[idx]
        ax1.annotate(f'{height:.1f}%', xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 5), textcoords="offset points", ha='center', va='bottom', 
                    fontsize=14, fontweight='bold')
        raw_count = df_norm.loc[df_norm['二级指标'] == indicator, '中央次数'].values
        if len(raw_count) > 0:
            ax1.annotate(f'({raw_count[0]})', xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, -18), textcoords="offset points", ha='center', va='bottom', 
                        fontsize=12, fontweight='bold', color='#7f8c8d')
    
    # ==================== Top Right: Local Policy Bar Chart (整体归一化) ====================
    ax2 = axes[0, 1]
    bars2 = ax2.bar(indicators, df_norm["地方_归一化"], color=bar_colors, edgecolor='white', linewidth=1.5, alpha=0.85)
    ax2.set_xlabel('Policy Tool Indicators', fontsize=14, fontweight='bold')
    ax2.set_ylabel('Normalized Percentage (%)', fontsize=14, fontweight='bold')
    ax2.set_title('Local Policy Tool Distribution (All 14 Indicators = 100%)', fontsize=14, fontweight='bold')
    ax2.set_xticklabels(indicators, rotation=45, ha='right', fontsize=12, fontweight='bold')
    ax2.set_ylim(0, 55)
    ax2.grid(True, alpha=0.3, axis='y')
    
    # 添加分组边界线和组标签
    _add_group_boundaries_independent(ax2, df_norm, tool_colors, fontsize=12)
    
    for idx, bar in enumerate(bars2):
        height = bar.get_height()
        indicator = indicators[idx]
        ax2.annotate(f'{height:.1f}%', xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 5), textcoords="offset points", ha='center', va='bottom', 
                    fontsize=14, fontweight='bold')
        raw_count = df_norm.loc[df_norm['二级指标'] == indicator, '地方次数'].values
        if len(raw_count) > 0:
            ax2.annotate(f'({raw_count[0]})', xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, -18), textcoords="offset points", ha='center', va='bottom', 
                        fontsize=12, fontweight='bold', color='#7f8c8d')
    
    # ==================== Bottom Left: Central Policy Pie Chart (原始数据) ====================
    ax3 = axes[1, 0]
    central_by_type = df_raw.groupby('一级工具')['中央原始占比'].sum()
    central_by_type = central_by_type.reindex(['Supply', 'Demand', 'Environment'])
    colors_pie = [tool_colors[t] for t in central_by_type.index]
    explode_vals = (0.06, 0.06, 0.06)
    
    # Shadow pie
    shadow_result = ax3.pie(
        central_by_type.values,
        colors=['#d0d0d0'] * len(central_by_type),
        explode=explode_vals,
        startangle=90,
        radius=1.0,
        wedgeprops={'edgecolor': 'none', 'alpha': 0.35},
        shadow=False,
        frame=False
    )
    shadow_wedges = shadow_result[0]
    for wedge in shadow_wedges:
        wedge.set_center((0.04, -0.04))
    
    # Main pie
    wedges, texts, autotexts = ax3.pie(
        central_by_type.values,
        labels=central_by_type.index.tolist(),
        colors=colors_pie,
        autopct='%1.1f%%',
        startangle=90,
        explode=explode_vals,
        wedgeprops={'edgecolor': 'white', 'linewidth': 1.5},
        pctdistance=0.80,
        labeldistance=1.10,
        shadow=False
    )
    for text in texts:
        text.set_fontsize(14)
        text.set_fontweight('bold')
    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontweight('bold')
        autotext.set_fontsize(18)
    ax3.set_title('')
    
    # ==================== Bottom Right: Local Policy Pie Chart (原始数据) ====================
    ax4 = axes[1, 1]
    local_by_type = df_raw.groupby('一级工具')['地方原始占比'].sum()
    local_by_type = local_by_type.reindex(['Supply', 'Demand', 'Environment'])
    
    # Shadow pie
    shadow_result2 = ax4.pie(
        local_by_type.values,
        colors=['#d0d0d0'] * len(local_by_type),
        explode=explode_vals,
        startangle=90,
        radius=1.0,
        wedgeprops={'edgecolor': 'none', 'alpha': 0.35},
        shadow=False,
        frame=False
    )
    shadow_wedges2 = shadow_result2[0]
    for wedge in shadow_wedges2:
        wedge.set_center((0.04, -0.04))
    
    # Main pie
    wedges, texts, autotexts = ax4.pie(
        local_by_type.values,
        labels=local_by_type.index.tolist(),
        colors=colors_pie,
        autopct='%1.1f%%',
        startangle=90,
        explode=explode_vals,
        wedgeprops={'edgecolor': 'white', 'linewidth': 1.5},
        pctdistance=0.80,
        labeldistance=1.10,
        shadow=False
    )
    for text in texts:
        text.set_fontsize(14)
        text.set_fontweight('bold')
    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontweight('bold')
        autotext.set_fontsize(18)
    ax4.set_title('')
    
    # ==================== Legend and Title ====================
    legend_elements = [
        Patch(facecolor=tool_colors['Supply'], label='Supply-oriented', alpha=0.85),
        Patch(facecolor=tool_colors['Demand'], label='Demand-oriented', alpha=0.85),
        Patch(facecolor=tool_colors['Environment'], label='Environment-oriented', alpha=0.85)
    ]
    fig.legend(handles=legend_elements, loc='lower center', ncol=3, 
               fontsize=18, bbox_to_anchor=(0.5, 0.02),
               prop={'weight': 'bold'})
    
    fig.suptitle('Central-Local Policy Tool Distribution Comparison\n', 
                 fontsize=20, fontweight='bold')
    fig.text(0.5, 0.06, 
             'Note: Bar shows normalized percentage (top) and raw count (bottom) for all 14 indicators = 100%; Pie shows raw tool type distribution',
             ha='center', fontsize=14, fontweight='bold', style='italic', 
             bbox=dict(boxstyle='round,pad=0.3', facecolor='#f0f0f0', alpha=0.8))
    plt.tight_layout()
    plt.subplots_adjust(bottom=0.12, hspace=0.3, wspace=0.25)
    
    plt.savefig(os.path.join(OUTPUT_DIR, '央地政策工具使用分布对比图_独立版.png'), dpi=1200, bbox_inches='tight')
    plt.close()
    print("✅ Central-Local Policy Tool Distribution Comparison saved (all 14 indicators = 100%, 1200 DPI)")

def _add_group_boundaries_independent(ax, df_norm, tool_colors, fontsize=12):
    """
    为独立版柱状图添加分组边界线和组标签
    """
    groups = ['Supply', 'Demand', 'Environment']
    group_indices = {}
    
    for g in groups:
        subset = df_norm[df_norm['一级工具'] == g]
        if not subset.empty:
            group_indices[g] = subset.index.tolist()
    
    for i, (g, indices) in enumerate(group_indices.items()):
        start, end = min(indices), max(indices)
        if i > 0:
            x_pos = start - 0.5
            ax.axvline(x=x_pos, color='gray', linestyle='--', linewidth=1, alpha=0.5)
        
        mid = (start + end) / 2
        ax.text(mid, -1.5, f'{g}', ha='center', va='top', 
                fontsize=fontsize, fontweight='bold', color=tool_colors.get(g, 'black'))
    
    ax.set_ylim(-2.5, 15)


# ==================== 【核心修改】export_tool_comparison_by_period_table 函数 - 整体归一化（每个时间段所有14个指标总和=100%） ====================

def export_tool_comparison_by_period_table(central_freq, local_freq, central_count, local_count, 
                                           central_texts_tool, local_texts_tool, metadata_df, tool_coder):
    """
    修改版：每个时间段内，所有14个二级指标归一化后总和=100%
    即每个时间段内，所有指标的出现次数之和作为分母进行归一化
    """
    print("\n导出央地政策不同时期工具使用分布表（整体归一化）...")
    
    periods = [
        {"name": "2011-2025", "years": list(range(2011, 2026))},
        {"name": "2011-2015", "years": list(range(2011, 2016))},
        {"name": "2016-2020", "years": list(range(2016, 2021))},
        {"name": "2021-2025", "years": list(range(2021, 2026))}
    ]
    
    indicators = list(INDICATOR_DEFINITIONS.keys())
    
    doc_years_covered = []
    for i, (_, row) in enumerate(metadata_df.iterrows()):
        filename = row.get("文件名", "")
        years_covered = extract_years_covered_from_filename(filename)
        if not years_covered:
            year_val = row.get("年份")
            if year_val:
                years_covered = [year_val]
        doc_years_covered.append(years_covered)
    
    # ========== 第一步：计算每个时间段每个指标的原始出现次数 ==========
    all_results = []
    
    for period in periods:
        period_years = period["years"]
        period_name = period["name"]
        
        # 统计中央政策
        central_counts = {ind: 0 for ind in indicators}
        central_docs = 0
        for i, text in enumerate(central_texts_tool):
            years_covered = doc_years_covered[i] if i < len(doc_years_covered) else []
            if not any(y in period_years for y in years_covered):
                continue
            central_docs += 1
            matched = tool_coder.encode_text(text)
            for tool_type, inds in matched.items():
                for ind in inds:
                    if ind in central_counts:
                        central_counts[ind] += 1
        
        # 统计地方政策
        local_counts = {ind: 0 for ind in indicators}
        local_docs = 0
        offset = len(central_texts_tool)
        for i, text in enumerate(local_texts_tool):
            years_covered = doc_years_covered[offset + i] if offset + i < len(doc_years_covered) else []
            if not any(y in period_years for y in years_covered):
                continue
            local_docs += 1
            matched = tool_coder.encode_text(text)
            for tool_type, inds in matched.items():
                for ind in inds:
                    if ind in local_counts:
                        local_counts[ind] += 1
        
        # 存储原始数据
        for indicator in indicators:
            tool_type = INDICATOR_TO_TYPE.get(indicator, "")
            all_results.append({
                "时间段": period_name,
                "一级工具": tool_type,
                "二级指标": indicator,
                "中央_原始次数": central_counts[indicator],
                "地方_原始次数": local_counts[indicator],
                "中央_文档数": central_docs,
                "地方_文档数": local_docs
            })
    
    result_df = pd.DataFrame(all_results)
    
    # ========== 第二步：按时间段分组，所有14个指标整体归一化 ==========
    normalized_data = []
    
    for period_name in [p["name"] for p in periods]:
        period_df = result_df[result_df["时间段"] == period_name]
        
        # 获取该时间段中央和地方的总次数（所有14个指标之和）
        central_total = period_df["中央_原始次数"].sum()
        local_total = period_df["地方_原始次数"].sum()
        
        for _, row in period_df.iterrows():
            indicator = row["二级指标"]
            tool_type = row["一级工具"]
            central_raw = row["中央_原始次数"]
            local_raw = row["地方_原始次数"]
            
            # 整体归一化：每个指标次数 / 该时间段所有指标总次数 × 100%
            central_norm = (central_raw / central_total * 100) if central_total > 0 else 0
            local_norm = (local_raw / local_total * 100) if local_total > 0 else 0
            
            normalized_data.append({
                "时间段": period_name,
                "一级工具": tool_type,
                "二级指标": indicator,
                f"{period_name}_中央": f"{central_norm:.1f}% ({central_raw})",
                f"{period_name}_地方": f"{local_norm:.1f}% ({local_raw})",
                "中央_归一化": round(central_norm, 2),
                "地方_归一化": round(local_norm, 2),
                "中央_原始次数": central_raw,
                "地方_原始次数": local_raw
            })
    
    norm_df = pd.DataFrame(normalized_data)
    
    # ========== 第三步：验证每个时间段所有指标总和是否为100% ==========
    print("\n【整体归一化验证】")
    all_valid = True
    for period_name in [p["name"] for p in periods]:
        period_subset = norm_df[norm_df["时间段"] == period_name]
        central_sum = period_subset["中央_归一化"].sum()
        local_sum = period_subset["地方_归一化"].sum()
        status = "✅" if (abs(central_sum - 100) < 0.01 and abs(local_sum - 100) < 0.01) else "❌"
        print(f"  {status} {period_name}: 中央 {central_sum:.1f}%, 地方 {local_sum:.1f}% (共{len(period_subset)}个指标)")
        if abs(central_sum - 100) >= 0.01 or abs(local_sum - 100) >= 0.01:
            all_valid = False
    
    if all_valid:
        print("  ✅ 所有时间段归一化验证通过！每个时间段所有指标总和=100%")
    else:
        print("  ⚠️ 部分时间段归一化验证未通过，请检查数据")
    
    # ========== 第四步：生成透视表 ==========
    unique_indicators = norm_df["二级指标"].unique()
    
    pivot_data = []
    for indicator in unique_indicators:
        row = {
            "一级工具": norm_df[norm_df["二级指标"] == indicator]["一级工具"].iloc[0],
            "二级指标": indicator
        }
        for period in periods:
            period_name = period["name"]
            subset = norm_df[(norm_df["时间段"] == period_name) & (norm_df["二级指标"] == indicator)]
            if not subset.empty:
                row[f"{period_name}_中央"] = subset[f"{period_name}_中央"].iloc[0]
                row[f"{period_name}_地方"] = subset[f"{period_name}_地方"].iloc[0]
            else:
                row[f"{period_name}_中央"] = "0.0% (0)"
                row[f"{period_name}_地方"] = "0.0% (0)"
        pivot_data.append(row)
    
    final_df = pd.DataFrame(pivot_data)
    
    # 调整列顺序
    cols = ["一级工具", "二级指标"]
    for period in periods:
        cols.append(f"{period['name']}_中央")
        cols.append(f"{period['name']}_地方")
    final_df = final_df[cols]
    
    # ========== 第五步：导出文件 ==========
    filepath = os.path.join(OUTPUT_DIR, "央地政策不同时期工具使用分布表.xlsx")
    with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
        final_df.to_excel(writer, sheet_name="不同时期对比（整体归一化）", index=False)
        
        # 验证表：显示每个时间段所有指标总和是否为100%
        validation_data = []
        for period_name in [p["name"] for p in periods]:
            period_subset = norm_df[norm_df["时间段"] == period_name]
            # 按一级工具分组显示汇总
            for tool_type in ["供给型", "需求型", "环境型"]:
                subset = period_subset[period_subset["一级工具"] == tool_type]
                if not subset.empty:
                    validation_data.append({
                        "时间段": period_name,
                        "一级工具": tool_type,
                        "中央_归一化总和": round(subset["中央_归一化"].sum(), 2),
                        "地方_归一化总和": round(subset["地方_归一化"].sum(), 2),
                        "指标数": len(subset)
                    })
            # 添加总计行
            validation_data.append({
                "时间段": period_name,
                "一级工具": "【总计】",
                "中央_归一化总和": round(period_subset["中央_归一化"].sum(), 2),
                "地方_归一化总和": round(period_subset["地方_归一化"].sum(), 2),
                "指标数": len(period_subset)
            })
        pd.DataFrame(validation_data).to_excel(writer, sheet_name="归一化验证（总计=100%）", index=False)
        
        # 原始数据
        raw_data = []
        for period_name in [p["name"] for p in periods]:
            period_subset = result_df[result_df["时间段"] == period_name]
            for _, row in period_subset.iterrows():
                raw_data.append({
                    "时间段": row["时间段"],
                    "一级工具": row["一级工具"],
                    "二级指标": row["二级指标"],
                    "中央_次数": row["中央_原始次数"],
                    "地方_次数": row["地方_原始次数"],
                    "中央_文档数": row["中央_文档数"],
                    "地方_文档数": row["地方_文档数"]
                })
        pd.DataFrame(raw_data).to_excel(writer, sheet_name="原始数据", index=False)
        
        # 说明
        note_df = pd.DataFrame({
            "说明项": ["表格说明", "归一化公式", "分组依据", "时间段说明", "格式说明", "生成时间"],
            "内容": [
                "央地政策不同时期工具使用分布表（每个时间段内，所有14个二级指标归一化后总和=100%）",
                "归一化值 = (该指标出现次数 / 该时间段所有指标出现次数之和) × 100%",
                "14个二级指标按供给型(5个)/需求型(4个)/环境型(5个)分组展示，但归一化基于全部14个指标",
                "2011-2025：全时段；2011-2015：十二五；2016-2020：十三五；2021-2025：十四五",
                "格式：归一化占比% (原始出现次数)，每个时间段内所有指标归一化占比之和=100%",
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ]
        })
        note_df.to_excel(writer, sheet_name="说明", index=False)
    
    print(f"✅ 央地政策不同时期工具使用分布表已保存: {filepath}")
    
    # ========== 第六步：导出CSV ==========
    csv_path = os.path.join(OUTPUT_DIR, "央地政策不同时期工具使用分布表.csv")
    final_df.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"✅ CSV已保存: {csv_path}")
    
    # ========== 第七步：导出Markdown ==========
    md_path = os.path.join(OUTPUT_DIR, "央地政策不同时期工具使用分布表.md")
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write("# 央地政策不同时期工具使用分布表\n\n")
        f.write("## 📌 说明\n\n")
        f.write("每个时间段内，所有14个二级指标**归一化后总和 = 100%**。\n\n")
        f.write("| 一级工具 | 二级指标 | " + " | ".join([f"{p['name']}_中央" for p in periods]) + " | " + " | ".join([f"{p['name']}_地方" for p in periods]) + " |\n")
        f.write("| --- | --- | " + " | ".join(["---" for _ in periods]) + " | " + " | ".join(["---" for _ in periods]) + " |\n")
        for _, row in final_df.iterrows():
            central_cols = " | ".join([row[f"{p['name']}_中央"] for p in periods])
            local_cols = " | ".join([row[f"{p['name']}_地方"] for p in periods])
            f.write(f"| {row['一级工具']} | {row['二级指标']} | {central_cols} | {local_cols} |\n")
        
        f.write("\n## 📊 归一化验证\n\n")
        f.write("| 时间段 | 一级工具 | 中央_归一化总和 | 地方_归一化总和 |\n")
        f.write("| --- | --- | --- | --- |\n")
        for period_name in [p["name"] for p in periods]:
            period_subset = norm_df[norm_df["时间段"] == period_name]
            # 先按一级工具分组显示
            for tool_type in ["供给型", "需求型", "环境型"]:
                subset = period_subset[period_subset["一级工具"] == tool_type]
                if not subset.empty:
                    f.write(f"| {period_name} | {tool_type} | {subset['中央_归一化'].sum():.1f}% | {subset['地方_归一化'].sum():.1f}% |\n")
            # 总计行
            f.write(f"| {period_name} | **【总计】** | **{period_subset['中央_归一化'].sum():.1f}%** | **{period_subset['地方_归一化'].sum():.1f}%** |\n")
    
    print(f"✅ Markdown表格已保存: {md_path}")
    
    return final_df


# ==================== 【核心修改】PolicyVisualizerTool 类 - 柱状图使用分组归一化 ====================

class PolicyVisualizerTool:
    def __init__(self, framework_df: pd.DataFrame, central_freq: Dict, local_freq: Dict,
                 central_count: int, local_count: int):
        self.framework_df = framework_df
        self.central_count = central_count
        self.local_count = local_count
        self.central_freq = central_freq
        self.local_freq = local_freq
        self.output_path = OUTPUT_DIR
        self._build_dataframe()
        self.tool_colors = {"供给型": "#3498db", "需求型": "#2ecc71", "环境型": "#e74c3c"}
    
    def _build_dataframe(self):
        self.data = []
        for _, row in self.framework_df.iterrows():
            indicator, tool_type = row["二级指标"], row["一级工具"]
            central_raw = self.central_freq.get(tool_type, {}).get(indicator, 0)
            local_raw = self.local_freq.get(tool_type, {}).get(indicator, 0)
            central_pct = central_raw / self.central_count * 100 if self.central_count > 0 else 0
            local_pct = local_raw / self.local_count * 100 if self.local_count > 0 else 0
            self.data.append({"二级指标": indicator, "一级工具": tool_type, 
                              "中央": central_pct, "地方": local_pct,
                              "中央原始次数": central_raw, "地方原始次数": local_raw})
        self.df = pd.DataFrame(self.data)
    
    def generate_all(self):
        print("\n正在生成央地政策工具可视化图表...")
        if self.df.empty:
            print("⚠️ 无数据，跳过可视化")
            return
        self._fig_combined_comparison()
        self._fig_type_comparison()
        self._fig_heatmap()
        self._fig_total_comparison()
        self._fig_table()
        print("✅ 所有图表生成完成！")
    
    def _fig_combined_comparison(self):
        """
        修改版：柱状图使用分组归一化数据（每组内总和=100%）
        饼图保持原始数据不变
        """
        if self.df.empty:
            return
        
        # ========== 计算分组归一化数据（仅用于柱状图） ==========
        normalized_data = []
        for tool_type in ['供给型', '需求型', '环境型']:
            subset = self.df[self.df['一级工具'] == tool_type]
            if subset.empty:
                continue
            
            central_sum = subset['中央'].sum()
            local_sum = subset['地方'].sum()
            
            for _, row in subset.iterrows():
                central_norm = (row['中央'] / central_sum * 100) if central_sum > 0 else 0
                local_norm = (row['地方'] / local_sum * 100) if local_sum > 0 else 0
                normalized_data.append({
                    '二级指标': row['二级指标'],
                    '一级工具': row['一级工具'],
                    '中央_归一化': central_norm,
                    '地方_归一化': local_norm,
                    '中央_原始': row['中央'],
                    '地方_原始': row['地方'],
                    '中央原始次数': row['中央原始次数'],
                    '地方原始次数': row['地方原始次数']
                })
        
        norm_df = pd.DataFrame(normalized_data)
        
        fig = plt.figure(figsize=(20, 12))
        tool_colors = {"供给型": "#3498db", "需求型": "#2ecc71", "环境型": "#e74c3c"}
        indicators = self.df['二级指标'].tolist()
        
        # ===== 左上：中央政策柱状图（使用归一化数据） =====
        ax_bar_left = plt.subplot(2, 2, 1)
        bar_colors = [tool_colors[t] for t in norm_df['一级工具']]
        central_vals = norm_df['中央_归一化'].tolist()
        
        bars_left = ax_bar_left.bar(indicators, central_vals, color=bar_colors, 
                                     edgecolor='white', linewidth=1.5, alpha=0.85)
        ax_bar_left.set_xlabel('政策工具指标')
        ax_bar_left.set_ylabel('组内归一化占比 (%)')
        ax_bar_left.set_title('中央政策工具使用分布（组内归一化）')
        ax_bar_left.set_xticklabels(indicators, rotation=45, ha='right', fontsize=9)
        ax_bar_left.set_ylim(0, 50)
        ax_bar_left.grid(True, alpha=0.3, axis='y')
        
        # 添加分组边界线
        self._add_group_boundaries(ax_bar_left, norm_df)
        
        for idx, bar in enumerate(bars_left):
            height = bar.get_height()
            indicator = indicators[idx]
            ax_bar_left.annotate(f'{height:.1f}%', xy=(bar.get_x() + bar.get_width() / 2, height),
                               xytext=(0, 5), textcoords="offset points", ha='center', va='bottom', 
                               fontsize=9, fontweight='bold')
            raw_count = norm_df.loc[norm_df['二级指标'] == indicator, '中央原始次数'].values
            if len(raw_count) > 0:
                ax_bar_left.annotate(f'({raw_count[0]}次)', xy=(bar.get_x() + bar.get_width() / 2, height),
                                   xytext=(0, -15), textcoords="offset points", ha='center', va='bottom', 
                                   fontsize=8, color='#7f8c8d')
        
        # ===== 左下：中央政策饼图（保持原始数据） =====
        ax_pie_left = plt.subplot(2, 2, 3)
        central_by_type = self.df.groupby('一级工具')['中央'].sum()
        colors_pie = [tool_colors[t] for t in central_by_type.index]
        wedges, texts, autotexts = ax_pie_left.pie(central_by_type.values, labels=central_by_type.index,
                                                     colors=colors_pie, autopct='%1.1f%%', startangle=90,
                                                     explode=(0.05, 0.05, 0.05), shadow=True)
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontweight('bold')
            autotext.set_fontsize(11)
        ax_pie_left.set_title('中央政策工具类型分布（原始数据）')
        
        # ===== 右上：地方政策柱状图（使用归一化数据） =====
        ax_bar_right = plt.subplot(2, 2, 2)
        local_vals = norm_df['地方_归一化'].tolist()
        
        bars_right = ax_bar_right.bar(indicators, local_vals, color=bar_colors, 
                                      edgecolor='white', linewidth=1.5, alpha=0.85)
        ax_bar_right.set_xlabel('政策工具指标')
        ax_bar_right.set_ylabel('组内归一化占比 (%)')
        ax_bar_right.set_title('地方政策工具使用分布（组内归一化）')
        ax_bar_right.set_xticklabels(indicators, rotation=45, ha='right', fontsize=9)
        ax_bar_right.set_ylim(0, 50)
        ax_bar_right.grid(True, alpha=0.3, axis='y')
        
        # 添加分组边界线
        self._add_group_boundaries(ax_bar_right, norm_df)
        
        for idx, bar in enumerate(bars_right):
            height = bar.get_height()
            indicator = indicators[idx]
            ax_bar_right.annotate(f'{height:.1f}%', xy=(bar.get_x() + bar.get_width() / 2, height),
                                xytext=(0, 5), textcoords="offset points", ha='center', va='bottom', 
                                fontsize=9, fontweight='bold')
            raw_count = norm_df.loc[norm_df['二级指标'] == indicator, '地方原始次数'].values
            if len(raw_count) > 0:
                ax_bar_right.annotate(f'({raw_count[0]}次)', xy=(bar.get_x() + bar.get_width() / 2, height),
                                    xytext=(0, -15), textcoords="offset points", ha='center', va='bottom', 
                                    fontsize=8, color='#7f8c8d')
        
        # ===== 右下：地方政策饼图（保持原始数据） =====
        ax_pie_right = plt.subplot(2, 2, 4)
        local_by_type = self.df.groupby('一级工具')['地方'].sum()
        wedges, texts, autotexts = ax_pie_right.pie(local_by_type.values, labels=local_by_type.index,
                                                     colors=colors_pie, autopct='%1.1f%%', startangle=90,
                                                     explode=(0.05, 0.05, 0.05), shadow=True)
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontweight('bold')
            autotext.set_fontsize(11)
        ax_pie_right.set_title('地方政策工具类型分布（原始数据）')
        
        # ===== 图例和标题 =====
        legend_elements = [
            Patch(facecolor=tool_colors['供给型'], label='供给型', alpha=0.85),
            Patch(facecolor=tool_colors['需求型'], label='需求型', alpha=0.85),
            Patch(facecolor=tool_colors['环境型'], label='环境型', alpha=0.85)
        ]
        fig.legend(handles=legend_elements, loc='lower center', ncol=3, fontsize=10, bbox_to_anchor=(0.5, 0.02))
        
        fig.suptitle('央地政策工具使用分布对比图\n（柱状图：每组内二级指标总和=100%；饼图：原始数据）', fontsize=14)
        fig.text(0.5, 0.07, 
                '注：柱状图上方标注为组内归一化占比（%），下方标注为原始出现次数；饼状图展示各类型工具的原始占比分布',
                ha='center', fontsize=10, style='italic', 
                bbox=dict(boxstyle='round,pad=0.3', facecolor='#f0f0f0', alpha=0.8))
        plt.tight_layout()
        plt.subplots_adjust(bottom=0.12, hspace=0.35, wspace=0.3)
        plt.savefig(os.path.join(self.output_path, '央地政策工具使用分布对比图.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("央地政策工具使用分布对比图已保存（柱状图已归一化）")
    
    def _add_group_boundaries(self, ax, norm_df):
        """
        在柱状图上添加分组边界线和组标签
        """
        # 计算各组的位置
        groups = ['供给型', '需求型', '环境型']
        group_indices = {}
        for g in groups:
            subset = norm_df[norm_df['一级工具'] == g]
            if not subset.empty:
                group_indices[g] = subset.index.tolist()
        
        # 添加分隔线
        for i, (g, indices) in enumerate(group_indices.items()):
            start, end = min(indices), max(indices)
            if i > 0:
                # 在组之间添加竖直线
                x_pos = start - 0.5
                ax.axvline(x=x_pos, color='gray', linestyle='--', linewidth=1, alpha=0.5)
            
            # 添加组标签（在x轴下方）
            mid = (start + end) / 2
            ax.text(mid, -8, f'{g}', ha='center', va='top', fontsize=10, 
                   fontweight='bold', color=self.tool_colors.get(g, 'black'))
        
        # 调整y轴下边距以显示组标签
        ax.set_ylim(-10, 50)
    
    def _fig_type_comparison(self):
        if self.df.empty:
            return
        fig, axes = plt.subplots(1, 3, figsize=(20, 7))
        for idx, tool in enumerate(['供给型', '需求型', '环境型']):
            td = self.df[self.df['一级工具'] == tool]
            if len(td) == 0:
                continue
            x = np.arange(len(td))
            width = 0.35
            bars1 = axes[idx].bar(x - width/2, td['中央'], width, label='中央', color='#2c7bb6', edgecolor='white')
            bars2 = axes[idx].bar(x + width/2, td['地方'], width, label='地方', color='#d7191c', edgecolor='white')
            axes[idx].set_title(f'{tool}工具央地对比')
            axes[idx].set_xticks(x)
            axes[idx].set_xticklabels(td['二级指标'], rotation=25, ha='right', fontsize=9)
            axes[idx].set_ylabel('使用占比 (%)')
            axes[idx].legend(loc='upper right')
            axes[idx].grid(True, alpha=0.3, axis='y')
            axes[idx].set_ylim(0, 105)
            
            for bar in bars1:
                height = bar.get_height()
                axes[idx].annotate(f'{height:.1f}%', xy=(bar.get_x() + bar.get_width() / 2, height),
                                 xytext=(0, 3), textcoords="offset points", ha='center', va='bottom', fontsize=8, fontweight='bold')
            for bar in bars2:
                height = bar.get_height()
                axes[idx].annotate(f'{height:.1f}%', xy=(bar.get_x() + bar.get_width() / 2, height),
                                 xytext=(0, 3), textcoords="offset points", ha='center', va='bottom', fontsize=8, fontweight='bold')
        plt.suptitle('按政策工具类型划分的央地对比分析')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, '按工具类型央地对比图.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("按工具类型央地对比图已保存")
    
    def _fig_heatmap(self):
        if self.df.empty:
            return
        fig, ax = plt.subplots(figsize=(14, 8))
        self.df['差异值'] = self.df['中央'] - self.df['地方']
        mat = self.df.pivot_table(values='差异值', index='一级工具', columns='二级指标', aggfunc='first')
        im = ax.imshow(mat.values, cmap='RdBu_r', vmin=-20, vmax=20)
        ax.set_xticks(range(len(mat.columns)))
        ax.set_yticks(range(len(mat.index)))
        ax.set_xticklabels(mat.columns, rotation=45, ha='right', fontsize=10)
        ax.set_yticklabels(mat.index, fontsize=11, fontweight='bold')
        ax.set_title('中央与地方政策工具使用差异热力图')
        
        for i in range(len(mat.index)):
            for j in range(len(mat.columns)):
                value = mat.values[i, j]
                if not np.isnan(value):
                    text_color = 'white' if abs(value) > 10 else 'black'
                    ax.text(j, i, f'{value:+.1f}%', ha='center', va='center', fontsize=10, fontweight='bold', color=text_color)
        plt.colorbar(im, ax=ax, label='差异值（百分点，中央-地方）')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, '央地政策工具差异热力图.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("央地政策工具差异热力图已保存")
    
    def _fig_total_comparison(self):
        if self.df.empty:
            return
        fig, ax = plt.subplots(figsize=(10, 6))
        summary = self.df.groupby('一级工具').agg({'中央': 'sum', '地方': 'sum'}).reset_index()
        x = np.arange(len(summary))
        width = 0.35
        bars1 = ax.bar(x - width/2, summary['中央'], width, label='中央政策', color='#2c7bb6', edgecolor='white')
        bars2 = ax.bar(x + width/2, summary['地方'], width, label='地方政策', color='#d7191c', edgecolor='white')
        ax.set_xlabel('政策工具类型')
        ax.set_ylabel('使用占比总和 (%)')
        ax.set_title('央地政策工具使用总量对比')
        ax.set_xticks(x)
        ax.set_xticklabels(summary['一级工具'])
        ax.legend()
        ax.grid(True, alpha=0.3, axis='y')
        
        for bar in bars1:
            height = bar.get_height()
            ax.annotate(f'{height:.1f}%', xy=(bar.get_x() + bar.get_width() / 2, height),
                       xytext=(0, 5), textcoords="offset points", ha='center', va='bottom', fontsize=10, fontweight='bold')
        for bar in bars2:
            height = bar.get_height()
            ax.annotate(f'{height:.1f}%', xy=(bar.get_x() + bar.get_width() / 2, height),
                       xytext=(0, 5), textcoords="offset points", ha='center', va='bottom', fontsize=10, fontweight='bold')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, '央地政策工具总量对比图.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("央地政策工具总量对比图已保存")
    
    def _fig_table(self):
        if self.df.empty:
            return
        fig, ax = plt.subplots(figsize=(16, 10))
        ax.axis('tight')
        ax.axis('off')
        self.df['差异值'] = self.df['中央'] - self.df['地方']
        data = [['一级工具', '二级指标', '中央占比(%)', '地方占比(%)', '差异值(百分点)', '中央次数', '地方次数']]
        for _, r in self.df.iterrows():
            data.append([r['一级工具'], r['二级指标'], f"{r['中央']:.1f}%", f"{r['地方']:.1f}%", 
                        f"{r['差异值']:+.1f}%", r['中央原始次数'], r['地方原始次数']])
        table = ax.table(cellText=data, loc='center', cellLoc='center')
        table.auto_set_font_size(False)
        table.set_fontsize(9)
        table.scale(1.2, 1.6)
        for i in range(len(data[0])):
            table[(0, i)].set_facecolor('#4a9bd9')
            table[(0, i)].set_text_props(weight='bold', color='white')
        ax.set_title('央地政策工具使用对比数据明细表')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, '央地政策工具使用对比数据明细表.png'), dpi=1000, bbox_inches='tight')
        plt.close()
        print("央地政策工具使用对比数据明细表已保存")


class ComparisonTableGenerator:
    def __init__(self, central_freq, local_freq, central_count, local_count):
        self.central_freq = central_freq
        self.local_freq = local_freq
        self.central_count = central_count
        self.local_count = local_count
    
    def generate_all(self):
        indicators = {"供给型": ["基础建设", "人才培养", "资金投入", "科技支持", "公共服务"],
                      "需求型": ["购买服务", "试点示范", "家校社协同", "引导激励"],
                      "环境型": ["法规管制", "目标规划", "质量监管", "策略措施", "宣传推广"]}
        data = []
        for tool_type, inds in indicators.items():
            for indicator in inds:
                central_raw = self.central_freq.get(tool_type, {}).get(indicator, 0)
                local_raw = self.local_freq.get(tool_type, {}).get(indicator, 0)
                central_pct = central_raw / self.central_count * 100 if self.central_count > 0 else 0
                local_pct = local_raw / self.local_count * 100 if self.local_count > 0 else 0
                data.append({"一级工具": tool_type, "二级指标": indicator,
                             "中央(总体)": f"{central_pct:.1f}% ({central_raw})",
                             "地方(总体)": f"{local_pct:.1f}% ({local_raw})"})
        df = pd.DataFrame(data)
        excel_path = os.path.join(OUTPUT_DIR, "央地政策工具使用分布对比表.xlsx")
        df.to_excel(excel_path, index=False)
        print(f"✅ Excel表格已保存: {excel_path}")
        
        md_path = os.path.join(OUTPUT_DIR, "央地政策工具使用分布对比表.md")
        with open(md_path, 'w', encoding='utf-8') as f:
            f.write("# 央地政策工具使用分布对比表\n\n")
            f.write("| 一级工具 | 二级指标 | 中央(总体) | 地方(总体) |\n")
            f.write("| --- | --- | --- | --- |\n")
            for _, row in df.iterrows():
                f.write(f"| {row['一级工具']} | {row['二级指标']} | {row['中央(总体)']} | {row['地方(总体)']} |\n")
        print(f"✅ Markdown表格已保存: {md_path}")
        
        html_path = os.path.join(OUTPUT_DIR, "央地政策工具使用分布对比表.html")
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write("""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>央地政策工具使用分布对比表</title>
<style>
    th, td { border: 1px solid #333; padding: 8px; text-align: center; }
    th { background: #4a9bd9; color: white; }
    table { border-collapse: collapse; margin: 20px auto; }
</style>
</head><body>
<h1>央地政策工具使用分布对比表</h1>
<table>
    <tr><th>一级工具</th><th>二级指标</th><th>中央(总体)</th><th>地方(总体)</th></tr>
""")
            for _, row in df.iterrows():
                f.write(f"    <tr><td>{row['一级工具']}</td><td>{row['二级指标']}</td><td>{row['中央(总体)']}</td><td>{row['地方(总体)']}</td></tr>\n")
            f.write("""</table>
</body></html>""")
        print(f"✅ HTML表格已保存: {html_path}")


# ==================== 模块三：主体部分 ====================

def does_policy_cover_period(years_covered: List[int], start_year: int, end_year: int) -> bool:
    if not years_covered:
        return False
    period_years = set(range(start_year, end_year + 1))
    return any(year in period_years for year in years_covered)


def process_policy_by_coverage(start_year=None, end_year=None, policy_type='central'):
    """
    从Excel读取政策数据，提取部门信息
    优先使用英文名称列，如果没有则使用中文名称
    """
    all_departments = []
    
    # 确定列名
    if policy_type == 'central':
        sheet = SHEET_CENTRAL
        dept_en_col = CENTRAL_DEPT_EN_COL
        dept_cn_col = CENTRAL_DEPT_COL
        year_col = CENTRAL_YEAR_COL
    else:
        sheet = SHEET_LOCAL
        dept_en_col = LOCAL_DEPT_EN_COL
        dept_cn_col = LOCAL_DEPT_COL
        year_col = LOCAL_YEAR_COL
    
    try:
        df = pd.read_excel(EXCEL_PATH, sheet_name=sheet)
        print(f"  Reading {len(df)} {policy_type} policy records")
        
        # 检查英文列是否存在
        has_en_col = dept_en_col in df.columns
        if has_en_col:
            print(f"  ✅ Found English column: '{dept_en_col}'")
        else:
            print(f"  ⚠️ English column '{dept_en_col}' not found, using Chinese column '{dept_cn_col}'")
            
    except Exception as e:
        print(f"  Failed to read {policy_type} policy: {e}")
        return all_departments
    
    # 查找文件名列
    filename_col = None
    for col in POSSIBLE_FILENAME_COLS:
        if col in df.columns:
            filename_col = col
            break
    
    if filename_col is None and len(df.columns) > 0:
        filename_col = df.columns[0]
        print(f"  ⚠️ No filename column found, using: '{filename_col}'")
    
    for idx, row in df.iterrows():
        # ========== 提取年份 ==========
        publish_year = None
        
        if year_col in df.columns:
            publish_year = parse_excel_date(row.get(year_col))
        
        if publish_year is None and filename_col:
            filename = str(row.get(filename_col, "")).replace('.txt', '').replace('.md', '')
            year_match = re.search(r'(201[1-9]|202[0-5])', filename)
            if year_match:
                publish_year = int(year_match.group())
        
        if publish_year is None:
            continue
        
        if start_year is not None and end_year is not None:
            if publish_year < start_year or publish_year > end_year:
                continue
        
        # ========== 提取部门名称 ==========
        if has_en_col:
            departments = extract_departments_from_field_en(row.get(dept_en_col))
        else:
            departments = extract_departments_from_field(row.get(dept_cn_col))
        
        # 如果部门列表为空，尝试另一个列
        if not departments:
            if has_en_col and dept_cn_col in df.columns:
                departments = extract_departments_from_field(row.get(dept_cn_col))
        
        if departments:
            all_departments.append(departments)
    
    print(f"  Extracted {len(all_departments)} department records")
    return all_departments

def build_cooccurrence_network(departments_list, use_weights=True):
    G = nx.Graph()
    for depts in departments_list:
        if len(depts) >= 2:
            for i in range(len(depts)):
                for j in range(i + 1, len(depts)):
                    u, v = depts[i].strip(), depts[j].strip()
                    if u and v and u != v:
                        if G.has_edge(u, v):
                            G[u][v]['weight'] += 1
                        else:
                            G.add_edge(u, v, weight=1)
        elif len(depts) == 1:
            G.add_node(depts[0].strip())
    return G


def calculate_centrality_metrics_weighted(G):
    if G.number_of_nodes() == 0:
        return pd.DataFrame()
    
    n_nodes = G.number_of_nodes()
    
    weighted_degree = {node: sum(d['weight'] for u, v, d in G.edges(node, data=True)) for node in G.nodes()}
    max_weighted_degree = max(weighted_degree.values()) if weighted_degree else 1
    weighted_degree_centrality = {node: round(wd / max_weighted_degree, 4) for node, wd in weighted_degree.items()}
    
    degree_centrality_rel = {node: round(d / (n_nodes - 1), 4) for node, d in dict(G.degree()).items()}
    closeness_centrality = {node: round(val, 4) for node, val in nx.closeness_centrality(G).items()}
    betweenness_centrality = {node: round(val * 100, 2) for node, val in nx.betweenness_centrality(G).items()}
    
    df = pd.DataFrame({
        "发文单位": list(G.nodes()), 
        "相对度数中心度（无权）": [degree_centrality_rel[node] for node in G.nodes()],
        "加权度数中心度": [weighted_degree_centrality[node] for node in G.nodes()],
        "接近中心度": [closeness_centrality[node] for node in G.nodes()],
        "中间中心度": [betweenness_centrality[node] for node in G.nodes()]
    })
    return df.sort_values("加权度数中心度", ascending=False).reset_index(drop=True)


def visualize_network(G, title, filename, policy_type):
    if G.number_of_nodes() == 0:
        print(f"Skipping visualization: {title} - no nodes")
        return
    plt.figure(figsize=(14, 10))
    pos = nx.spring_layout(G, k=1.5, iterations=50, seed=42)
    
    if policy_type == "central":
        node_color = '#3F0180'
        edge_color = '#6A2B8A'
    else:
        node_color = '#D2691E'
        edge_color = '#E87A3E'
    
    edges = G.edges(data=True)
    weights = [d.get('weight', 1) for u, v, d in edges]
    max_weight = max(weights) if weights else 1
    widths = [1 + (w / max_weight) * 3 for w in weights]
    
    nx.draw_networkx_nodes(G, pos, node_size=800, node_color=node_color, alpha=0.85, edgecolors='black')
    nx.draw_networkx_edges(G, pos, width=widths, edge_color=edge_color, alpha=0.5)
    
    # ========== 【修改】标签使用英文标题 ==========
    nx.draw_networkx_labels(G, pos, font_size=10, font_weight='bold')
    plt.title(title)  # title 已经是英文
    plt.axis('off')
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, filename), dpi=800, bbox_inches='tight')
    plt.close()


def visualize_network_comparison(G_central, G_local):
    fig, axes = plt.subplots(1, 2, figsize=(16, 8))
    for ax, (G, title, color) in zip(axes, [(G_central, "中央政策主体网络", '#1E3A5F'), (G_local, "地方政策主体网络", '#D2691E')]):
        if G.number_of_nodes() == 0:
            ax.text(0.5, 0.5, "无数据", ha='center', va='center')
            ax.axis('off')
            continue
        pos = nx.spring_layout(G, k=1.5, iterations=50, seed=42)
        edges = G.edges(data=True)
        weights = [d.get('weight', 1) for u, v, d in edges]
        max_weight = max(weights) if weights else 1
        widths = [1 + (w / max_weight) * 2 for w in weights]
        
        nx.draw_networkx_nodes(G, pos, node_size=800, node_color=color, alpha=0.85, ax=ax)
        nx.draw_networkx_edges(G, pos, width=widths, edge_color=color, alpha=0.5, ax=ax)
        nx.draw_networkx_labels(G, pos, font_size=9, font_weight='bold', ax=ax)
        ax.set_title(title)
        ax.axis('off')
    plt.suptitle("央地政策主体网络对比（边粗细表示合作强度）")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "央地网络对比图.png"), dpi=800, bbox_inches="tight")
    plt.close()


def visualize_degree_distribution(G_central, G_local, period_name):
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, (G, title) in zip(axes, [(G_central, "中央"), (G_local, "地方")]):
        if G.number_of_nodes() == 0:
            ax.text(0.5, 0.5, "无数据", ha='center', va='center')
            ax.axis('off')
            continue
        weighted_degrees = [sum(d.get('weight', 1) for u, v, d in G.edges(node, data=True)) for node in G.nodes()]
        degree_counts = Counter(weighted_degrees)
        ax.bar(degree_counts.keys(), degree_counts.values(), color='#4682B4', alpha=0.7)
        ax.set_xlabel('加权度数')
        ax.set_ylabel('节点数')
        ax.set_title(f'{title} - 加权度数分布')
        ax.grid(True, alpha=0.3)
    plt.suptitle(f"{period_name} 政策主体网络加权度数分布")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, f"加权度数分布_{period_name}.png"), dpi=1000, bbox_inches='tight')
    plt.close()


def visualize_metrics_trend(results):
    periods = [r['period'] for r in results]
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    axes[0,0].plot(periods, [r['c_nodes'] for r in results], 'o-', label='中央', color='#1E3A5F')
    axes[0,0].plot(periods, [r['l_nodes'] for r in results], 's-', label='地方', color='#D2691E')
    axes[0,0].set_title('节点数变化趋势')
    axes[0,0].legend()
    axes[0,0].grid(True, alpha=0.3)
    
    axes[0,1].plot(periods, [r['c_weighted_density'] for r in results], 'o-', label='中央(加权密度)', color='#1E3A5F')
    axes[0,1].plot(periods, [r['l_weighted_density'] for r in results], 's-', label='地方(加权密度)', color='#D2691E')
    axes[0,1].set_title('加权网络密度变化趋势')
    axes[0,1].legend()
    axes[0,1].grid(True, alpha=0.3)
    
    axes[1,0].plot(periods, [r['c_clustering'] for r in results], 'o-', label='中央', color='#1E3A5F')
    axes[1,0].plot(periods, [r['l_clustering'] for r in results], 's-', label='地方', color='#D2691E')
    axes[1,0].set_title('聚类系数变化趋势（加权）')
    axes[1,0].legend()
    axes[1,0].grid(True, alpha=0.3)
    
    axes[1,1].scatter([r['c_weighted_density'] for r in results], [r['c_clustering'] for r in results], label='中央', s=120, c='#1E3A5F')
    axes[1,1].scatter([r['l_weighted_density'] for r in results], [r['l_clustering'] for r in results], label='地方', s=120, c='#D2691E')
    axes[1,1].set_title('密度-聚类系数关系（加权）')
    axes[1,1].legend()
    axes[1,1].grid(True, alpha=0.3)
    
    plt.suptitle('政策主体网络指标时间变化趋势（加权版）')
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "指标趋势图_加权.png"), dpi=1000, bbox_inches='tight')
    plt.close()


def visualize_centrality_bar_chart(df_central, df_local):
    if df_central.empty or df_local.empty:
        print("⚠️ 中心性数据为空，跳过柱状图生成")
        return
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    top_central = df_central.head(10).copy()
    x = np.arange(len(top_central))
    axes[0].bar(x - 0.3, top_central["相对度数中心度（无权）"], 0.3, label="相对度数中心度（无权）", color="#1E3A5F")
    axes[0].bar(x, top_central["加权度数中心度"], 0.3, label="加权度数中心度", color="#4682B4")
    axes[0].set_title("中央政策主体中心性指标")
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(top_central["发文单位"], rotation=45, ha="right", fontsize=9)
    axes[0].legend()
    
    top_local = df_local.head(10).copy()
    x = np.arange(len(top_local))
    axes[1].bar(x - 0.3, top_local["相对度数中心度（无权）"], 0.3, label="相对度数中心度（无权）", color="#D2691E")
    axes[1].bar(x, top_local["加权度数中心度"], 0.3, label="加权度数中心度", color="#E87A3E")
    axes[1].set_title("地方政策主体中心性指标")
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(top_local["发文单位"], rotation=45, ha="right", fontsize=9)
    axes[1].legend()
    
    plt.suptitle("央地政策主体协作网络中心性指标对比（无权 vs 加权）")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "中心性指标柱状图_加权.png"), dpi=1000, bbox_inches="tight")
    plt.close()


def visualize_centrality_radar(df_central, df_local):
    if df_central.empty or df_local.empty:
        print("⚠️ 中心性数据为空，跳过雷达图生成")
        return
    
    # ========== 【修复1】设置英文字体 ==========
    plt.rcParams['font.sans-serif'] = ['Arial', 'Helvetica', 'DejaVu Sans', 'Tahoma', 'Verdana']
    plt.rcParams['font.family'] = 'sans-serif'
    plt.rcParams['axes.unicode_minus'] = False
    
    # ========== 【修复2】长标签换行函数 ==========
    def wrap_label(label, max_len=8):
        if '(' in label and ')' in label:
            parts = label.split('(')
            if len(parts) >= 2:
                return f"{parts[0].strip()}\n({parts[1].strip()}"
        if len(label) > max_len:
            words = label.split()
            if len(words) >= 2:
                mid = len(words) // 2
                return '\n'.join([' '.join(words[:mid]), ' '.join(words[mid:])])
            if '_' in label:
                parts = label.split('_')
                if len(parts) >= 2:
                    mid = len(parts) // 2
                    return '\n'.join(['_'.join(parts[:mid]), '_'.join(parts[mid:])])
        return label
    
    fig, axes = plt.subplots(1, 2, figsize=(16, 8), subplot_kw={'projection': 'polar'})
    
    # ========== 中央雷达图 ==========
    top5_central = df_central.head(5)
    categories = [wrap_label(label, 8) for label in top5_central["发文单位"].tolist()]
    N = len(categories)
    angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
    angles += angles[:1]
    
    values = top5_central["加权度数中心度"].tolist() + [top5_central["加权度数中心度"].tolist()[0]]
    axes[0].plot(angles, values, 'o-', linewidth=3, color='#1E3A5F', markersize=8)
    axes[0].fill(angles, values, alpha=0.25, color='#1E3A5F')
    axes[0].set_xticks(angles[:-1])
    axes[0].set_xticklabels(categories, fontsize=20, fontweight='bold', ha='center')
    axes[0].set_ylim(0, 1.1)
    # ========== 【修改1】标题改为 "Central Top 5"，字体20加粗 ==========
    axes[0].set_title("Central Top 5", fontsize=20, fontweight='bold')
    axes[0].grid(True, alpha=0.3)
    # ========== 刻度标签字体20加粗 ==========
    axes[0].tick_params(labelsize=20)
    
    # ========== 地方雷达图 ==========
    top5_local = df_local.head(5)
    categories = [wrap_label(label, 8) for label in top5_local["发文单位"].tolist()]
    N = len(categories)
    angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
    angles += angles[:1]
    
    values = top5_local["加权度数中心度"].tolist() + [top5_local["加权度数中心度"].tolist()[0]]
    axes[1].plot(angles, values, 'o-', linewidth=3, color='#D2691E', markersize=8)
    axes[1].fill(angles, values, alpha=0.25, color='#D2691E')
    axes[1].set_xticks(angles[:-1])
    axes[1].set_xticklabels(categories, fontsize=20, fontweight='bold', ha='center')
    axes[1].set_ylim(0, 1.1)
    # ========== 【修改2】标题改为 "Local Top 5"，字体20加粗 ==========
    axes[1].set_title("Local Top 5", fontsize=20, fontweight='bold')
    axes[1].grid(True, alpha=0.3)
    # ========== 刻度标签字体20加粗 ==========
    axes[1].tick_params(labelsize=20)
    
    # ========== 【修改3】总标题字体20加粗 ==========
    plt.suptitle("Central-Local Policy Actor Centrality Radar Comparison", 
                 fontsize=20, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "中心性雷达图_加权.png"), dpi=1000, bbox_inches="tight")
    plt.close()
    print("✅ 中心性雷达图已保存（全部字体20加粗）")

def k_clique_analysis(G, k=3):
    cliques = list(nx.find_cliques(G))
    return [c for c in cliques if len(c) >= k]


def k_core_analysis(G):
    core_numbers = nx.core_number(G)
    cores = {}
    for node, k in core_numbers.items():
        if k not in cores:
            cores[k] = []
        cores[k].append(node)
    return core_numbers, cores


def visualize_subgroups(G, subgroups, title, filename, policy_type, max_subgroups=8):
    if len(subgroups) == 0:
        print(f"跳过可视化: {title} - 无子群")
        return
    
    sorted_subgroups = sorted(subgroups, key=lambda x: (-len(x), sorted(x)))
    
    plt.figure(figsize=(14, 10))
    colors = ['#1E3A5F', '#D2691E', '#2E8B57', '#9370DB', '#DC143C', '#FF8C00', 
              '#00CED1', '#FF69B4', '#3CB371', '#CD5C5C', '#6A5ACD', '#FFD700', 
              '#20B2AA', '#FF6347', '#4169E1', '#DB7093']
    
    node_colors = {}
    for i, group in enumerate(sorted_subgroups[:max_subgroups]):
        color = colors[i % len(colors)]
        for node in group:
            node_colors[node] = color
    
    for node in G.nodes():
        if node not in node_colors:
            node_colors[node] = '#A9A9A9'
    
    pos = nx.spring_layout(G, k=1.5, iterations=50, seed=42)
    
    edges = G.edges(data=True)
    weights = [d.get('weight', 1) for u, v, d in edges]
    max_weight = max(weights) if weights else 1
    widths = [1 + (w / max_weight) * 2 for w in weights]
    
    nx.draw_networkx_edges(G, pos, width=widths, edge_color='#C0C0C0', alpha=0.6)
    degrees = dict(G.degree())
    
    for color in set(node_colors.values()):
        nodes_with_color = [node for node in G.nodes() if node_colors[node] == color]
        if nodes_with_color:
            sizes = [800 + degrees[node] * 30 for node in nodes_with_color]
            nx.draw_networkx_nodes(G, pos, nodelist=nodes_with_color, 
                                   node_size=sizes, node_color=color,
                                   alpha=0.85, edgecolors='black', linewidths=1.5)
    
    nx.draw_networkx_labels(G, pos, font_size=10, font_weight='bold')
    
    legend_elements = []
    for i in range(min(len(sorted_subgroups), max_subgroups)):
        color = colors[i % len(colors)]
        legend_elements.append(Patch(facecolor=color, label=f'派系{i+1}', alpha=0.85))
    legend_elements.append(Patch(facecolor='#A9A9A9', label='未分组节点', alpha=0.85))
    plt.legend(handles=legend_elements, loc='upper left', bbox_to_anchor=(1, 1), fontsize=10)
    plt.title(title)
    plt.axis('off')
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, filename), dpi=1000, bbox_inches='tight')
    plt.close()
    print(f"核心协作派系图已保存: {filename}")


def export_subgroup_analysis_to_excel(G_central_full, G_local_full, central_cliques_3, local_cliques_3,
                                       central_cores, local_cores):
    filepath = os.path.join(OUTPUT_DIR, "凝聚子群分析结果.xlsx")
    with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
        central_cliques_data = []
        for i, clique in enumerate(central_cliques_3):
            for node in clique:
                central_cliques_data.append({"派系编号": i+1, "节点": node})
        if central_cliques_data:
            pd.DataFrame(central_cliques_data).to_excel(writer, sheet_name="中央K-派系", index=False)
        else:
            pd.DataFrame({"说明": ["未检测到3-派系"]}).to_excel(writer, sheet_name="中央K-派系", index=False)
        
        local_cliques_data = []
        for i, clique in enumerate(local_cliques_3):
            for node in clique:
                local_cliques_data.append({"派系编号": i+1, "节点": node})
        if local_cliques_data:
            pd.DataFrame(local_cliques_data).to_excel(writer, sheet_name="地方K-派系", index=False)
        else:
            pd.DataFrame({"说明": ["未检测到3-派系"]}).to_excel(writer, sheet_name="地方K-派系", index=False)
        
        central_cores_data = [{"节点": node, "K-核值": k} for node, k in central_cores.items()]
        if central_cores_data:
            pd.DataFrame(central_cores_data).to_excel(writer, sheet_name="中央K-核值", index=False)
        
        local_cores_data = [{"节点": node, "K-核值": k} for node, k in local_cores.items()]
        if local_cores_data:
            pd.DataFrame(local_cores_data).to_excel(writer, sheet_name="地方K-核值", index=False)
        
        central_core_nodes = [node for node, k in central_cores.items() if k >= 3]
        local_core_nodes = [node for node, k in local_cores.items() if k >= 3]
        core_participants = []
        for node in central_core_nodes:
            core_participants.append({"政策类型": "中央", "节点": node, "K-核值": central_cores[node]})
        for node in local_core_nodes:
            core_participants.append({"政策类型": "地方", "节点": node, "K-核值": local_cores[node]})
        if core_participants:
            pd.DataFrame(core_participants).to_excel(writer, sheet_name="核心协作派系", index=False)
        else:
            pd.DataFrame({"说明": ["未检测到核心协作派系（K-核值≥3）"]}).to_excel(writer, sheet_name="核心协作派系", index=False)
        
        edge_weight_stats = []
        for u, v, d in G_central_full.edges(data=True):
            edge_weight_stats.append({"政策类型": "中央", "节点A": u, "节点B": v, "合作次数": d.get('weight', 1)})
        for u, v, d in G_local_full.edges(data=True):
            edge_weight_stats.append({"政策类型": "地方", "节点A": u, "节点B": v, "合作次数": d.get('weight', 1)})
        if edge_weight_stats:
            pd.DataFrame(edge_weight_stats).to_excel(writer, sheet_name="边权重统计", index=False)
        
    print(f"✅ 凝聚子群分析结果已导出: {filepath}")


def export_faction_analysis_plots(G_central_full, G_local_full, central_cliques_3, local_cliques_3):
    print("\n导出派系分析PNG文件...")
    
    if len(central_cliques_3) > 0:
        visualize_subgroups(
            G_central_full, central_cliques_3,
            "中央政策主体核心协作派系", "中央_派系分析.png", "central"
        )
    else:
        fig, ax = plt.subplots(figsize=(10, 8))
        ax.text(0.5, 0.5, "未检测到3-派系", ha='center', va='center', fontsize=16)
        ax.set_title("中央政策主体核心协作派系")
        ax.axis('off')
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, "中央_派系分析.png"), dpi=1000, bbox_inches='tight')
        plt.close()
    
    if len(local_cliques_3) > 0:
        visualize_subgroups(
            G_local_full, local_cliques_3,
            "地方政策主体核心协作派系", "地方_派系分析.png", "local"
        )
    else:
        fig, ax = plt.subplots(figsize=(10, 8))
        ax.text(0.5, 0.5, "未检测到3-派系", ha='center', va='center', fontsize=16)
        ax.set_title("地方政策主体核心协作派系")
        ax.axis('off')
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, "地方_派系分析.png"), dpi=1000, bbox_inches='tight')
        plt.close()

def visualize_faction_comparison(G_central_full, G_local_full, central_cliques_3, local_cliques_3):
    print("\nGenerating Central-Local Core Collaborative Faction Network Comparison...")
    
    # ========== 子标题颜色（深橙红） ==========
    SUBTITLE_COLOR = '#C0392B'
    # ========== 主标题颜色（黑色） ==========
    MAIN_TITLE_COLOR = 'black'
    
    colors = ['#1E3A5F', '#D2691E', '#2E8B57', '#9370DB', '#DC143C', '#FF8C00', 
              '#00CED1', '#FF69B4', '#3CB371', '#CD5C5C', '#6A5ACD', '#FFD700', 
              '#20B2AA', '#FF6347', '#4169E1', '#DB7093']
    
    fig, axes = plt.subplots(1, 2, figsize=(38, 34))
    
    sorted_central_cliques = sorted(central_cliques_3, key=lambda x: (-len(x), sorted(x)))
    sorted_local_cliques = sorted(local_cliques_3, key=lambda x: (-len(x), sorted(x)))
    
    def draw_with_smart_labels(G, cliques, ax, title_text, colors_list):
        if G.number_of_nodes() == 0 or len(cliques) == 0:
            ax.text(0.5, 0.5, "No 3-cliques detected", ha='center', va='center', fontsize=40, color=SUBTITLE_COLOR)
            ax.set_title(title_text, fontsize=40, fontweight='bold', color=SUBTITLE_COLOR)
            ax.axis('off')
            return
        
        node_colors = {}
        for i, group in enumerate(cliques[:8]):
            color = colors_list[i % len(colors_list)]
            for node in group:
                node_colors[node] = color
        
        for node in G.nodes():
            if node not in node_colors:
                node_colors[node] = '#A9A9A9'
        
        # ========== 节点距离 k=10.0 ==========
        pos = nx.spring_layout(G, k=10.0, iterations=200, seed=42)
        
        # ========== 纵轴拉伸（将y坐标乘以1.8） ==========
        for node in pos:
            x, y = pos[node]
            pos[node] = (x, y * 1.8)
        
        degrees = dict(G.degree())
        sizes = [500 + degrees[node] * 25 for node in G.nodes()]
        
        edges = G.edges(data=True)
        edge_colors = []
        edge_widths = []
        
        for u, v, d in edges:
            weight = d.get('weight', 1)
            color_u = node_colors.get(u, '#A9A9A9')
            color_v = node_colors.get(v, '#A9A9A9')
            
            if color_u == color_v and color_u != '#A9A9A9':
                edge_colors.append(color_u)
                # ========== 同派系连线再次加粗一倍：原来是 3.0 + weight * 1.0，现在变为 6.0 + weight * 2.0 ==========
                edge_widths.append(6.0 + weight * 2.0)
            else:
                edge_colors.append('#D0D0D0')
                # ========== 跨派系连线再次加粗一倍：原来是 1.0 + weight * 0.6，现在变为 2.0 + weight * 1.2 ==========
                edge_widths.append(2.0 + weight * 1.2)
        
        nx.draw_networkx_edges(G, pos, edgelist=edges, width=edge_widths, 
                               edge_color=edge_colors, alpha=0.7, ax=ax)
        
        for color in set(node_colors.values()):
            nodes_with_color = [node for node in G.nodes() if node_colors[node] == color]
            if nodes_with_color:
                sizes_for_color = [sizes[list(G.nodes()).index(node)] for node in nodes_with_color]
                nx.draw_networkx_nodes(G, pos, nodelist=nodes_with_color, 
                                       node_size=sizes_for_color, node_color=color,
                                       alpha=0.85, edgecolors='black', linewidths=1.0, ax=ax)
        
        # ========== 标签紧贴节点 ==========
        all_y = [pos[node][1] for node in G.nodes()]
        sorted_nodes = sorted(G.nodes(), key=lambda n: pos[n][1])
        used_y_positions = {}
        
        for i, node in enumerate(sorted_nodes):
            x, y = pos[node]
            node_name = str(node)
            name_len = len(node_name)
            
            if name_len >= 12:
                base_offset = 0.02
            elif name_len >= 8:
                base_offset = 0.015
            elif name_len >= 5:
                base_offset = 0.012
            else:
                base_offset = 0.008
            
            y_dist_prev = float('inf')
            y_dist_next = float('inf')
            
            if i > 0:
                prev_node = sorted_nodes[i - 1]
                y_dist_prev = abs(pos[prev_node][1] - y)
            if i < len(sorted_nodes) - 1:
                next_node = sorted_nodes[i + 1]
                y_dist_next = abs(pos[next_node][1] - y)
            
            if min(y_dist_prev, y_dist_next) < 0.10:
                base_offset *= 1.2
            
            rank = i / len(sorted_nodes)
            if rank < 0.25:
                direction = 1
                va = 'bottom'
            elif rank > 0.75:
                direction = -1
                va = 'top'
            else:
                if y_dist_prev < y_dist_next:
                    direction = 1
                    va = 'bottom'
                else:
                    direction = -1
                    va = 'top'
            
            offset_y = y + direction * base_offset
            
            attempts = 0
            while attempts < 8:
                conflict = False
                for used_node, used_y in used_y_positions.items():
                    if abs(offset_y - used_y) < 0.02:
                        conflict = True
                        if direction == 1:
                            offset_y += 0.015 + attempts * 0.008
                        else:
                            offset_y -= 0.015 + attempts * 0.008
                        break
                if not conflict:
                    break
                attempts += 1
            
            used_y_positions[node] = offset_y
            
            ax.text(x, offset_y, node_name, fontsize=40, fontweight='bold',
                   ha='center', va=va, color='black')
        
        ax.set_title(title_text, fontsize=40, fontweight='bold', color=SUBTITLE_COLOR)
        ax.axis('off')
    
    draw_with_smart_labels(G_central_full, sorted_central_cliques, axes[0], 'Central', colors)
    draw_with_smart_labels(G_local_full, sorted_local_cliques, axes[1], 'Local', colors)
    
    plt.suptitle('Central-Local Core Collaborative Faction Network Comparison', 
                 fontsize=40, fontweight='bold', color=MAIN_TITLE_COLOR)
    plt.tight_layout()
    
    output_path = os.path.join(OUTPUT_DIR, '央地核心协作派系网络对比图.png')
    plt.savefig(output_path, dpi=600, bbox_inches='tight')
    plt.close()
    
    print(f"✅ Core Faction Network saved (k=10.0, y-stretch=1.8, font size 40, dpi=600, edges 4x thicker): {output_path}")

def export_network_summary_table_v23(
    G_central_full, G_local_full,
    G_central_2011_2015, G_local_2011_2015,
    G_central_2016_2020, G_local_2016_2020,
    G_central_2021_2025, G_local_2021_2025
):
    print("\n导出网络整体特征表（四个时间段）...")
    
    metrics = ['节点数', '边数', '加权网络密度', '平均聚类系数', '平均路径长度']
    
    periods = ['2011-2025', '2011-2015', '2016-2020', '2021-2025']
    period_networks = {
        '2011-2025': ('central', G_central_full, 'local', G_local_full),
        '2011-2015': ('central', G_central_2011_2015, 'local', G_local_2011_2015),
        '2016-2020': ('central', G_central_2016_2020, 'local', G_local_2016_2020),
        '2021-2025': ('central', G_central_2021_2025, 'local', G_local_2021_2025)
    }
    
    def get_network_metrics(G):
        if G.number_of_nodes() == 0:
            return {
                '节点数': 0,
                '边数': 0,
                '加权网络密度': 0,
                '平均聚类系数': 0,
                '平均路径长度': 0
            }
        
        n_nodes = G.number_of_nodes()
        n_edges = G.number_of_edges()
        
        total_weight = sum(d.get('weight', 1) for u, v, d in G.edges(data=True))
        max_weight = max([d.get('weight', 1) for u, v, d in G.edges(data=True)] or [1])
        max_possible = n_nodes * (n_nodes - 1) / 2 * max_weight if n_nodes > 1 else 1
        weighted_density = total_weight / max_possible if max_possible > 0 else 0
        
        if n_nodes > 0:
            avg_clustering = nx.average_clustering(G, weight='weight')
        else:
            avg_clustering = 0
        
        if n_nodes > 1:
            if nx.is_connected(G):
                avg_path = nx.average_shortest_path_length(G)
            else:
                largest_cc = max(nx.connected_components(G), key=len)
                subgraph = G.subgraph(largest_cc)
                avg_path = nx.average_shortest_path_length(subgraph) if subgraph.number_of_nodes() > 1 else 0
        else:
            avg_path = 0
        
        return {
            '节点数': n_nodes,
            '边数': n_edges,
            '加权网络密度': round(weighted_density, 6),
            '平均聚类系数': round(avg_clustering, 6),
            '平均路径长度': round(avg_path, 4) if avg_path else 0
        }
    
    data = []
    for metric in metrics:
        row = {'指标': metric}
        for period in periods:
            central_net = period_networks[period][1]
            local_net = period_networks[period][3]
            
            central_metrics = get_network_metrics(central_net)
            local_metrics = get_network_metrics(local_net)
            
            row[f'{period} 中央'] = central_metrics[metric]
            row[f'{period} 地方'] = local_metrics[metric]
        
        data.append(row)
    
    result_df = pd.DataFrame(data)
    
    cols = ['指标']
    for period in periods:
        cols.append(f'{period} 中央')
        cols.append(f'{period} 地方')
    result_df = result_df[cols]
    
    filepath = os.path.join(OUTPUT_DIR, "表5_网络整体特征.xlsx")
    with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
        result_df.to_excel(writer, sheet_name="表5", index=False)
        
        note_df = pd.DataFrame({
            "说明项": ["表格说明", "指标说明", "时间段说明", "计算方法", "生成时间"],
            "内容": ["表5_网络整体特征：央地政策主体网络指标汇总（四个时间段）",
                    "节点数：网络中的部门数量；边数：部门间的合作连接数；加权网络密度：考虑合作次数的网络密度；平均聚类系数：节点的聚集程度；平均路径长度：网络的平均距离",
                    "2011-2025：全时段；2011-2015：十二五；2016-2020：十三五；2021-2025：十四五",
                    "加权网络密度 = 总权重 / 最大可能权重；平均路径长度基于最大连通子图计算",
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S")]
        })
        note_df.to_excel(writer, sheet_name="说明", index=False)
    
    print(f"✅ 网络整体特征表已保存: {filepath}")
    
    csv_path = os.path.join(OUTPUT_DIR, "表5_网络整体特征.csv")
    result_df.to_csv(csv_path, index=False, encoding='utf-8-sig')
    
    return result_df


# ==================== 【修改点1】visualize_four_period_networks 函数 - 节点标签字体改为12 ====================

def visualize_four_period_networks(
    G_central_full, G_local_full,
    G_central_2011_2015, G_local_2011_2015,
    G_central_2016_2020, G_local_2016_2020,
    G_central_2021_2025, G_local_2021_2025
):
    print("\nGenerating four-period central-local network comparison...")
    
    # ========== 颜色设置 ==========
    SUBTITLE_COLOR = '#C0392B'  # 子标题：深橙红
    MAIN_TITLE_COLOR = 'black'  # 主标题：黑色
    
    def draw_period_subplot(G, ax, title, node_color='#9370DB', edge_color='#7B68EE'):
        if G.number_of_nodes() == 0:
            ax.text(0.5, 0.5, "No Data", ha='center', va='center', fontsize=40, color=SUBTITLE_COLOR)
            ax.axis('off')
            ax.set_title(title, fontsize=40, fontweight='bold', color=SUBTITLE_COLOR)
            return
        
        # ========== 固定节点位置 ==========
        pos = nx.spring_layout(G, k=10.0, iterations=200, seed=42)
        
        # ========== 判断时间段 ==========
        is_local = (node_color == '#D2691E')
        is_local_full_2025 = (title == "2011-2025\n(Full Period)" and is_local)
        is_local_2011_2015 = (title == "2011-2015" and is_local)
        is_local_2016_2020 = (title == "2016-2020" and is_local)
        is_local_2021_2025 = (title == "2021-2025" and is_local)
        
        # ========== 纵轴拉伸 ==========
        if is_local_full_2025 or is_local_2011_2015:
            y_stretch = 35.0
        elif is_local_2016_2020 or is_local_2021_2025:
            y_stretch = 12.0
        else:
            y_stretch = 8.0
        
        for node in pos:
            x, y = pos[node]
            pos[node] = (x, y * y_stretch)
        
        degrees = dict(G.degree())
        node_sizes = [500 + degrees[node] * 30 for node in G.nodes()]
        
        edges = G.edges(data=True)
        weights = [d.get('weight', 1) for u, v, d in edges]
        max_weight = max(weights) if weights else 1
        # ========== 连线加粗2倍 ==========
        widths = [4.0 + (w / max_weight) * 16 for w in weights]
        
        nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color=node_color,
                               alpha=0.85, edgecolors='black', linewidths=1.0, ax=ax)
        nx.draw_networkx_edges(G, pos, width=widths, edge_color=edge_color, alpha=0.5, ax=ax)
        
        # ========== 按y坐标排序 ==========
        sorted_nodes = sorted(G.nodes(), key=lambda n: pos[n][1], reverse=True)
        
        # ========== 存储已使用标签的y坐标 ==========
        used_label_info = []  # 存储 (label_x, label_y, name_len)
        
        # ========== 辅助函数：根据名称长度获取检测阈值 ==========
        def get_thresholds(name_len):
            if name_len >= 15:
                return 0.85, 0.85
            elif name_len >= 12:
                return 0.75, 0.75
            elif name_len >= 8:
                return 0.65, 0.65
            elif name_len >= 5:
                return 0.55, 0.55
            else:
                return 0.45, 0.45
        
        for i, node in enumerate(sorted_nodes):
            x, y = pos[node]
            node_name = str(node)
            name_len = len(node_name)
            
            # ========== 根据时间段设置偏移量 ==========
            if is_local_full_2025 or is_local_2011_2015:
                if name_len >= 15:
                    base_offset = 2.50
                elif name_len >= 12:
                    base_offset = 2.16
                elif name_len >= 8:
                    base_offset = 1.82
                elif name_len >= 5:
                    base_offset = 1.48
                else:
                    base_offset = 1.14
                
                step = 0.20
                max_attempts = 350
            elif is_local_2016_2020 or is_local_2021_2025:
                if name_len >= 15:
                    base_offset = 0.57
                elif name_len >= 12:
                    base_offset = 0.51
                elif name_len >= 8:
                    base_offset = 0.45
                elif name_len >= 5:
                    base_offset = 0.40
                else:
                    base_offset = 0.32
                
                step = 0.12
                max_attempts = 120
            else:
                if name_len >= 12:
                    base_offset = 0.40
                elif name_len >= 8:
                    base_offset = 0.34
                elif name_len >= 5:
                    base_offset = 0.28
                else:
                    base_offset = 0.23
                
                step = 0.08
                max_attempts = 70
            
            # ========== 根据垂直位置决定偏移方向 ==========
            y_range = max([pos[n][1] for n in G.nodes()]) - min([pos[n][1] for n in G.nodes()])
            if y_range == 0:
                y_range = 1
            relative_y = (y - min([pos[n][1] for n in G.nodes()])) / y_range
            
            if relative_y > 0.7:
                direction = 1
            elif relative_y < 0.3:
                direction = -1
            else:
                direction = 1 if i % 2 == 0 else -1
            
            # ========== 水平位置保持不变 ==========
            offset_x = x
            
            # ========== 获取动态阈值 ==========
            dx_threshold, dy_threshold = get_thresholds(name_len)
            
            # ========== 尝试找到无重叠的位置 ==========
            offset_y = y + direction * base_offset
            
            attempts = 0
            while attempts < max_attempts:
                overlap = False
                for used_x, used_y, used_len in used_label_info:
                    dx = abs(offset_x - used_x)
                    dy = abs(offset_y - used_y)
                    
                    if dx < dx_threshold and dy < dy_threshold:
                        overlap = True
                        if direction == 1:
                            offset_y += step + attempts * 0.025
                        else:
                            offset_y -= step + attempts * 0.025
                        break
                
                if not overlap:
                    break
                attempts += 1
            
            # ========== 如果仍然重叠，强制移动 ==========
            if attempts >= max_attempts:
                if direction == 1:
                    offset_y = y + 3.5
                else:
                    offset_y = y - 3.5
            
            # 记录标签信息
            used_label_info.append((offset_x, offset_y, name_len))
            
            # ========== 设置对齐方式 ==========
            if offset_y > y + 0.02:
                va = 'bottom'
            elif offset_y < y - 0.02:
                va = 'top'
            else:
                va = 'center'
            
            ha = 'center'
            
            if name_len <= 3:
                va = 'center'
            
            ax.text(offset_x, offset_y, node_name, fontsize=40, fontweight='bold',
                   ha=ha, va=va, color='black')
        
        # ========== 【手动移动特定标签】 ==========
        manual_fixes = {}
        
        # 地方 2011-2025 中的标签
        if is_local_full_2025:
            manual_fixes.update({
                "Provincial Development & Reform Commission": {"dy": 0.35, "ha": "center", "va": "bottom"},
                "Local People's Congress": {"dy": 0.90, "ha": "center", "va": "bottom"},
                "Provincial Human Resources & Social Security Department": {"dy": 0.30, "ha": "center", "va": "bottom"},
                "Provincial Government Department": {"dy": -0.30, "ha": "center", "va": "top"},
            })
        
        # 地方 2011-2015 中的标签
        if is_local_2011_2015:
            manual_fixes.update({
                "Provincial Youth League Committee": {"dy": 0.30, "ha": "center", "va": "bottom"},
                "Provincial Government": {"dy": -0.25, "ha": "center", "va": "top"},
                "Provincial Health Commission": {"dy": -0.25, "ha": "center", "va": "top"},
            })
        
        # 地方 2016-2020 中的标签
        if is_local_2016_2020:
            manual_fixes.update({
                "Provincial Education Authority": {"dy": -0.25, "ha": "center", "va": "top"},
                "Provincial Radio & Television Administration": {"dy": -0.15, "ha": "center", "va": "top"},
                "Provincial Government": {"dy": -0.25, "ha": "center", "va": "top"},
            })

        # 地方 2021-2025 中的标签
        if is_local_2021_2025:
            manual_fixes.update({
                "Local People's Congress": {"dy": -0.40, "ha": "center", "va": "top"},
                "Provincial Party Committee": {"dy": -0.55, "ha": "center", "va": "top"},
                "Provincial Human Resources & Social Security Department": {"dy": -0.15, "ha": "center", "va": "top"},
                "Provincial Development & Reform Commission": {"dy": -0.40, "ha": "center", "va": "top"},
                "Social Organization": {"dy": 0.30, "ha": "center", "va": "bottom"},
                "Provincial Radio & Television Administration": {"dy": 0.40, "ha": "center", "va": "bottom"},
                "Provincial Finance Department": {"dy": 0.15, "ha": "center", "va": "bottom"},
                    })

        # 中央 2011-2025 中的标签
        if title == "2011-2025\n(Full Period)" and not is_local:
            manual_fixes.update({
                "National Youth Campus Football Work Leading Group Office": {"dy": -0.30, "ha": "center", "va": "top"},
            })
        
        # 应用手动移动
        for text_obj in ax.texts:
            label = text_obj.get_text()
            if label in manual_fixes:
                fix = manual_fixes[label]
                x, y = text_obj.get_position()
                new_y = y + fix["dy"]
                text_obj.set_position((x, new_y))
                text_obj.set_ha(fix["ha"])
                text_obj.set_va(fix["va"])
        
        ax.set_title(title, fontsize=40, fontweight='bold', color=SUBTITLE_COLOR)
        ax.axis('off')
    
    # ========== 中央网络（保持不变：36×36，500 DPI） ==========
    fig, axes = plt.subplots(2, 2, figsize=(36, 36))
    
    central_networks = [
        (G_central_full, "2011-2025\n(Full Period)"),
        (G_central_2011_2015, "2011-2015"),
        (G_central_2016_2020, "2016-2020"),
        (G_central_2021_2025, "2021-2025")
    ]
    
    for idx, (G, title) in enumerate(central_networks):
        ax = axes[idx // 2, idx % 2]
        draw_period_subplot(G, ax, title, node_color='#9370DB', edge_color='#7B68EE')
    
    plt.suptitle('Central Policy Actor Network Comparison (Four Periods)', 
                 fontsize=40, fontweight='bold', color=MAIN_TITLE_COLOR)
    plt.subplots_adjust(left=0.02, right=0.98, top=0.92, bottom=0.05, wspace=0.35, hspace=0.15)
    # ========== 中央网络 DPI=500 ==========
    plt.savefig(os.path.join(OUTPUT_DIR, '中央网络_四时段对比图.png'), dpi=500, bbox_inches='tight')
    plt.close()
    print("Central network saved (figsize=36x36, dpi=500, edges 2x thicker)")
    
    # ========== 地方网络（修改为：30×30，500 DPI） ==========
    fig, axes = plt.subplots(2, 2, figsize=(30, 30))
    
    local_networks = [
        (G_local_full, "2011-2025\n(Full Period)"),
        (G_local_2011_2015, "2011-2015"),
        (G_local_2016_2020, "2016-2020"),
        (G_local_2021_2025, "2021-2025")
    ]
    
    for idx, (G, title) in enumerate(local_networks):
        ax = axes[idx // 2, idx % 2]
        draw_period_subplot(G, ax, title, node_color='#D2691E', edge_color='#E87A3E')
    
    plt.suptitle('Local Policy Actor Network Comparison (Four Periods)', 
                 fontsize=40, fontweight='bold', color=MAIN_TITLE_COLOR)
    plt.subplots_adjust(left=0.02, right=0.98, top=0.92, bottom=0.05, wspace=0.35, hspace=0.15)
    # ========== 地方网络 DPI=500 ==========
    plt.savefig(os.path.join(OUTPUT_DIR, '地方网络_四时段对比图.png'), dpi=500, bbox_inches='tight')
    plt.close()
    print("Local network saved (figsize=30x30, dpi=500, edges 2x thicker)")

# ==================== 模块四：三维协同分析 ====================

class ThreeDimensionAnalyzer:
    def __init__(self, output_dir: str, tool_coder: PolicyTextCoder = None):
        self.output_dir = output_dir
        self.tool_coder = tool_coder
        self.tool_categories = ['供给型', '需求型', '环境型']
    
    def get_tool_vectors(self, texts):
        if self.tool_coder is None:
            return np.zeros((len(texts), len(self.tool_categories)))
        return np.array([self.tool_coder.get_tool_vector(text) for text in texts])
    
    def build_theme_tool_matrix(self, doc_theme, doc_tools, theme_names):
        n_docs, n_themes = doc_theme.shape
        n_tools = len(self.tool_categories)
        doc_tools_norm = doc_tools / (doc_tools.sum(axis=1, keepdims=True) + 1e-10)
        theme_tool = np.zeros((n_themes, n_tools))
        for theme_idx in range(n_themes):
            theme_weights = doc_theme[:, theme_idx]
            if theme_weights.sum() > 0:
                theme_weights = theme_weights / theme_weights.sum()
                for tool_idx in range(n_tools):
                    theme_tool[theme_idx, tool_idx] = np.sum(theme_weights * doc_tools_norm[:, tool_idx])
        return pd.DataFrame(theme_tool, index=theme_names, columns=self.tool_categories)
    
    def build_theme_actor_matrix(self, doc_theme, doc_actors, theme_names, policy_type="中央"):
        n_docs, n_themes = doc_theme.shape
        
        all_actors = set()
        doc_mapped_actors = []
        
        for doc_idx, actors in enumerate(doc_actors):
            if actors and len(actors) > 0:
                mapped_actors = []
                for actor in actors:
                    if actor:
                        mapped = map_department_to_category(actor)
                        mapped_actors.append(mapped)
                        all_actors.add(mapped)
                doc_mapped_actors.append(list(set(mapped_actors)))
            else:
                if policy_type == "中央":
                    default_actors = ['教育部门', '体育部门', '财政部门']
                else:
                    default_actors = ['教育部门', '体育部门', '财政部门', '省级政府']
                doc_mapped_actors.append(default_actors)
                for actor in default_actors:
                    all_actors.add(actor)
        
        if len(all_actors) == 0:
            if policy_type == "中央":
                all_actors = {'教育部门', '体育部门', '发改部门', '财政部门'}
            else:
                all_actors = {'教育部门', '体育部门', '财政部门', '省级政府'}
        
        all_actors = sorted(list(all_actors))
        actor_to_idx = {actor: idx for idx, actor in enumerate(all_actors)}
        n_actors = len(all_actors)
        
        doc_actor = np.zeros((n_docs, n_actors))
        for doc_idx, actors in enumerate(doc_mapped_actors):
            if actors and doc_idx < n_docs:
                unique_mapped = list(set(actors))
                if unique_mapped:
                    weight = 1.0 / len(unique_mapped)
                    for mapped in unique_mapped:
                        if mapped in actor_to_idx:
                            idx = actor_to_idx[mapped]
                            if idx < n_actors:
                                doc_actor[doc_idx, idx] = weight
        
        theme_actor = np.zeros((n_themes, n_actors))
        for theme_idx in range(n_themes):
            theme_weights = doc_theme[:, theme_idx]
            if theme_weights.sum() > 0:
                theme_weights = theme_weights / theme_weights.sum()
                for actor_idx in range(n_actors):
                    theme_actor[theme_idx, actor_idx] = np.sum(theme_weights * doc_actor[:, actor_idx])
        
        for i in range(n_themes):
            row_sum = theme_actor[i, :].sum()
            if row_sum > 0:
                theme_actor[i, :] = theme_actor[i, :] / row_sum
        
        return pd.DataFrame(theme_actor, index=theme_names, columns=all_actors)
    
    def calculate_theme_scores(self, theme_names, theme_tool, theme_actor):
        def entropy(dist):
            dist = dist / (dist.sum() + 1e-10)
            return -np.sum(dist * np.log(dist + 1e-10))
        
        scores = []
        for theme in theme_names:
            if theme in theme_tool.index:
                tool_dist = theme_tool.loc[theme].values
            else:
                tool_dist = np.zeros(len(self.tool_categories))
            
            if theme in theme_actor.index:
                actor_dist = theme_actor.loc[theme].values
            else:
                actor_dist = np.zeros(theme_actor.shape[1]) if theme_actor.shape[1] > 0 else np.zeros(1)
            
            tool_dist = np.nan_to_num(tool_dist)
            actor_dist = np.nan_to_num(actor_dist)
            
            tool_entropy = entropy(tool_dist)
            tool_diversity = tool_entropy / np.log(len(tool_dist) + 1e-10)
            actor_entropy = entropy(actor_dist)
            actor_collaboration = actor_entropy / np.log(len(actor_dist) + 1e-10) if len(actor_dist) > 1 else 0.5
            
            comprehensive = (THREE_DIMENSION_CONFIG['theme_tool_weight'] * tool_diversity +
                           THREE_DIMENSION_CONFIG['theme_actor_weight'] * actor_collaboration +
                           THREE_DIMENSION_CONFIG['tool_actor_weight'] * 0.5)
            
            if comprehensive >= THREE_DIMENSION_CONFIG['high_synergy_threshold']:
                level = '高协同'
            elif comprehensive >= THREE_DIMENSION_CONFIG['medium_synergy_threshold']:
                level = '中等协同'
            else:
                level = '低协同'
            
            scores.append({
                '主题': theme,
                '工具多样性得分': round(tool_diversity, 4),
                '主体协作得分': round(actor_collaboration, 4),
                '综合协同得分': round(comprehensive, 4),
                '协同等级': level
            })
        return pd.DataFrame(scores)
    
    def perform_clustering(self, theme_tool, theme_actor, n_clusters=3, policy_type="central"):
        tool_features = theme_tool.values
        actor_features = theme_actor.values
        
        if actor_features.shape[1] > 10:
            strengths = actor_features.sum(axis=0)
            top_idx = np.argsort(strengths)[-10:]
            actor_features = actor_features[:, top_idx]
        
        tool_features = (tool_features - tool_features.min(axis=0)) / (tool_features.max(axis=0) - tool_features.min(axis=0) + 1e-10)
        actor_features = (actor_features - actor_features.min(axis=0)) / (actor_features.max(axis=0) - actor_features.min(axis=0) + 1e-10)
        
        from sklearn.preprocessing import StandardScaler
        scaler = StandardScaler()
        tool_scaled = scaler.fit_transform(tool_features)
        actor_scaled = scaler.fit_transform(actor_features)
        combined = np.hstack([tool_scaled * 0.5, actor_scaled * 0.5])
        
        n_clusters = min(n_clusters, len(combined))
        if n_clusters < 1:
            n_clusters = 1
        
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        labels = kmeans.fit_predict(combined)
        results = pd.DataFrame({'主题': theme_tool.index.tolist(), '聚类类别': labels + 1})
        return results, labels
    
    def calculate_cross_synergy(self, central_theme_tool, local_theme_tool,
                                 central_theme_actor, local_theme_actor, matching_pairs):
        WEIGHT_THEME = 1/3
        WEIGHT_TOOL = 1/3
        WEIGHT_ACTOR = 1/3
        
        cross_scores = []
        skipped_count = 0
        
        common_actors = set(central_theme_actor.columns) & set(local_theme_actor.columns)
        
        if len(common_actors) == 0:
            all_actors = set(central_theme_actor.columns) | set(local_theme_actor.columns)
            common_actors = all_actors
            
            for actor in common_actors:
                if actor not in central_theme_actor.columns:
                    central_theme_actor[actor] = 0
                if actor not in local_theme_actor.columns:
                    local_theme_actor[actor] = 0
            
            central_theme_actor = central_theme_actor[list(common_actors)]
            local_theme_actor = local_theme_actor[list(common_actors)]
        
        print(f"\n跨维度协同分析：共同主体类别数 = {len(common_actors)}")
        print(f"  共同主体类别: {list(common_actors)}")
        
        for pair in matching_pairs:
            if pair.get('match_type') != 'matched':
                continue
            
            c_idx = pair['central_topic']
            l_idx = pair['local_topic']
            c_theme = f"C{c_idx+1}"
            l_theme = f"L{l_idx+1}"
            
            if c_theme not in central_theme_tool.index or l_theme not in local_theme_tool.index:
                skipped_count += 1
                continue
            
            theme_match_score = pair['match_score']
            
            c_tool = central_theme_tool.loc[c_theme].values
            l_tool = local_theme_tool.loc[l_theme].values
            tool_sim = cosine_similarity(c_tool.reshape(1, -1), l_tool.reshape(1, -1))[0, 0]
            
            c_actor = central_theme_actor.loc[c_theme, list(common_actors)].values
            l_actor = local_theme_actor.loc[l_theme, list(common_actors)].values
            
            if np.linalg.norm(c_actor) == 0:
                c_actor = np.ones(len(common_actors)) / len(common_actors)
            if np.linalg.norm(l_actor) == 0:
                l_actor = np.ones(len(common_actors)) / len(common_actors)
            
            actor_sim = cosine_similarity(c_actor.reshape(1, -1), l_actor.reshape(1, -1))[0, 0]
            actor_sim = max(0.1, min(0.9, actor_sim))
            
            cross_score = (
                WEIGHT_THEME * theme_match_score +
                WEIGHT_TOOL * tool_sim +
                WEIGHT_ACTOR * actor_sim
            )
            
            cross_scores.append({
                '中央主题': c_theme,
                '地方主题': l_theme,
                '主题匹配得分': round(theme_match_score, 4),
                '工具相似度': round(tool_sim, 4),
                '主体相似度': round(actor_sim, 4),
                '跨维度协同得分': round(cross_score, 4)
            })
        
        if skipped_count > 0:
            print(f"⚠️ 跳过了 {skipped_count} 个无效主题对")
        
        return pd.DataFrame(cross_scores)


class ThreeDimensionVisualizer:
    def __init__(self, output_dir):
        self.output_dir = output_dir
    
    def plot_theme_tool_heatmap(self, matrix, title):
        if matrix.empty:
            return
        fig, ax = plt.subplots(figsize=(10, max(5, len(matrix) * 0.4)))
        sns.heatmap(matrix, annot=True, cmap='RdYlBu_r', fmt='.3f', cbar_kws={'label': '关联强度'}, ax=ax, vmin=0, vmax=1)
        ax.set_title(title)
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, f'{title}.png'), dpi=1000, bbox_inches='tight')
        plt.close()
    
    def plot_theme_actor_heatmap(self, matrix, title, top_n=8):
        if matrix.empty:
            return
        strengths = matrix.sum(axis=0).sort_values(ascending=False)
        top_actors = strengths.head(top_n).index.tolist()
        filtered = matrix[top_actors]
        fig, ax = plt.subplots(figsize=(12, max(5, len(matrix) * 0.4)))
        sns.heatmap(filtered, annot=True, cmap='Greens', fmt='.3f', cbar_kws={'label': '关联强度'}, ax=ax, vmin=0, vmax=1)
        ax.set_title(title)
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, f'{title}.png'), dpi=1000, bbox_inches='tight')
        plt.close()
    
    def plot_radar_chart(self, scores_df, title):
        if scores_df.empty:
            return
        top_themes = scores_df.nlargest(6, '综合协同得分')
        categories = ['工具多样性', '主体协作', '综合协同']
        N = len(categories)
        angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
        angles += angles[:1]
        fig, ax = plt.subplots(figsize=(10, 8), subplot_kw={'projection': 'polar'})
        colors = plt.cm.tab10(np.linspace(0, 1, len(top_themes)))
        for idx, (_, row) in enumerate(top_themes.iterrows()):
            values = [row['工具多样性得分'], row['主体协作得分'], row['综合协同得分']]
            values += values[:1]
            ax.plot(angles, values, 'o-', linewidth=2, color=colors[idx], label=f"{row['主题']} ({row['综合协同得分']:.3f})")
            ax.fill(angles, values, alpha=0.1, color=colors[idx])
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(categories)
        ax.set_ylim(0, 1)
        ax.set_title(title)
        ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0), fontsize=8)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, f'{title}.png'), dpi=1000, bbox_inches='tight')
        plt.close()
    
    def plot_clustering_scatter(self, theme_tool, theme_actor, labels, policy_type):
        tool_features = theme_tool.values
        actor_features = theme_actor.values
        if actor_features.shape[1] > 10:
            strengths = actor_features.sum(axis=0)
            top_idx = np.argsort(strengths)[-10:]
            actor_features = actor_features[:, top_idx]
        tool_features = (tool_features - tool_features.min(axis=0)) / (tool_features.max(axis=0) - tool_features.min(axis=0) + 1e-10)
        actor_features = (actor_features - actor_features.min(axis=0)) / (actor_features.max(axis=0) - actor_features.min(axis=0) + 1e-10)
        combined = np.hstack([tool_features, actor_features])
        pca = PCA(n_components=2, random_state=42)
        coords = pca.fit_transform(combined)
        fig, ax = plt.subplots(figsize=(12, 8))
        colors = plt.cm.tab10(np.linspace(0, 1, len(np.unique(labels))))
        for i, label in enumerate(np.unique(labels)):
            mask = labels == label
            ax.scatter(coords[mask, 0], coords[mask, 1], c=[colors[i]], s=300, alpha=0.7, edgecolors='black', linewidths=1.5, label=f'聚类 {label+1}')
        themes = theme_tool.index.tolist()
        for idx, (x, y) in enumerate(coords):
            ax.annotate(themes[idx], (x, y), fontsize=10, fontweight='bold', xytext=(5, 5), textcoords='offset points')
        ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}%)')
        ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}%)')
        ax.set_title(f'{policy_type}政策主题聚类分析')
        ax.legend(loc='best')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, f'{policy_type}_主题聚类散点图.png'), dpi=1000, bbox_inches='tight')
        plt.close()
    
    def plot_cross_synergy_matrix(self, cross_df, central_themes, local_themes):
        if cross_df.empty:
            return
        matrix = np.zeros((len(central_themes), len(local_themes)))
        for _, row in cross_df.iterrows():
            c_idx = central_themes.index(row['中央主题'])
            l_idx = local_themes.index(row['地方主题'])
            matrix[c_idx, l_idx] = row['跨维度协同得分']
        fig, ax = plt.subplots(figsize=(10, 8))
        im = ax.imshow(matrix, cmap='RdYlBu_r', vmin=0, vmax=1)
        ax.set_xticks(range(len(local_themes)))
        ax.set_yticks(range(len(central_themes)))
        ax.set_xticklabels(local_themes, rotation=45, ha='right')
        ax.set_yticklabels(central_themes)
        ax.set_xlabel('地方政策主题')
        ax.set_ylabel('中央政策主题')
        ax.set_title('央地跨维度协同得分矩阵')
        for i in range(len(central_themes)):
            for j in range(len(local_themes)):
                if matrix[i, j] > 0:
                    color = 'white' if matrix[i, j] > 0.6 else 'black'
                    ax.text(j, i, f'{matrix[i, j]:.2f}', ha='center', va='center', fontsize=9, color=color, fontweight='bold')
        plt.colorbar(im, ax=ax, label='跨维度协同得分')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, '央地跨维度协同矩阵.png'), dpi=1000, bbox_inches='tight')
        plt.close()


# ==================== 完整中文分析报告生成 ====================

def generate_comprehensive_chinese_report_v24(
    central_k, local_k, synergy_df, comprehensive_score,
    central_strengths, local_strengths, central_info, local_info,
    similarity_matrix, central_model, local_model,
    central_df, local_df,
    central_yearly_strengths, local_yearly_strengths,
    central_years, local_years,
    framework_df, reliability_result,
    central_freq, local_freq, central_count, local_count,
    G_central_full, G_local_full, df_central, df_local,
    central_cliques_3, local_cliques_3, central_cores, local_cores,
    network_results, three_dimension_results=None
):
    report_path = os.path.join(OUTPUT_DIR, '完整中文分析报告.txt')
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("=" * 80 + "\n")
        f.write("学校体育政策府际协同关系分析报告（v28.4版 - 更新参考文献，节点标签12号）\n")
        f.write("=" * 80 + "\n\n")
        f.write(f"报告生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("数据时间范围：2011-2025年\n")
        f.write(f"中央政策文档数：{len(central_df)}份\n")
        f.write(f"地方政策文档数：{len(local_df)}份\n")
        f.write("【数据来源】\n")
        f.write("  1. 政策文本：47份中央政策 + 130份地方政策（真实txt文件）\n")
        f.write("  2. 政策主体：从《学校体育政策文件.xlsx》提取（真实数据）\n")
        f.write("  3. 部门名称标准化：区分中央和地方，确保网络图节点准确\n")
        f.write("  4. 工具表归一化：每个时间段内，所有14个二级指标归一化后总和=100%\n")
        f.write("  5. 所有输出结果图分辨率：1000 DPI（超高清晰度）\n")
        f.write("  6. 政策工具二级指标参考文献：王培刚与吴婧等(2026)，曹盛民与史万兵(2018)，张歆竹与刘俊荣(2024)，部义峰与来鲁振(2020)\n")
        f.write("  7. 四时段对比图和派系网络对比图的节点标签字体：12号\n\n")
        
        f.write("=" * 80 + "\n")
        f.write("第一部分：主题部分（LDA主题建模与主题强度分析）\n")
        f.write("=" * 80 + "\n\n")
        f.write("1.1 LDA主题建模\n")
        f.write("-" * 60 + "\n\n")
        f.write("【中央政策\"主题-关键词\"分布】\n\n")
        for i in range(central_k):
            f.write(f"主题C{i+1}：{central_info[i] if i in central_info else '待补充'}\n")
            f.write(f"  主题强度（文档长度加权）：{central_strengths[i]:.4f}\n\n")
        
        f.write("【地方政策\"主题-关键词\"分布】\n\n")
        for i in range(local_k):
            f.write(f"主题L{i+1}：{local_info[i] if i in local_info else '待补充'}\n")
            f.write(f"  主题强度（文档长度加权）：{local_strengths[i]:.4f}\n\n")
        
        f.write("1.2 主题余弦相似度分析\n")
        f.write("-" * 60 + "\n\n")
        f.write("【央地政策主题余弦相似度矩阵】\n\n")
        f.write("中央\\地方\t" + "\t".join([f"L{i+1}" for i in range(local_k)]) + "\n")
        for c in range(central_k):
            row = [f"C{c+1}"]
            for l in range(local_k):
                sim_value = similarity_matrix[c, l] if c < similarity_matrix.shape[0] and l < similarity_matrix.shape[1] else 0
                row.append(f"{sim_value:.4f}")
            f.write("\t".join(row) + "\n")
        f.write("\n")
        
        f.write("【央地协同类型分布（7种类型完整统计）】\n\n")
        type_counts = {}
        for t in ALL_SYNERGY_TYPES:
            type_counts[t] = len(synergy_df[synergy_df['synergy_type'] == t]) if t in synergy_df['synergy_type'].values else 0
        
        for stype in ALL_SYNERGY_TYPES:
            count = type_counts[stype]
            pct = count / len(synergy_df) * 100 if len(synergy_df) > 0 else 0
            f.write(f"  {stype}（{SYNERGY_MEANINGS[stype]}）：{count} 个 ({pct:.1f}%)\n")
        
        f.write(f"\n综合协同度指数：{comprehensive_score:.4f}\n")
        if comprehensive_score > 0.7:
            f.write("评价：央地政策协同良好\n\n")
        elif comprehensive_score > 0.5:
            f.write("评价：央地政策协同中等，有改进空间\n\n")
        else:
            f.write("评价：央地政策协同较弱，需加强\n\n")
        
        if 'match_quality' in synergy_df.columns:
            f.write("【BTM匹配质量统计】\n\n")
            quality_counts = synergy_df['match_quality'].value_counts()
            quality_names = {'high': '高质量匹配(≥0.70)', 'medium': '中等匹配(0.40-0.70)', 
                           'low': '低质量匹配(0.10-0.40)', 'none': '未匹配(<0.10)'}
            for quality, count in quality_counts.items():
                quality_name = quality_names.get(quality, quality)
                pct = count / len(synergy_df) * 100
                f.write(f"  {quality_name}：{count} 个 ({pct:.1f}%)\n")
            f.write("\n")
        
        f.write("=" * 80 + "\n")
        f.write("第二部分：政策工具部分（14个二级指标）\n")
        f.write("=" * 80 + "\n\n")
        f.write("2.1 政策工具类型及其含义\n")
        f.write("-" * 60 + "\n\n")
        f.write("本研究基于Rothwell & Zegveld模型，构建了包含3个一级工具、14个二级指标的政策工具分析框架：\n\n")
        
        f.write("【14个二级指标完整框架】\n\n")
        f.write("| 一级工具 | 二级指标 | 操作化定义 | 关键词示例 | 文献来源 |\n")
        f.write("| --- | --- | --- | --- | --- |\n")
        for indicator, tool_type in INDICATOR_TO_TYPE.items():
            definition = INDICATOR_DEFINITIONS.get(indicator, "待补充")
            keywords = INDICATOR_KEYWORDS.get(indicator, "待补充")
            literature = INDICATOR_LITERATURE.get(indicator, "待补充")
            f.write(f"| {tool_type} | {indicator} | {definition} | {keywords} | {literature} |\n")
        
        f.write("\n2.2 央地政策工具使用对比（四个时间段）\n")
        f.write("-" * 60 + "\n\n")
        f.write("**说明**：每个时间段内，所有14个二级指标**归一化后总和=100%**。\n\n")
        f.write("| 一级工具 | 二级指标 | 2011-2025_中央 | 2011-2025_地方 | 2011-2015_中央 | 2011-2015_地方 | 2016-2020_中央 | 2016-2020_地方 | 2021-2025_中央 | 2021-2025_地方 |\n")
        f.write("| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |\n")
        
        period_file = os.path.join(OUTPUT_DIR, "央地政策不同时期工具使用分布表.xlsx")
        if os.path.exists(period_file):
            try:
                period_df = pd.read_excel(period_file, sheet_name="不同时期对比（整体归一化）")
                for _, row in period_df.iterrows():
                    f.write(f"| {row['一级工具']} | {row['二级指标']} | {row['2011-2025_中央']} | {row['2011-2025_地方']} | "
                           f"{row['2011-2015_中央']} | {row['2011-2015_地方']} | {row['2016-2020_中央']} | {row['2016-2020_地方']} | "
                           f"{row['2021-2025_中央']} | {row['2021-2025_地方']} |\n")
            except:
                f.write("| 数据不可用 | - | - | - | - | - | - | - | - | - |\n")
        f.write("\n")
        
        f.write("=" * 80 + "\n")
        f.write("第三部分：政策主体部分（协作网络分析 - 加权版）\n")
        f.write("=" * 80 + "\n\n")
        f.write("3.1 网络整体结构（四个时间段）\n")
        f.write("-" * 60 + "\n\n")
        
        if G_central_full.number_of_nodes() > 0:
            c_nodes = G_central_full.number_of_nodes()
            c_edges = G_central_full.number_of_edges()
            total_weight_c = sum(d.get('weight', 1) for u, v, d in G_central_full.edges(data=True))
            max_weight_c = max([d.get('weight', 1) for u, v, d in G_central_full.edges(data=True)] or [1])
            max_possible_weighted = c_nodes * (c_nodes - 1) / 2 * max_weight_c if c_nodes > 1 else 1
            c_weighted_density = total_weight_c / max_possible_weighted if max_possible_weighted > 0 else 0
            c_avg_clustering = nx.average_clustering(G_central_full, weight='weight') if c_nodes > 0 else 0
            
            f.write("【中央政策主体网络（加权）】\n")
            f.write(f"  - 节点数：{c_nodes}个\n")
            f.write(f"  - 边数：{c_edges}条\n")
            f.write(f"  - 总合作权重：{total_weight_c:.0f}\n")
            f.write(f"  - 加权网络密度：{c_weighted_density:.4f}\n")
            f.write(f"  - 平均聚类系数（加权）：{c_avg_clustering:.4f}\n\n")
        
        if G_local_full.number_of_nodes() > 0:
            l_nodes = G_local_full.number_of_nodes()
            l_edges = G_local_full.number_of_edges()
            total_weight_l = sum(d.get('weight', 1) for u, v, d in G_local_full.edges(data=True))
            max_weight_l = max([d.get('weight', 1) for u, v, d in G_local_full.edges(data=True)] or [1])
            max_possible_weighted_l = l_nodes * (l_nodes - 1) / 2 * max_weight_l if l_nodes > 1 else 1
            l_weighted_density = total_weight_l / max_possible_weighted_l if max_possible_weighted_l > 0 else 0
            l_avg_clustering = nx.average_clustering(G_local_full, weight='weight') if l_nodes > 0 else 0
            
            f.write("【地方政策主体网络（加权）】\n")
            f.write(f"  - 节点数：{l_nodes}个\n")
            f.write(f"  - 边数：{l_edges}条\n")
            f.write(f"  - 总合作权重：{total_weight_l:.0f}\n")
            f.write(f"  - 加权网络密度：{l_weighted_density:.4f}\n")
            f.write(f"  - 平均聚类系数（加权）：{l_avg_clustering:.4f}\n\n")
        
        f.write("3.2 中心性分析（加权度数中心度）\n")
        f.write("-" * 60 + "\n\n")
        if not df_central.empty:
            f.write("【中央政策主体中心性指标（Top10）】\n\n")
            f.write("| 排名 | 发文单位 | 相对度数中心度（无权） | 加权度数中心度 | 接近中心度 | 中间中心度 |\n")
            f.write("| --- | --- | --- | --- | --- | --- |\n")
            for i, (_, row) in enumerate(df_central.head(10).iterrows()):
                f.write(f"| {i+1} | {row['发文单位']} | {row['相对度数中心度（无权）']:.4f} | {row['加权度数中心度']:.4f} | {row['接近中心度']:.4f} | {row['中间中心度']:.2f} |\n")
            f.write("\n")
        
        f.write("3.3 凝聚子群分析\n")
        f.write("-" * 60 + "\n\n")
        f.write(f"中央网络：检测到 {len(central_cliques_3)} 个3-派系\n")
        f.write(f"地方网络：检测到 {len(local_cliques_3)} 个3-派系\n\n")
        
        central_core_nodes = [node for node, k in central_cores.items() if k >= 3]
        local_core_nodes = [node for node, k in local_cores.items() if k >= 3]
        f.write(f"中央网络核心节点（K-核值≥3）：{len(central_core_nodes)}个\n")
        f.write(f"地方网络核心节点（K-核值≥3）：{len(local_core_nodes)}个\n\n")
        
        if three_dimension_results:
            f.write("=" * 80 + "\n")
            f.write("第四部分：主题-工具-主体三维协同分析\n")
            f.write("=" * 80 + "\n\n")
            
            f.write("4.1 中央政策主题三维协同得分\n")
            f.write("-" * 60 + "\n\n")
            f.write("| 主题 | 工具多样性得分 | 主体协作得分 | 综合协同得分 | 协同等级 |\n")
            f.write("| --- | --- | --- | --- | --- |\n")
            for _, row in three_dimension_results['central_scores'].iterrows():
                f.write(f"| {row['主题']} | {row['工具多样性得分']:.4f} | {row['主体协作得分']:.4f} | "
                       f"{row['综合协同得分']:.4f} | {row['协同等级']} |\n")
            
            f.write("\n4.2 地方政策主题三维协同得分\n")
            f.write("-" * 60 + "\n\n")
            f.write("| 主题 | 工具多样性得分 | 主体协作得分 | 综合协同得分 | 协同等级 |\n")
            f.write("| --- | --- | --- | --- | --- |\n")
            for _, row in three_dimension_results['local_scores'].iterrows():
                f.write(f"| {row['主题']} | {row['工具多样性得分']:.4f} | {row['主体协作得分']:.4f} | "
                       f"{row['综合协同得分']:.4f} | {row['协同等级']} |\n")
            
            f.write("\n4.3 央地跨维度协同得分\n")
            f.write("-" * 60 + "\n\n")
            if not three_dimension_results['cross_synergy'].empty:
                f.write("| 中央主题 | 地方主题 | 主题匹配得分 | 工具相似度 | 主体相似度 | 跨维度协同得分 |\n")
                f.write("| --- | --- | --- | --- | --- | --- |\n")
                for _, row in three_dimension_results['cross_synergy'].head(10).iterrows():
                    f.write(f"| {row['中央主题']} | {row['地方主题']} | {row['主题匹配得分']:.4f} | "
                           f"{row['工具相似度']:.4f} | {row['主体相似度']:.4f} | {row['跨维度协同得分']:.4f} |\n")
                
                avg_cross = three_dimension_results['cross_synergy']['跨维度协同得分'].mean()
                avg_actor = three_dimension_results['cross_synergy']['主体相似度'].mean()
                f.write(f"\n平均跨维度协同得分：{avg_cross:.4f}\n")
                f.write(f"平均主体相似度：{avg_actor:.4f}\n")
        
        f.write("\n" + "=" * 80 + "\n")
        f.write("总结与建议\n")
        f.write("=" * 80 + "\n\n")
        f.write("【主要发现】\n\n")
        f.write("1. 主题层面：央地政策主题存在明确的对应关系，综合协同度指数达到"
                  f"{comprehensive_score:.3f}，表明央地政策协同处于")
        if comprehensive_score > 0.7:
            f.write("良好水平。\n")
        elif comprehensive_score > 0.5:
            f.write("中等水平，仍有改进空间。\n")
        else:
            f.write("较弱水平，需加强协调。\n")
        f.write("2. 政策工具层面：供给型和环境型工具是央地政策共同关注的重点。\n")
        f.write("3. 政策主体层面：央地政策主体网络呈现多层次协同特征。\n")
        f.write("4. 时间维度：2011-2025年央地政策协同呈现阶段性变化特征。\n")
        f.write("5. 工具表归一化：每个时间段内，所有14个二级指标归一化后总和=100%，便于横向比较各指标的相对重要程度。\n\n")
        
        f.write("【对策建议】\n\n")
        f.write("1. 加强央地政策协调机制建设，提升政策传导效率\n")
        f.write("2. 丰富需求型政策工具的应用场景\n")
        f.write("3. 完善跨部门协同机制，打破部门壁垒\n")
        f.write("4. 优化主题-工具-主体的三维匹配度，提升整体协同效能\n\n")
        
        f.write("=" * 80 + "\n")
        f.write(f"报告生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("=" * 80 + "\n")
    print(f"完整中文分析报告已保存至: {report_path}")


# ==================== 主程序 ====================

def main():
    print("=" * 80)
    print("学校体育政策府际协同关系分析系统 - v28.4版（节点标签12号）")
    print("=" * 80)
    print("\n【v28核心修复】")
    print("  1. 修复部门名称标准化函数，区分中央和地方部门")
    print("  2. 地方政策中的'财政部门'正确显示为'省级财政部门'")
    print("  3. 确保网络图节点名称准确反映政策层级")
    print("  4. 所有分析均基于真实数据\n")
    print("【v28.1优化】")
    print("  5. 主题关键词改为8个\n")
    print("【v28.3新增】")
    print("  6. '央地政策不同时期工具使用分布表'中，每个时间段内所有14个二级指标归一化后总和=100%\n")
    print("【v28.4修改】")
    print("  7. 所有输出结果图分辨率改为1000 DPI（超高清晰度）")
    print("  8. 移除信度检验相关代码（不再依赖学校体育政策信度检验抽样汇总表.xlsx）")
    print("  9. 更新政策工具二级指标参考文献：")
    print("      - 王培刚与吴婧等(2026)")
    print("      - 曹盛民与史万兵(2018)")
    print("      - 张歆竹与刘俊荣(2024)")
    print("      - 部义峰与来鲁振(2020)")
    print("  10. 修改中央网络_四时段对比图.png、地方网络_四时段对比图.png、")
    print("      央地核心协作派系网络对比图.png的节点标签字体为12号\n")
    
    print(f"  中央数据路径: {CENTRAL_PATH}")
    print(f"  地方数据路径: {LOCAL_PATH}")
    print(f"  政策主体数据路径: {EXCEL_PATH}")
    print(f"  结果输出路径: {OUTPUT_DIR}")
    
    # ==================== 信度检验已移除 ====================
    reliability_result = None
    print("\n✅ 信度检验已跳过（不依赖学校体育政策信度检验抽样汇总表.xlsx）")
    
    SEEDS = [42, 123, 456, 789, 1024]
    INVALID_THRESHOLD = 0.02
    MATCH_THRESHOLD = 0.10
    
    print(f"\n参数设置:")
    print(f"  无效主题检测阈值: {INVALID_THRESHOLD}")
    print(f"  BTM匹配阈值: {MATCH_THRESHOLD}")
    print(f"  中央主题数搜索范围: {CENTRAL_TOPIC_RANGE[0]}-{CENTRAL_TOPIC_RANGE[1]}")
    print(f"  地方主题数搜索范围: {LOCAL_TOPIC_RANGE[0]}-{LOCAL_TOPIC_RANGE[1]}")
    print(f"  时间段: 2011-2025、2011-2015、2016-2020、2021-2025")
    print(f"  部门映射: 已启用（区分中央/地方）\n")
    
    # ========== 模块一：主题部分 ==========
    print("=" * 70)
    print("模块一：LDA主题建模与府际协同分析")
    print("=" * 70)
    
    data_loader = DataLoader(CENTRAL_PATH, LOCAL_PATH, OUTPUT_DIR)
    central_df, local_df = data_loader.load_all_policies()
    
    print(f"\n【加载结果】中央文档: {len(central_df)}份, 地方文档: {len(local_df)}份")
    
    preprocessor = PolicyPreprocessor()
    central_df = preprocessor.prepare_corpus(central_df)
    local_df = preprocessor.prepare_corpus(local_df)
    
    central_texts = central_df['processed'].tolist()
    local_texts = local_df['processed'].tolist()
    print(f"\n中央政策有效文档: {len(central_texts)} 份")
    print(f"地方政策有效文档: {len(local_texts)} 份")
    
    if len(central_texts) == 0 or len(local_texts) == 0:
        print("❌ 错误：文档数为0，请检查数据文件")
        return
    
    central_model = LDATopicModeler(max_features=600, max_iter=200, invalid_threshold=INVALID_THRESHOLD)
    central_k = central_model.find_optimal_topics(central_texts, CENTRAL_TOPIC_RANGE[0], CENTRAL_TOPIC_RANGE[1], "中央政策", SEEDS)
    central_model.plot_metrics_curves(OUTPUT_DIR, "中央政策")
    
    local_model = LDATopicModeler(max_features=800, max_iter=200, invalid_threshold=INVALID_THRESHOLD)
    local_k = local_model.find_optimal_topics(local_texts, LOCAL_TOPIC_RANGE[0], LOCAL_TOPIC_RANGE[1], "地方政策", SEEDS)
    local_model.plot_metrics_curves(OUTPUT_DIR, "地方政策")
    
    central_model.df_original = central_df
    local_model.df_original = local_df
    
    central_strengths = central_model.get_topic_strength_weighted()
    local_strengths = local_model.get_topic_strength_weighted()
    
    print(f"\n最终主题数: 中央{central_k}个, 地方{local_k}个")
    
    # 修改为8个关键词
    central_words = central_model.get_top_words(8)
    local_words = local_model.get_top_words(8)
    
    central_info = {}
    for i, (k, v) in enumerate(central_words.items()):
        central_info[i] = '、'.join([w[0] for w in v[:8]])  # 显示8个关键词
        print(f"C{i+1}: {central_info[i]} (加权强度: {central_strengths[i]:.4f})")
    
    local_info = {}
    for i, (k, v) in enumerate(local_words.items()):
        local_info[i] = '、'.join([w[0] for w in v[:8]])  # 显示8个关键词
        print(f"L{i+1}: {local_info[i]} (加权强度: {local_strengths[i]:.4f})")
    
    central_years, central_yearly_strengths = central_model.get_yearly_topic_strengths()
    local_years, local_yearly_strengths = local_model.get_yearly_topic_strengths()
    
    matcher = BTMMatcher(threshold=MATCH_THRESHOLD, use_synonyms=True)
    matching_pairs, similarity_matrix = matcher.find_matching_pairs(central_model, local_model)
    
    analyzer = SynergyAnalyzer(OUTPUT_DIR)
    synergy_df = analyzer.compute_synergy_metrics(matching_pairs, central_strengths, local_strengths)
    comprehensive_score = analyzer.calculate_comprehensive_synergy_index(synergy_df)
    
    print(f"\n综合协同度指数: {comprehensive_score:.3f}")
    
    print("\n【7种协同类型统计】")
    for t in ALL_SYNERGY_TYPES:
        count = len(synergy_df[synergy_df['synergy_type'] == t]) if t in synergy_df['synergy_type'].values else 0
        pct = count / len(synergy_df) * 100 if len(synergy_df) > 0 else 0
        print(f"  {t}（{SYNERGY_MEANINGS[t]}）：{count} 个 ({pct:.1f}%)")
    
    theme_viz = ThemeVisualizer(OUTPUT_DIR)
    theme_viz.plot_cross_comparison_curves(central_model, local_model)
    theme_viz.plot_similarity_heatmap(similarity_matrix)
    theme_viz.plot_yearly_topic_matrices(central_model, local_model)
    theme_viz.plot_synergy_network(synergy_df, central_strengths, local_strengths)
    theme_viz.plot_synergy_distribution(synergy_df)
    theme_viz.plot_synergy_difference_barchart(synergy_df)
    theme_viz.plot_central_local_comprehensive(central_strengths, local_strengths)
    theme_viz.plot_synergy_distribution_pie(synergy_df)
    theme_viz.plot_difference_matrix(synergy_df, central_strengths, local_strengths)
    theme_viz.plot_central_topics_matrix(central_model)
    theme_viz.plot_local_topics_matrix(local_model)
    
    period_analyzer = TimePeriodAnalyzer(OUTPUT_DIR)
    period_analyzer.run_analysis(central_model, local_model, central_df, local_df)
    
    output_file = os.path.join(OUTPUT_DIR, '府际协同分析结果.xlsx')
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        synergy_df.to_excel(writer, sheet_name='协同分析结果', index=False)
        central_df_data = pd.DataFrame([{'主题ID': f"C{i+1}", '主题名称': central_info[i], '加权强度': central_strengths[i]} for i in range(central_k)])
        central_df_data.to_excel(writer, sheet_name='中央主题信息', index=False)
        local_df_data = pd.DataFrame([{'主题ID': f"L{i+1}", '主题名称': local_info[i], '加权强度': local_strengths[i]} for i in range(local_k)])
        local_df_data.to_excel(writer, sheet_name='地方主题信息', index=False)
    
    # ========== 模块二：工具部分 ==========
    print("\n" + "=" * 70)
    print("模块二：政策工具分析（14个二级指标）")
    print("=" * 70)
    
    framework = build_builtin_framework()
    framework_df = build_framework_dataframe()
    
    print("✅ 使用内置14个二级指标政策工具框架（基于Rothwell & Zegveld模型）")
    print(f"   - 供给型：{len(framework['供给型'])}个指标")
    print(f"   - 需求型：{len(framework['需求型'])}个指标")
    print(f"   - 环境型：{len(framework['环境型'])}个指标")
    
    central_texts_tool, local_texts_tool, metadata_df, text_names_df, sampling_stats = PolicyTextLoader.load_all_policies(CENTRAL_PATH, LOCAL_PATH)
    PolicyTextLoader.export_metadata(metadata_df, "policy_metadata.xlsx")
    PolicyTextLoader.export_text_names(text_names_df, "policy_text_names.xlsx")
    PolicyTextLoader.export_sampling_stats(sampling_stats, "sampling_stats.xlsx")
    
    tool_coder = PolicyTextCoder(framework_df)
    all_texts = central_texts_tool + local_texts_tool
    detailed_freq = tool_coder.get_detailed_frequency(all_texts, metadata_df)
    central_freq = detailed_freq["central"]
    local_freq = detailed_freq["local"]
    central_count = len(central_texts_tool)
    local_count = len(local_texts_tool)
    
    encoding_results = tool_coder.batch_encode(all_texts)
    tool_coder.export_encoding_results(encoding_results, "encoding_results.xlsx")
    
    validator = CoverageValidator(total_texts=len(all_texts))
    evaluation_df = validator.evaluate_all_indicators(detailed_freq["total"], central_freq, local_freq)
    validator.export_evaluation_report(evaluation_df, "coverage_evaluation.xlsx")
    
    documenter = FrameworkDocumenter(framework)
    documenter.export_framework_to_excel("policy_framework_table.xlsx")
    documenter.export_framework_theoretical_basis("policy_framework_theoretical_basis.md")
    documenter.export_to_markdown("school_sports_policy_framework.md")
    
    visualizer = PolicyVisualizerTool(framework_df, central_freq, local_freq, central_count, local_count)
    visualizer.generate_all()
    
    plot_tool_comparison_independent(framework_df, central_freq, local_freq, central_count, local_count)
    
    # ========== 调用修改后的 export_tool_comparison_by_period_table（整体归一化） ==========
    if tool_coder is not None and len(central_texts_tool) > 0 and len(local_texts_tool) > 0:
        export_tool_comparison_by_period_table(
            central_freq, local_freq, central_count, local_count,
            central_texts_tool, local_texts_tool, metadata_df, tool_coder
        )
    
    table_generator = ComparisonTableGenerator(central_freq, local_freq, central_count, local_count)
    table_generator.generate_all()
    
    # ========== 模块三：主体部分 ==========
    print("\n" + "=" * 70)
    print("模块三：央地政策主体协作网络分析（四个时间段）")
    print("=" * 70)
    
    G_central_full = nx.Graph()
    G_local_full = nx.Graph()
    G_central_2011_2015 = nx.Graph()
    G_central_2016_2020 = nx.Graph()
    G_central_2021_2025 = nx.Graph()
    G_local_2011_2015 = nx.Graph()
    G_local_2016_2020 = nx.Graph()
    G_local_2021_2025 = nx.Graph()
    df_central = pd.DataFrame()
    df_local = pd.DataFrame()
    central_cliques_3 = []
    local_cliques_3 = []
    central_cores = {}
    local_cores = {}
    network_results = []
    
    central_depts_full = []
    local_depts_full = []
    
    if os.path.exists(EXCEL_PATH):
        print("\n构建中央政策各时期网络...")
        central_depts_full = process_policy_by_coverage(2011, 2025, 'central')
        central_depts_2011_2015 = process_policy_by_coverage(2011, 2015, 'central')
        central_depts_2016_2020 = process_policy_by_coverage(2016, 2020, 'central')
        central_depts_2021_2025 = process_policy_by_coverage(2021, 2025, 'central')
        
        print("\n构建地方政策各时期网络...")
        local_depts_full = process_policy_by_coverage(2011, 2025, 'local')
        local_depts_2011_2015 = process_policy_by_coverage(2011, 2015, 'local')
        local_depts_2016_2020 = process_policy_by_coverage(2016, 2020, 'local')
        local_depts_2021_2025 = process_policy_by_coverage(2021, 2025, 'local')
        
        G_central_full = build_cooccurrence_network(central_depts_full)
        G_central_2011_2015 = build_cooccurrence_network(central_depts_2011_2015)
        G_central_2016_2020 = build_cooccurrence_network(central_depts_2016_2020)
        G_central_2021_2025 = build_cooccurrence_network(central_depts_2021_2025)
        
        G_local_full = build_cooccurrence_network(local_depts_full)
        G_local_2011_2015 = build_cooccurrence_network(local_depts_2011_2015)
        G_local_2016_2020 = build_cooccurrence_network(local_depts_2016_2020)
        G_local_2021_2025 = build_cooccurrence_network(local_depts_2021_2025)
        
        c_nodes_full = G_central_full.number_of_nodes()
        c_edges_full = G_central_full.number_of_edges()
        total_weight_c = sum(d.get('weight', 1) for u, v, d in G_central_full.edges(data=True))
        max_weight_c = max([d.get('weight', 1) for u, v, d in G_central_full.edges(data=True)] or [1])
        max_possible_weighted_c = c_nodes_full * (c_nodes_full - 1) / 2 * max_weight_c if c_nodes_full > 1 else 1
        c_weighted_density_full = total_weight_c / max_possible_weighted_c if max_possible_weighted_c > 0 else 0
        
        l_nodes_full = G_local_full.number_of_nodes()
        l_edges_full = G_local_full.number_of_edges()
        total_weight_l = sum(d.get('weight', 1) for u, v, d in G_local_full.edges(data=True))
        max_weight_l = max([d.get('weight', 1) for u, v, d in G_local_full.edges(data=True)] or [1])
        max_possible_weighted_l = l_nodes_full * (l_nodes_full - 1) / 2 * max_weight_l if l_nodes_full > 1 else 1
        l_weighted_density_full = total_weight_l / max_possible_weighted_l if max_possible_weighted_l > 0 else 0
        
        print(f"\n网络统计（加权）:")
        print(f"  中央网络 - 全时段: {c_nodes_full}个节点, {c_edges_full}条边, 总权重={total_weight_c:.0f}, 加权密度={c_weighted_density_full:.4f}")
        print(f"  地方网络 - 全时段: {l_nodes_full}个节点, {l_edges_full}条边, 总权重={total_weight_l:.0f}, 加权密度={l_weighted_density_full:.4f}")
        
        visualize_network(G_central_full, "中央政策主体协作网络（全时段）- 边粗细表示合作强度", "中央网络_全时段_加权.png", "central")
        visualize_network(G_local_full, "地方政策主体协作网络（全时段）- 边粗细表示合作强度", "地方网络_全时段_加权.png", "local")
        
        # 调用修改后的 visualize_four_period_networks（节点标签字体已改为12）
        visualize_four_period_networks(
            G_central_full, G_local_full,
            G_central_2011_2015, G_local_2011_2015,
            G_central_2016_2020, G_local_2016_2020,
            G_central_2021_2025, G_local_2021_2025
        )
        
        periods = {"2011-2025": (2011, 2025), "2011-2015": (2011, 2015), 
                   "2016-2020": (2016, 2020), "2021-2025": (2021, 2025)}
        for period_name, (start, end) in periods.items():
            print(f"\n处理时间段: {period_name}")
            central_depts = process_policy_by_coverage(start, end, 'central')
            local_depts = process_policy_by_coverage(start, end, 'local')
            G_central = build_cooccurrence_network(central_depts)
            G_local = build_cooccurrence_network(local_depts)
            
            c_nodes, c_edges = G_central.number_of_nodes(), G_central.number_of_edges()
            total_w_c = sum(d.get('weight', 1) for u, v, d in G_central.edges(data=True))
            max_w_c = max([d.get('weight', 1) for u, v, d in G_central.edges(data=True)] or [1])
            max_possible_c = c_nodes * (c_nodes - 1) / 2 * max_w_c if c_nodes > 1 else 1
            c_w_density = total_w_c / max_possible_c if max_possible_c > 0 else 0
            c_clustering = nx.average_clustering(G_central, weight='weight') if c_nodes > 0 else 0
            
            l_nodes, l_edges = G_local.number_of_nodes(), G_local.number_of_edges()
            total_w_l = sum(d.get('weight', 1) for u, v, d in G_local.edges(data=True))
            max_w_l = max([d.get('weight', 1) for u, v, d in G_local.edges(data=True)] or [1])
            max_possible_l = l_nodes * (l_nodes - 1) / 2 * max_w_l if l_nodes > 1 else 1
            l_w_density = total_w_l / max_possible_l if max_possible_l > 0 else 0
            l_clustering = nx.average_clustering(G_local, weight='weight') if l_nodes > 0 else 0
            
            network_results.append({
                "period": period_name, 
                "c_nodes": c_nodes, "c_edges": c_edges, 
                "c_weighted_density": c_w_density, "c_clustering": c_clustering,
                "l_nodes": l_nodes, "l_edges": l_edges,
                "l_weighted_density": l_w_density, "l_clustering": l_clustering
            })
            visualize_degree_distribution(G_central, G_local, period_name)
        
        visualize_metrics_trend(network_results)
        
        df_central = calculate_centrality_metrics_weighted(G_central_full)
        df_local = calculate_centrality_metrics_weighted(G_local_full)
        
        if not df_central.empty:
            df_central.to_csv(os.path.join(OUTPUT_DIR, "中央政策主体中心性指标_加权.csv"), index=False, encoding="utf-8-sig")
        if not df_local.empty:
            df_local.to_csv(os.path.join(OUTPUT_DIR, "地方政策主体中心性指标_加权.csv"), index=False, encoding="utf-8-sig")
        
        visualize_centrality_bar_chart(df_central, df_local)
        visualize_centrality_radar(df_central, df_local)
        visualize_network_comparison(G_central_full, G_local_full)
        
        central_cliques_3 = k_clique_analysis(G_central_full, k=3)
        local_cliques_3 = k_clique_analysis(G_local_full, k=3)
        print(f"\n凝聚子群分析:")
        print(f"  中央网络 - 3-派系: {len(central_cliques_3)}个")
        print(f"  地方网络 - 3-派系: {len(local_cliques_3)}个")
        
        export_faction_analysis_plots(G_central_full, G_local_full, central_cliques_3, local_cliques_3)
        # 调用修改后的 visualize_faction_comparison（节点标签字体已改为12）
        visualize_faction_comparison(G_central_full, G_local_full, central_cliques_3, local_cliques_3)
        
        export_network_summary_table_v23(
            G_central_full, G_local_full,
            G_central_2011_2015, G_local_2011_2015,
            G_central_2016_2020, G_local_2016_2020,
            G_central_2021_2025, G_local_2021_2025
        )
        
        visualize_subgroups(G_central_full, central_cliques_3, "中央网络 - 核心协作派系", "中央_派系分析.png", "central")
        visualize_subgroups(G_local_full, local_cliques_3, "地方网络 - 核心协作派系", "地方_派系分析.png", "local")
        
        central_cores, central_core_groups = k_core_analysis(G_central_full)
        local_cores, local_core_groups = k_core_analysis(G_local_full)
        
        export_subgroup_analysis_to_excel(
            G_central_full, G_local_full, central_cliques_3, local_cliques_3,
            central_cores, local_cores
        )
    else:
        print(f"⚠️ Excel文件不存在: {EXCEL_PATH}")
        print("   主体分析将被跳过")
    
    # ========== 模块四：三维协同分析 ==========
    print("\n" + "=" * 70)
    print("模块四：主题-工具-主体三维协同分析")
    print("=" * 70)
    
    three_dimension_results = None
    
    if tool_coder is not None and len(central_df) > 0 and len(local_df) > 0 and len(central_depts_full) > 0 and len(local_depts_full) > 0:
        print("✅ 三维分析：使用 process_policy_by_coverage 提取的真实部门数据")
        print(f"  中央部门记录数: {len(central_depts_full)}")
        print(f"  地方部门记录数: {len(local_depts_full)}")
        
        if len(central_depts_full) != len(central_df):
            min_central = min(len(central_df), len(central_depts_full))
            central_depts_trimmed = central_depts_full[:min_central]
            central_df_trimmed = central_df.iloc[:min_central]
        else:
            central_depts_trimmed = central_depts_full
            central_df_trimmed = central_df
        
        if len(local_depts_full) != len(local_df):
            min_local = min(len(local_df), len(local_depts_full))
            local_depts_trimmed = local_depts_full[:min_local]
            local_df_trimmed = local_df.iloc[:min_local]
        else:
            local_depts_trimmed = local_depts_full
            local_df_trimmed = local_df
        
        print(f"  实际使用：中央 {len(central_df_trimmed)} 份，地方 {len(local_df_trimmed)} 份")
        
        if len(central_depts_trimmed) > 0:
            print(f"  中央部门数据样本: {central_depts_trimmed[0]}")
        if len(local_depts_trimmed) > 0:
            print(f"  地方部门数据样本: {local_depts_trimmed[0]}")
        
        central_tools = np.array([tool_coder.get_tool_vector(text) for text in central_df_trimmed['content'].tolist()])
        local_tools = np.array([tool_coder.get_tool_vector(text) for text in local_df_trimmed['content'].tolist()])
        
        central_theme_names = [f"C{i+1}" for i in range(central_model.n_topics)]
        local_theme_names = [f"L{i+1}" for i in range(local_model.n_topics)]
        
        three_dim_analyzer = ThreeDimensionAnalyzer(OUTPUT_DIR, tool_coder)
        three_dim_viz = ThreeDimensionVisualizer(OUTPUT_DIR)
        
        central_theme_tool = three_dim_analyzer.build_theme_tool_matrix(
            central_model.doc_topic_dist[:len(central_df_trimmed)], central_tools, central_theme_names
        )
        local_theme_tool = three_dim_analyzer.build_theme_tool_matrix(
            local_model.doc_topic_dist[:len(local_df_trimmed)], local_tools, local_theme_names
        )
        
        central_theme_actor = three_dim_analyzer.build_theme_actor_matrix(
            central_model.doc_topic_dist[:len(central_df_trimmed)], central_depts_trimmed, central_theme_names, "中央"
        )
        local_theme_actor = three_dim_analyzer.build_theme_actor_matrix(
            local_model.doc_topic_dist[:len(local_df_trimmed)], local_depts_trimmed, local_theme_names, "地方"
        )
        
        print(f"\n中央主题-主体矩阵维度: {central_theme_actor.shape}")
        print(f"  主体类别: {list(central_theme_actor.columns)}")
        print(f"地方主题-主体矩阵维度: {local_theme_actor.shape}")
        print(f"  主体类别: {list(local_theme_actor.columns)}")
        
        central_scores = three_dim_analyzer.calculate_theme_scores(
            central_theme_names, central_theme_tool, central_theme_actor
        )
        local_scores = three_dim_analyzer.calculate_theme_scores(
            local_theme_names, local_theme_tool, local_theme_actor
        )
        
        print("\n中央政策主题三维协同得分:")
        print(central_scores.to_string(index=False))
        print("\n地方政策主题三维协同得分:")
        print(local_scores.to_string(index=False))
        
        central_clusters, central_labels = three_dim_analyzer.perform_clustering(
            central_theme_tool, central_theme_actor, n_clusters=min(3, len(central_theme_names)), policy_type="中央"
        )
        local_clusters, local_labels = three_dim_analyzer.perform_clustering(
            local_theme_tool, local_theme_actor, n_clusters=min(3, len(local_theme_names)), policy_type="地方"
        )
        
        cross_synergy = three_dim_analyzer.calculate_cross_synergy(
            central_theme_tool, local_theme_tool, central_theme_actor, local_theme_actor, matching_pairs
        )
        
        three_dim_viz.plot_theme_tool_heatmap(central_theme_tool, "中央政策-主题-工具关联热力图")
        three_dim_viz.plot_theme_tool_heatmap(local_theme_tool, "地方政策-主题-工具关联热力图")
        three_dim_viz.plot_theme_actor_heatmap(central_theme_actor, "中央政策-主题-主体关联热力图")
        three_dim_viz.plot_theme_actor_heatmap(local_theme_actor, "地方政策-主题-主体关联热力图")
        three_dim_viz.plot_radar_chart(central_scores, "中央政策主题三维协同能力雷达图")
        three_dim_viz.plot_radar_chart(local_scores, "地方政策主题三维协同能力雷达图")
        three_dim_viz.plot_clustering_scatter(central_theme_tool, central_theme_actor, central_labels, "中央")
        three_dim_viz.plot_clustering_scatter(local_theme_tool, local_theme_actor, local_labels, "地方")
        three_dim_viz.plot_cross_synergy_matrix(cross_synergy, central_theme_names, local_theme_names)
        
        with pd.ExcelWriter(os.path.join(OUTPUT_DIR, '三维协同分析结果.xlsx'), engine='openpyxl') as writer:
            central_scores.to_excel(writer, sheet_name='中央主题协同得分', index=False)
            local_scores.to_excel(writer, sheet_name='地方主题协同得分', index=False)
            central_theme_tool.to_excel(writer, sheet_name='中央主题-工具矩阵')
            local_theme_tool.to_excel(writer, sheet_name='地方主题-工具矩阵')
            central_theme_actor.to_excel(writer, sheet_name='中央主题-主体矩阵')
            local_theme_actor.to_excel(writer, sheet_name='地方主题-主体矩阵')
            central_clusters.to_excel(writer, sheet_name='中央主题聚类', index=False)
            local_clusters.to_excel(writer, sheet_name='地方主题聚类', index=False)
            if not cross_synergy.empty:
                cross_synergy.to_excel(writer, sheet_name='央地跨维度协同', index=False)
        
        three_dimension_results = {
            'central_scores': central_scores,
            'local_scores': local_scores,
            'cross_synergy': cross_synergy,
            'central_clusters': central_clusters,
            'local_clusters': local_clusters
        }
        
        if three_dimension_results is not None and not three_dimension_results['cross_synergy'].empty:
            cross_df = three_dimension_results['cross_synergy']
            
            csv_path = os.path.join(OUTPUT_DIR, '央地跨维度协同得分表.csv')
            cross_df.to_csv(csv_path, index=False, encoding='utf-8-sig')
            print(f"✅ 跨维度协同得分表已保存: {csv_path}")
            
            md_path = os.path.join(OUTPUT_DIR, '央地跨维度协同得分表.md')
            with open(md_path, 'w', encoding='utf-8') as f:
                f.write("# 央地跨维度协同得分表\n\n")
                f.write("## 数据来源说明\n\n")
                f.write(f"- 中央部门数据：从《学校体育政策文件.xlsx》提取，共 {len(central_depts_full)} 条记录\n")
                f.write(f"- 地方部门数据：从《学校体育政策文件.xlsx》提取，共 {len(local_depts_full)} 条记录\n")
                f.write("- 主体映射方式：部门名称→类别映射\n\n")
                f.write("## 计算方法\n\n")
                f.write("**跨维度协同得分 = 1/3 × 主题匹配得分 + 1/3 × 工具相似度 + 1/3 × 主体相似度**\n\n")
                f.write("| 中央主题 | 地方主题 | 主题匹配得分 | 工具相似度 | 主体相似度 | 跨维度协同得分 |\n")
                f.write("| --- | --- | --- | --- | --- | --- |\n")
                for _, row in cross_df.iterrows():
                    f.write(f"| {row['中央主题']} | {row['地方主题']} | {row['主题匹配得分']:.4f} | "
                           f"{row['工具相似度']:.4f} | {row['主体相似度']:.4f} | {row['跨维度协同得分']:.4f} |\n")
                
                f.write(f"\n## 统计摘要\n\n")
                f.write(f"- 匹配主题对数：{len(cross_df)}\n")
                f.write(f"- 平均跨维度协同得分：{cross_df['跨维度协同得分'].mean():.4f}\n")
                f.write(f"- 最高跨维度协同得分：{cross_df['跨维度协同得分'].max():.4f}\n")
                f.write(f"- 最低跨维度协同得分：{cross_df['跨维度协同得分'].min():.4f}\n")
                f.write(f"- 标准差：{cross_df['跨维度协同得分'].std():.4f}\n")
                f.write(f"- 平均主体相似度：{cross_df['主体相似度'].mean():.4f}\n")
            
            print(f"✅ 跨维度协同得分Markdown表格已保存: {md_path}")
            
            excel_path = os.path.join(OUTPUT_DIR, '央地跨维度协同得分表.xlsx')
            with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
                cross_df.to_excel(writer, sheet_name='跨维度协同得分', index=False)
                
                summary_df = pd.DataFrame({
                    '统计项': ['匹配主题对数', '平均跨维度协同得分', '最高得分', '最低得分', '标准差', '平均主体相似度'],
                    '数值': [
                        len(cross_df),
                        round(cross_df['跨维度协同得分'].mean(), 4),
                        round(cross_df['跨维度协同得分'].max(), 4),
                        round(cross_df['跨维度协同得分'].min(), 4),
                        round(cross_df['跨维度协同得分'].std(), 4),
                        round(cross_df['主体相似度'].mean(), 4)
                    ]
                })
                summary_df.to_excel(writer, sheet_name='统计摘要', index=False)
                
                sorted_df = cross_df.sort_values('跨维度协同得分', ascending=False)
                sorted_df.to_excel(writer, sheet_name='按得分排序', index=False)
                
                note_df = pd.DataFrame({
                    '说明项': ['表格说明', '计算方法', '权重设置', '主体相似度说明', '数据来源', '生成时间'],
                    '内容': [
                        '央地跨维度协同得分表（三维等权计算）',
                        '跨维度协同得分 = 1/3 × 主题匹配得分 + 1/3 × 工具相似度 + 1/3 × 主体相似度',
                        '主题匹配得分：BTM匹配得分；工具相似度：余弦相似度；主体相似度：余弦相似度',
                        '主体相似度使用部门类别映射，确保央地主体维度对齐',
                        f'主体数据来自《学校体育政策文件.xlsx》（中央{len(central_depts_full)}条，地方{len(local_depts_full)}条）',
                        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    ]
                })
                note_df.to_excel(writer, sheet_name='说明', index=False)
            
            print(f"✅ 跨维度协同得分Excel表格已保存: {excel_path}")
        
        print(f"\n✅ 三维协同分析结果已保存至: {OUTPUT_DIR}")
    else:
        if len(central_depts_full) == 0 or len(local_depts_full) == 0:
            print("⚠️ 部门数据为空，请检查Excel文件中的'发文主体'列")
        else:
            print("⚠️ 工具编码器未初始化或数据不足，跳过三维协同分析")
    
    # ========== 生成完整报告 ==========
    print("\n" + "=" * 70)
    print("生成完整中文分析报告")
    print("=" * 70)
    
    generate_comprehensive_chinese_report_v24(
        central_k, local_k, synergy_df, comprehensive_score,
        central_strengths, local_strengths, central_info, local_info,
        similarity_matrix, central_model, local_model,
        central_df, local_df,
        central_yearly_strengths, local_yearly_strengths,
        central_years, local_years,
        framework_df, reliability_result,
        central_freq, local_freq, central_count, local_count,
        G_central_full, G_local_full, df_central, df_local,
        central_cliques_3, local_cliques_3, central_cores, local_cores,
        network_results, three_dimension_results
    )
    
    print("\n" + "=" * 80)
    print("分析完成！")
    print(f"✅ 所有结果已输出至: {OUTPUT_DIR}")
    print("=" * 80)
    print("\n生成的文件清单:")
    print("  📊 主题协同: 府际协同分析结果.xlsx, 央地协同关系网络图.png, 等20+个文件")
    print("  📊 工具分析:")
    print("      - 央地政策工具使用分布对比图.png（组合图）")
    print("      - 央地政策工具使用分布对比图_独立版.png（独立高清图）")
    print("      - 央地政策不同时期工具使用分布表.xlsx（四个时间段×央地，整体归一化）")
    print("      - 政策工具框架表.xlsx（14个二级指标完整框架）")
    print("      - school_sports_policy_framework.md（框架Markdown）")
    print("  📊 主体网络: 央地网络对比图.png, 中央网络_四时段对比图.png, 地方网络_四时段对比图.png, 等20+个文件")
    print("      - 中央网络_四时段对比图.png 节点标签字体: 12号")
    print("      - 地方网络_四时段对比图.png 节点标签字体: 12号")
    print("      - 央地核心协作派系网络对比图.png 节点标签字体: 12号")
    print("  📊 三维协同: 三维协同分析结果.xlsx, 三维协同可视化图表, 等10个文件")
    print("  📊 跨维度协同得分表: 央地跨维度协同得分表.xlsx, .csv, .md")
    print("  📄 综合报告: 完整中文分析报告.txt")
    print("  📊 网络整体特征: 表5_网络整体特征.xlsx（四个时间段）")
    print("  📊 派系分析PNG: 中央_派系分析.png, 地方_派系分析.png")
    print("  📊 凝聚子群分析: 凝聚子群分析结果.xlsx")
    print(f"\n  🔹 所有输出结果图分辨率: 1000 DPI（超高清晰度）")
    print("  🔹 信度检验已移除（不再依赖学校体育政策信度检验抽样汇总表.xlsx）")
    print("  🔹 政策工具参考文献已更新：王培刚与吴婧等(2026)，曹盛民与史万兵(2018)，张歆竹与刘俊荣(2024)，部义峰与来鲁振(2020)")
    print("  🔹 中央网络_四时段对比图.png、地方网络_四时段对比图.png、央地核心协作派系网络对比图.png 节点标签字体: 12号")


if __name__ == "__main__":
    main()